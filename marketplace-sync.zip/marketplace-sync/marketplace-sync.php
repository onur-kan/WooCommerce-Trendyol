<?php
/**
 * Plugin Name: Marketplace Sync
 * Plugin URI: https://github.com/cemasma/marketplace-sync
 * Description: WooCommerce ürünlerini marketplace platformlarıyla (Trendyol, Hepsiburada, vb.) senkronize edin
 * Version: 1.0.0
 * Author: Cem Asma
 * Author URI: https://github.com/cemasma
 * License: GPL v2 or later
 * Text Domain: marketplace-sync
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('MPS_VERSION', '1.0.0');
define('MPS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MPS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MPS_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main Plugin Class
 */
class Marketplace_Sync {
    
    private static $instance = null;
    
    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Check if WooCommerce is active
        if (!$this->is_woocommerce_active()) {
            add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
            return;
        }
        
        // Load required files
        $this->load_dependencies();
        
        // Hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // AJAX handlers
        add_action('wp_ajax_mps_sync_products', array($this, 'ajax_sync_products'));
        add_action('wp_ajax_mps_save_settings', array($this, 'ajax_save_settings'));
        add_action('wp_ajax_mps_test_connection', array($this, 'ajax_test_connection'));
    }
    
    /**
     * Check if WooCommerce is active
     */
    private function is_woocommerce_active() {
        return in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')));
    }
    
    /**
     * WooCommerce missing notice
     */
    public function woocommerce_missing_notice() {
        ?>
        <div class="notice notice-error">
            <p><?php _e('Marketplace Sync eklentisi WooCommerce gerektirir. Lütfen WooCommerce\'i yükleyin ve aktif edin.', 'marketplace-sync'); ?></p>
        </div>
        <?php
    }
    
    /**
     * Load required files
     */
    private function load_dependencies() {
        // Core classes
        require_once MPS_PLUGIN_DIR . 'includes/class-mps-api.php';
        require_once MPS_PLUGIN_DIR . 'includes/class-mps-settings.php';
        require_once MPS_PLUGIN_DIR . 'includes/class-mps-product-sync.php';
        require_once MPS_PLUGIN_DIR . 'includes/class-mps-logger.php';
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        $table_name = $wpdb->prefix . 'mps_sync_log';
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            product_id bigint(20) NOT NULL,
            marketplace varchar(50) NOT NULL,
            action varchar(50) NOT NULL,
            status varchar(20) NOT NULL,
            message text,
            request_data longtext,
            response_data longtext,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY product_id (product_id),
            KEY marketplace (marketplace),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Set default options
        if (!get_option('mps_settings')) {
            add_option('mps_settings', array(
                'trendyol_api_key' => '',
                'trendyol_api_secret' => '',
                'trendyol_supplier_id' => '',
                'auto_sync' => 'no',
                'sync_stock' => 'yes',
                'sync_price' => 'yes',
            ));
        }
        
        // Schedule cron if auto sync is enabled
        if (!wp_next_scheduled('mps_auto_sync')) {
            wp_schedule_event(time(), 'hourly', 'mps_auto_sync');
        }
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clear scheduled cron
        $timestamp = wp_next_scheduled('mps_auto_sync');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'mps_auto_sync');
        }
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Marketplace Sync', 'marketplace-sync'),
            __('Marketplace Sync', 'marketplace-sync'),
            'manage_woocommerce',
            'marketplace-sync',
            array($this, 'display_dashboard'),
            'dashicons-update',
            56
        );
        
        add_submenu_page(
            'marketplace-sync',
            __('Gösterge Paneli', 'marketplace-sync'),
            __('Gösterge Paneli', 'marketplace-sync'),
            'manage_woocommerce',
            'marketplace-sync',
            array($this, 'display_dashboard')
        );
        
        add_submenu_page(
            'marketplace-sync',
            __('Ayarlar', 'marketplace-sync'),
            __('Ayarlar', 'marketplace-sync'),
            'manage_woocommerce',
            'marketplace-sync-settings',
            array($this, 'display_settings_page')
        );
        
        add_submenu_page(
            'marketplace-sync',
            __('Senkronizasyon Logları', 'marketplace-sync'),
            __('Loglar', 'marketplace-sync'),
            'manage_woocommerce',
            'marketplace-sync-logs',
            array($this, 'display_logs_page')
        );
    }
    
    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'marketplace-sync') === false) {
            return;
        }
        
        wp_enqueue_style('mps-admin', MPS_PLUGIN_URL . 'assets/css/admin.css', array(), MPS_VERSION);
        wp_enqueue_script('mps-admin', MPS_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), MPS_VERSION, true);
        
        wp_localize_script('mps-admin', 'mpsAdmin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mps_nonce'),
            'i18n' => array(
                'confirm_sync' => __('Seçili ürünler senkronize edilecek. Devam etmek istiyor musunuz?', 'marketplace-sync'),
                'syncing' => __('Senkronize ediliyor...', 'marketplace-sync'),
                'success' => __('Başarılı!', 'marketplace-sync'),
                'error' => __('Hata oluştu!', 'marketplace-sync'),
            )
        ));
    }
    
    /**
     * Display dashboard page
     */
    public function display_dashboard() {
        include MPS_PLUGIN_DIR . 'admin/dashboard.php';
    }
    
    /**
     * Display settings page
     */
    public function display_settings_page() {
        include MPS_PLUGIN_DIR . 'admin/settings.php';
    }
    
    /**
     * Display logs page
     */
    public function display_logs_page() {
        include MPS_PLUGIN_DIR . 'admin/logs.php';
    }
    
    /**
     * AJAX: Sync products
     */
    public function ajax_sync_products() {
        check_ajax_referer('mps_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Yetkiniz yok.', 'marketplace-sync')));
        }
        
        $product_ids = isset($_POST['product_ids']) ? array_map('intval', $_POST['product_ids']) : array();
        $marketplace = isset($_POST['marketplace']) ? sanitize_text_field($_POST['marketplace']) : 'trendyol';
        
        if (empty($product_ids)) {
            wp_send_json_error(array('message' => __('Lütfen en az bir ürün seçin.', 'marketplace-sync')));
        }
        
        $sync = new MPS_Product_Sync();
        $results = $sync->sync_products($product_ids, $marketplace);
        
        wp_send_json_success(array(
            'message' => sprintf(__('%d ürün senkronize edildi.', 'marketplace-sync'), count($results['success'])),
            'results' => $results
        ));
    }
    
    /**
     * AJAX: Save settings
     */
    public function ajax_save_settings() {
        check_ajax_referer('mps_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Yetkiniz yok.', 'marketplace-sync')));
        }
        
        $settings = isset($_POST['settings']) ? $_POST['settings'] : array();
        
        // Sanitize settings
        $sanitized_settings = array(
            'trendyol_api_key' => sanitize_text_field($settings['trendyol_api_key'] ?? ''),
            'trendyol_api_secret' => sanitize_text_field($settings['trendyol_api_secret'] ?? ''),
            'trendyol_supplier_id' => sanitize_text_field($settings['trendyol_supplier_id'] ?? ''),
            'auto_sync' => sanitize_text_field($settings['auto_sync'] ?? 'no'),
            'sync_stock' => sanitize_text_field($settings['sync_stock'] ?? 'yes'),
            'sync_price' => sanitize_text_field($settings['sync_price'] ?? 'yes'),
        );
        
        update_option('mps_settings', $sanitized_settings);
        
        wp_send_json_success(array('message' => __('Ayarlar kaydedildi.', 'marketplace-sync')));
    }
    
    /**
     * AJAX: Test connection
     */
    public function ajax_test_connection() {
        check_ajax_referer('mps_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Yetkiniz yok.', 'marketplace-sync')));
        }
        
        $marketplace = isset($_POST['marketplace']) ? sanitize_text_field($_POST['marketplace']) : 'trendyol';
        
        $api = new MPS_API();
        $result = $api->test_connection($marketplace);
        
        if ($result['success']) {
            wp_send_json_success(array('message' => __('Bağlantı başarılı!', 'marketplace-sync')));
        } else {
            wp_send_json_error(array('message' => $result['message']));
        }
    }
}

/**
 * Initialize the plugin
 */
function marketplace_sync() {
    return Marketplace_Sync::instance();
}

// Start the plugin
marketplace_sync();
