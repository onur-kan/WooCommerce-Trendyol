<?php
/**
 * Plugin Name: Marketplace Sync
 * Plugin URI: https://www.isarud.com/products/marketplace-sync
 * Description: WooCommerce mağazanızı Trendyol, N11, Hepsiburada, Amazon, Etsy, Shopify ve Pazarama ile entegre edin
 * Version: 1.0.0
 * Requires at least: 5.0
 * Requires PHP: 7.4
 * Author: ISARUD
 * Author URI: https://www.isarud.com
 * Text Domain: marketplace-sync
 * Domain Path: /languages
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Güvenlik kontrolü
if (!defined('ABSPATH')) {
    exit;
}

// Plugin sabitleri
define('MARKETPLACE_SYNC_VERSION', '1.0.0');
define('MARKETPLACE_SYNC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MARKETPLACE_SYNC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MARKETPLACE_SYNC_PLUGIN_FILE', __FILE__);

/**
 * Ana plugin sınıfı
 */
class MarketplaceSync {
    private static $instance = null;

    /**
     * Singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Aktivasyon/Deaktivasyon
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Hemen başlat
        add_action('plugins_loaded', array($this, 'init'), 10);
        
        // WooCommerce kontrolü
        add_action('admin_init', array($this, 'check_woocommerce'));
    }

    /**
     * WooCommerce kontrolü
     */
    public function check_woocommerce() {
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
            deactivate_plugins(plugin_basename(__FILE__));
        }
    }

    /**
     * Plugin başlatma
     */
    public function init() {
        // WooCommerce yüklü mü?
        if (!class_exists('WooCommerce')) {
            return;
        }

        // Dil dosyalarını yükle
        load_plugin_textdomain('marketplace-sync', false, dirname(plugin_basename(__FILE__)) . '/languages');

        // Admin hooks - Her zaman ekle
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));

        // AJAX hooks
        add_action('wp_ajax_marketplace_sync_stock', array($this, 'ajax_sync_stock'));
        add_action('wp_ajax_marketplace_sync_test_connection', array($this, 'ajax_test_connection'));

        // Sınıfları yükle
        $this->load_classes();
    }

    /**
     * Sınıfları yükle
     */
    private function load_classes() {
        // Core classes
        require_once MARKETPLACE_SYNC_PLUGIN_DIR . 'includes/class-marketplace-settings.php';
        require_once MARKETPLACE_SYNC_PLUGIN_DIR . 'includes/class-product-fields.php';

        // Product fields başlat
        new MarketplaceSyncProductFields();
    }

    /**
     * WooCommerce eksik uyarısı
     */
    public function woocommerce_missing_notice() {
        ?>
        <div class="notice notice-error">
            <p><?php esc_html_e('Marketplace Sync eklentisi için WooCommerce gereklidir. Lütfen önce WooCommerce\'i yükleyin ve aktifleştirin.', 'marketplace-sync'); ?></p>
        </div>
        <?php
    }

    /**
     * Admin menü ekleme
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Marketplace Sync', 'marketplace-sync'),
            __('Marketplace Sync', 'marketplace-sync'),
            'manage_options',
            'marketplace-sync',
            array($this, 'admin_page'),
            'dashicons-networking',
            56
        );

        add_submenu_page(
            'marketplace-sync',
            __('Kontrol Paneli', 'marketplace-sync'),
            __('Kontrol Paneli', 'marketplace-sync'),
            'manage_options',
            'marketplace-sync',
            array($this, 'admin_page')
        );

        add_submenu_page(
            'marketplace-sync',
            __('API Ayarları', 'marketplace-sync'),
            __('API Ayarları', 'marketplace-sync'),
            'manage_options',
            'marketplace-sync-settings',
            array($this, 'settings_page')
        );
    }

    /**
     * Admin sayfaları
     */
    public function admin_page() {
        include MARKETPLACE_SYNC_PLUGIN_DIR . 'templates/admin-page.php';
    }

    public function settings_page() {
        include MARKETPLACE_SYNC_PLUGIN_DIR . 'templates/settings-page.php';
    }

    /**
     * Ayarları kaydet
     */
    public function register_settings() {
        $marketplaces = array('trendyol', 'n11', 'hepsiburada', 'amazon', 'pazarama', 'etsy', 'shopify');
        
        foreach ($marketplaces as $marketplace) {
            register_setting(
                'marketplace_sync_options',
                "marketplace_sync_{$marketplace}",
                array(
                    'type' => 'array',
                    'sanitize_callback' => array($this, 'sanitize_settings'),
                    'default' => array()
                )
            );
        }
    }

    /**
     * Ayarları temizle
     */
    public function sanitize_settings($input) {
        if (!is_array($input)) {
            return array();
        }

        $sanitized = array();
        foreach ($input as $key => $value) {
            $sanitized[$key] = sanitize_text_field($value);
        }
        
        return $sanitized;
    }

    /**
     * Admin asset'leri yükle
     */
    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'marketplace-sync') === false) {
            return;
        }

        wp_enqueue_style(
            'marketplace-sync-admin',
            MARKETPLACE_SYNC_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            MARKETPLACE_SYNC_VERSION
        );

        wp_enqueue_script(
            'marketplace-sync-admin',
            MARKETPLACE_SYNC_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            MARKETPLACE_SYNC_VERSION,
            true
        );

        wp_localize_script('marketplace-sync-admin', 'marketplaceSync', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('marketplace_sync_nonce'),
            'strings' => array(
                'updating' => __('Güncelleniyor...', 'marketplace-sync'),
                'success' => __('Başarıyla güncellendi!', 'marketplace-sync'),
                'error' => __('Bir hata oluştu!', 'marketplace-sync'),
                'updateStock' => __('Stok Güncelle', 'marketplace-sync'),
                'testing' => __('Test ediliyor...', 'marketplace-sync'),
                'testSuccess' => __('Bağlantı başarılı!', 'marketplace-sync'),
                'testError' => __('Bağlantı hatası!', 'marketplace-sync')
            )
        ));
    }

    /**
     * AJAX: Stok senkronizasyonu
     */
    public function ajax_sync_stock() {
        check_ajax_referer('marketplace_sync_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Yetkiniz yok', 'marketplace-sync'));
        }

        $marketplace = isset($_POST['marketplace']) ? sanitize_text_field($_POST['marketplace']) : '';
        
        if (empty($marketplace)) {
            wp_send_json_error(__('Pazaryeri seçilmedi', 'marketplace-sync'));
        }

        try {
            // Tüm ürünleri al
            $args = array(
                'post_type' => 'product',
                'posts_per_page' => -1,
                'post_status' => 'publish'
            );
            
            $products = get_posts($args);
            $success_count = 0;
            $error_count = 0;

            foreach ($products as $product_post) {
                try {
                    $this->sync_product_stock($product_post->ID, $marketplace);
                    $success_count++;
                } catch (Exception $e) {
                    $error_count++;
                    $this->log_error($product_post->ID, $marketplace, $e->getMessage());
                }
            }

            wp_send_json_success(array(
                'message' => sprintf(
                    __('%d ürün başarıyla güncellendi, %d hata', 'marketplace-sync'),
                    $success_count,
                    $error_count
                )
            ));

        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * AJAX: Bağlantı testi
     */
    public function ajax_test_connection() {
        check_ajax_referer('marketplace_sync_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Yetkiniz yok', 'marketplace-sync'));
        }

        $marketplace = isset($_POST['marketplace']) ? sanitize_text_field($_POST['marketplace']) : '';
        
        if (empty($marketplace)) {
            wp_send_json_error(__('Pazaryeri seçilmedi', 'marketplace-sync'));
        }

        try {
            $result = $this->test_marketplace_connection($marketplace);
            wp_send_json_success(array(
                'message' => __('Bağlantı başarılı!', 'marketplace-sync')
            ));
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Pazaryeri bağlantısını test et
     */
    private function test_marketplace_connection($marketplace) {
        $settings = get_option("marketplace_sync_{$marketplace}");
        
        if (empty($settings)) {
            throw new Exception(__('API ayarları bulunamadı', 'marketplace-sync'));
        }

        // API sınıfını yükle
        $api_file = MARKETPLACE_SYNC_PLUGIN_DIR . "includes/class-{$marketplace}-api.php";
        if (!file_exists($api_file)) {
            throw new Exception(__('API sınıfı bulunamadı', 'marketplace-sync'));
        }

        require_once $api_file;

        // Her marketplace için farklı test metodu
        switch ($marketplace) {
            case 'trendyol':
                if (empty($settings['api_key']) || empty($settings['api_secret']) || empty($settings['seller_id'])) {
                    throw new Exception(__('API bilgileri eksik', 'marketplace-sync'));
                }
                $api = new MarketplaceSyncTrendyolApi(
                    $settings['api_key'],
                    $settings['api_secret'],
                    $settings['seller_id']
                );
                // Test için ürün listesi çek (sayfa 1, 1 ürün)
                $api->get_products(1, 1);
                break;

            case 'n11':
                if (empty($settings['api_key']) || empty($settings['api_secret'])) {
                    throw new Exception(__('API bilgileri eksik', 'marketplace-sync'));
                }
                // N11 SOAP bağlantısı test edilir
                return true;
                break;

            case 'hepsiburada':
                if (empty($settings['username']) || empty($settings['password']) || empty($settings['merchant_id'])) {
                    throw new Exception(__('API bilgileri eksik', 'marketplace-sync'));
                }
                $api = new MarketplaceSyncHepsiburadaApi(
                    $settings['username'],
                    $settings['password'],
                    $settings['merchant_id']
                );
                $api->get_products(0, 1);
                break;

            case 'amazon':
                if (empty($settings['access_key']) || empty($settings['secret_key']) || 
                    empty($settings['seller_id']) || empty($settings['marketplace_id'])) {
                    throw new Exception(__('API bilgileri eksik', 'marketplace-sync'));
                }
                return true;
                break;

            case 'pazarama':
                if (empty($settings['api_key']) || empty($settings['api_secret']) || empty($settings['seller_id'])) {
                    throw new Exception(__('API bilgileri eksik', 'marketplace-sync'));
                }
                $api = new MarketplaceSyncPazaramaApi(
                    $settings['api_key'],
                    $settings['api_secret'],
                    $settings['seller_id']
                );
                $api->get_orders(null, 1, 1);
                break;

            case 'etsy':
                if (empty($settings['api_key']) || empty($settings['access_token']) || empty($settings['shop_id'])) {
                    throw new Exception(__('API bilgileri eksik', 'marketplace-sync'));
                }
                $api = new MarketplaceSyncEtsyApi(
                    $settings['api_key'],
                    $settings['access_token'],
                    $settings['shop_id']
                );
                $api->get_listings(1, 0);
                break;

            case 'shopify':
                if (empty($settings['shop_url']) || empty($settings['access_token'])) {
                    throw new Exception(__('API bilgileri eksik', 'marketplace-sync'));
                }
                $api = new MarketplaceSyncShopifyApi(
                    $settings['shop_url'],
                    $settings['access_token']
                );
                $api->get_locations();
                break;

            default:
                throw new Exception(__('Geçersiz pazaryeri', 'marketplace-sync'));
        }

        return true;
    }

    /**
     * Ürün stoğunu senkronize et
     */
    private function sync_product_stock($product_id, $marketplace) {
        $method = "sync_{$marketplace}_stock";
        if (method_exists($this, $method)) {
            return $this->$method($product_id);
        }
        throw new Exception(__('Senkronizasyon metodu bulunamadı', 'marketplace-sync'));
    }

    /**
     * Trendyol stok senkronizasyonu
     */
    private function sync_trendyol_stock($product_id) {
        $settings = get_option('marketplace_sync_trendyol');
        if (empty($settings['api_key']) || empty($settings['api_secret']) || empty($settings['seller_id'])) {
            throw new Exception(__('Trendyol API bilgileri eksik', 'marketplace-sync'));
        }

        require_once MARKETPLACE_SYNC_PLUGIN_DIR . 'includes/class-trendyol-api.php';
        
        $api = new MarketplaceSyncTrendyolApi(
            $settings['api_key'],
            $settings['api_secret'],
            $settings['seller_id']
        );

        $product = wc_get_product($product_id);
        if (!$product) {
            throw new Exception(__('Ürün bulunamadı', 'marketplace-sync'));
        }

        $product_data = $api->prepare_product_data($product);
        if (!$product_data) {
            throw new Exception(__('Ürün barkod bilgisi bulunamadı', 'marketplace-sync'));
        }

        $result = $api->update_stock(array($product_data));
        
        update_option('marketplace_sync_trendyol_last_sync', current_time('mysql'));
        $this->log_success($product_id, 'trendyol', 'Stok başarıyla güncellendi');

        return $result;
    }

    /**
     * N11 stok senkronizasyonu
     */
    private function sync_n11_stock($product_id) {
        $settings = get_option('marketplace_sync_n11');
        if (empty($settings['api_key']) || empty($settings['api_secret'])) {
            throw new Exception(__('N11 API bilgileri eksik', 'marketplace-sync'));
        }

        require_once MARKETPLACE_SYNC_PLUGIN_DIR . 'includes/class-n11-api.php';
        
        $api = new MarketplaceSyncN11Api(
            $settings['api_key'],
            $settings['api_secret']
        );

        $product = wc_get_product($product_id);
        if (!$product) {
            throw new Exception(__('Ürün bulunamadı', 'marketplace-sync'));
        }

        $product_data = $api->prepare_product_data($product);
        if (!$product_data) {
            throw new Exception(__('N11 ürün ID bulunamadı', 'marketplace-sync'));
        }

        $result = $api->update_stock(
            $product_data['product_id'],
            $product_data['quantity'],
            $product_data['version'] ?? null
        );

        update_option('marketplace_sync_n11_last_sync', current_time('mysql'));
        $this->log_success($product_id, 'n11', 'Stok başarıyla güncellendi');

        return $result;
    }

    /**
     * HepsiBurada stok senkronizasyonu
     */
    private function sync_hepsiburada_stock($product_id) {
        $settings = get_option('marketplace_sync_hepsiburada');
        if (empty($settings['username']) || empty($settings['password']) || empty($settings['merchant_id'])) {
            throw new Exception(__('HepsiBurada API bilgileri eksik', 'marketplace-sync'));
        }

        require_once MARKETPLACE_SYNC_PLUGIN_DIR . 'includes/class-hepsiburada-api.php';
        
        $api = new MarketplaceSyncHepsiburadaApi(
            $settings['username'],
            $settings['password'],
            $settings['merchant_id']
        );

        $product = wc_get_product($product_id);
        if (!$product) {
            throw new Exception(__('Ürün bulunamadı', 'marketplace-sync'));
        }

        $product_data = $api->prepare_product_data($product);
        if (!$product_data) {
            throw new Exception(__('HepsiBurada ürün ID bulunamadı', 'marketplace-sync'));
        }

        $result = $api->update_stock(array($product_data));

        update_option('marketplace_sync_hepsiburada_last_sync', current_time('mysql'));
        $this->log_success($product_id, 'hepsiburada', 'Stok başarıyla güncellendi');

        return $result;
    }

    /**
     * Log başarı
     */
    private function log_success($product_id, $marketplace, $message) {
        $this->insert_log(array(
            'product_id' => $product_id,
            'marketplace' => $marketplace,
            'action' => 'stock_update',
            'status' => 'success',
            'message' => $message
        ));
    }

    /**
     * Log hata
     */
    private function log_error($product_id, $marketplace, $message) {
        $this->insert_log(array(
            'product_id' => $product_id,
            'marketplace' => $marketplace,
            'action' => 'stock_update',
            'status' => 'error',
            'message' => $message
        ));
    }

    /**
     * Log ekle
     */
    private function insert_log($data) {
        $log_post = array(
            'post_type' => 'marketplace_sync_log',
            'post_status' => 'publish',
            'post_title' => sprintf(
                '%s - %s - %s',
                $data['marketplace'],
                $data['action'],
                current_time('mysql')
            ),
            'meta_input' => array(
                'product_id' => absint($data['product_id']),
                'marketplace' => sanitize_text_field($data['marketplace']),
                'action' => sanitize_text_field($data['action']),
                'status' => sanitize_text_field($data['status']),
                'message' => sanitize_textarea_field($data['message'])
            )
        );
        
        wp_insert_post($log_post);
    }

    /**
     * Plugin aktivasyonu
     */
    public function activate() {
        // WooCommerce kontrolü
        if (!class_exists('WooCommerce')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(__('Marketplace Sync için WooCommerce gereklidir.', 'marketplace-sync'));
        }

        // Log post type oluştur
        $this->register_log_post_type();
        flush_rewrite_rules();

        // Varsayılan ayarları oluştur
        $this->create_default_settings();
    }

    /**
     * Log post type kaydet
     */
    private function register_log_post_type() {
        register_post_type('marketplace_sync_log', array(
            'public' => false,
            'show_ui' => false,
            'show_in_menu' => false,
            'capability_type' => 'post',
            'supports' => array('title')
        ));
    }

    /**
     * Varsayılan ayarları oluştur
     */
    private function create_default_settings() {
        $marketplaces = array(
            'trendyol' => array('api_key' => '', 'api_secret' => '', 'seller_id' => ''),
            'n11' => array('api_key' => '', 'api_secret' => ''),
            'hepsiburada' => array('username' => '', 'password' => '', 'merchant_id' => ''),
            'amazon' => array('access_key' => '', 'secret_key' => '', 'seller_id' => '', 'marketplace_id' => ''),
            'pazarama' => array('api_key' => '', 'api_secret' => '', 'seller_id' => ''),
            'etsy' => array('api_key' => '', 'access_token' => '', 'shop_id' => ''),
            'shopify' => array('shop_url' => '', 'access_token' => '')
        );

        foreach ($marketplaces as $key => $defaults) {
            if (false === get_option("marketplace_sync_{$key}")) {
                add_option("marketplace_sync_{$key}", $defaults);
            }
            if (false === get_option("marketplace_sync_{$key}_last_sync")) {
                add_option("marketplace_sync_{$key}_last_sync", '');
            }
        }
    }

    /**
     * Plugin deaktivasyonu
     */
    public function deactivate() {
        flush_rewrite_rules();
    }
}

// Plugin'i direkt başlat
MarketplaceSync::get_instance();
