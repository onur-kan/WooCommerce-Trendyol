<?php 
if (!defined('ABSPATH')) {
    exit;
}

require_once MARKETPLACE_SYNC_PLUGIN_DIR . 'includes/class-marketplace-settings.php';

$marketplaces = MarketplaceSyncSettings::get_marketplaces();
?>
<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="notice notice-info is-dismissible">
        <p><?php esc_html_e('Tüm pazaryeri entegrasyonlarınızı bu sayfadan yönetebilirsiniz.', 'marketplace-sync'); ?></p>
    </div>

    <div class="card">
        <h2><?php esc_html_e('Pazaryeri Entegrasyonları', 'marketplace-sync'); ?></h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php esc_html_e('Pazaryeri', 'marketplace-sync'); ?></th>
                    <th><?php esc_html_e('Durum', 'marketplace-sync'); ?></th>
                    <th><?php esc_html_e('Son Senkronizasyon', 'marketplace-sync'); ?></th>
                    <th><?php esc_html_e('İşlemler', 'marketplace-sync'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($marketplaces as $key => $marketplace) :
                    $settings = get_option("marketplace_sync_{$key}");
                    
                    // Aktif durumunu kontrol et
                    $is_active = false;
                    if ($key === 'etsy') {
                        $is_active = !empty($settings['api_key']) && !empty($settings['access_token']) && !empty($settings['shop_id']);
                    } elseif ($key === 'shopify') {
                        $is_active = !empty($settings['shop_url']) && !empty($settings['access_token']);
                    } elseif ($key === 'hepsiburada') {
                        $is_active = !empty($settings['username']) && !empty($settings['password']) && !empty($settings['merchant_id']);
                    } elseif ($key === 'amazon') {
                        $is_active = !empty($settings['access_key']) && !empty($settings['secret_key']) && 
                                    !empty($settings['seller_id']) && !empty($settings['marketplace_id']);
                    } else {
                        $is_active = !empty($settings['api_key']) && !empty($settings['api_secret']);
                        if ($key === 'trendyol' || $key === 'pazarama') {
                            $is_active = $is_active && !empty($settings['seller_id']);
                        }
                    }
                    
                    $last_sync = get_option("marketplace_sync_{$key}_last_sync");
                ?>
                <tr>
                    <td><strong><?php echo esc_html($marketplace['name']); ?></strong></td>
                    <td>
                        <span class="status-<?php echo $is_active ? 'active' : 'inactive'; ?>">
                            <?php echo $is_active ? esc_html__('Aktif', 'marketplace-sync') : esc_html__('Pasif', 'marketplace-sync'); ?>
                        </span>
                    </td>
                    <td>
                        <?php 
                        if ($last_sync) {
                            echo esc_html(date_i18n('d.m.Y H:i:s', strtotime($last_sync)));
                        } else {
                            echo '-';
                        }
                        ?>
                    </td>
                    <td>
                        <?php if ($is_active) : ?>
                            <button class="button sync-stock" 
                                    data-marketplace="<?php echo esc_attr($key); ?>">
                                <?php esc_html_e('Ürünleri Senkronize Et', 'marketplace-sync'); ?>
                            </button>
                        <?php else : ?>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=marketplace-sync-settings')); ?>" 
                               class="button button-secondary">
                                <?php esc_html_e('API Ayarlarını Yapılandır', 'marketplace-sync'); ?>
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="card">
        <h2><?php esc_html_e('Son İşlem Logları', 'marketplace-sync'); ?></h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php esc_html_e('Tarih', 'marketplace-sync'); ?></th>
                    <th><?php esc_html_e('Pazaryeri', 'marketplace-sync'); ?></th>
                    <th><?php esc_html_e('İşlem', 'marketplace-sync'); ?></th>
                    <th><?php esc_html_e('Durum', 'marketplace-sync'); ?></th>
                    <th><?php esc_html_e('Mesaj', 'marketplace-sync'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php
                $logs = new WP_Query(array(
                    'post_type' => 'marketplace_sync_log',
                    'posts_per_page' => 20,
                    'orderby' => 'date',
                    'order' => 'DESC'
                ));

                if ($logs->have_posts()) :
                    while ($logs->have_posts()) : $logs->the_post();
                        $product_id = get_post_meta(get_the_ID(), 'product_id', true);
                        $marketplace = get_post_meta(get_the_ID(), 'marketplace', true);
                        $action = get_post_meta(get_the_ID(), 'action', true);
                        $status = get_post_meta(get_the_ID(), 'status', true);
                        $message = get_post_meta(get_the_ID(), 'message', true);
                ?>
                <tr>
                    <td><?php echo esc_html(get_the_date('d.m.Y H:i:s')); ?></td>
                    <td><?php echo esc_html(ucfirst($marketplace)); ?></td>
                    <td><?php echo esc_html($action); ?></td>
                    <td>
                        <span class="status-<?php echo esc_attr($status); ?>">
                            <?php echo $status === 'success' ? esc_html__('Başarılı', 'marketplace-sync') : esc_html__('Hata', 'marketplace-sync'); ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($product_id) : ?>
                            <a href="<?php echo esc_url(get_edit_post_link($product_id)); ?>" target="_blank">
                                #<?php echo esc_html($product_id); ?>
                            </a> - 
                        <?php endif; ?>
                        <?php echo esc_html($message); ?>
                    </td>
                </tr>
                <?php 
                    endwhile;
                    wp_reset_postdata();
                else :
                ?>
                <tr>
                    <td colspan="5" style="text-align: center;">
                        <?php esc_html_e('Henüz log kaydı bulunmuyor.', 'marketplace-sync'); ?>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="card">
        <h2><?php esc_html_e('Hızlı İşlemler', 'marketplace-sync'); ?></h2>
        <div class="quick-actions">
            <a href="<?php echo esc_url(admin_url('admin.php?page=marketplace-sync-settings')); ?>" 
               class="button button-primary button-large">
                <?php esc_html_e('API Ayarlarını Yönet', 'marketplace-sync'); ?>
            </a>
            <a href="<?php echo esc_url(admin_url('edit.php?post_type=product')); ?>" 
               class="button button-secondary button-large">
                <?php esc_html_e('Ürünleri Yönet', 'marketplace-sync'); ?>
            </a>
        </div>
    </div>

    <div class="card">
        <h2><?php esc_html_e('Destek ve Güncellemeler', 'marketplace-sync'); ?></h2>
        <div class="support-links">
            <div class="link-box">
                <h3><?php esc_html_e('Son Güncellemeler', 'marketplace-sync'); ?></h3>
                <p><?php esc_html_e('Eklentinin son sürümü ve yenilikler hakkında bilgi alın.', 'marketplace-sync'); ?></p>
                <a href="https://www.isarud.com/products/marketplace-sync" target="_blank" class="button button-secondary">
                    <?php esc_html_e('Güncellemeleri Görüntüle', 'marketplace-sync'); ?>
                </a>
            </div>
            <div class="link-box">
                <h3><?php esc_html_e('Bağış Yapın', 'marketplace-sync'); ?></h3>
                <p><?php esc_html_e('Eklentinin geliştirilmesine destek olun.', 'marketplace-sync'); ?></p>
                <a href="https://donate.stripe.com/dR69Dl5HqcsR3N65kl" target="_blank" class="button button-primary">
                    <?php esc_html_e('Bağış Yap', 'marketplace-sync'); ?>
                </a>
            </div>
        </div>
    </div>
</div>

<style>
.quick-actions {
    display: flex;
    gap: 15px;
    padding: 15px 0;
}
.quick-actions .button-large {
    padding: 10px 20px;
    height: auto;
    font-size: 14px;
}
</style>
