<?php
if (!defined('ABSPATH')) {
    exit;
}

require_once MARKETPLACE_SYNC_PLUGIN_DIR . 'includes/class-marketplace-settings.php';

$marketplaces = MarketplaceSyncSettings::get_marketplaces();

// Ayarlar kaydedildi mi?
$settings_updated = false;
if (isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true') {
    $settings_updated = true;
}
?>
<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <?php if ($settings_updated) : ?>
    <div class="notice notice-success is-dismissible">
        <p><?php esc_html_e('Ayarlar başarıyla kaydedildi!', 'marketplace-sync'); ?></p>
    </div>
    <?php endif; ?>
    
    <form id="marketplace-sync-settings-form" method="post" action="options.php">
        <?php 
        settings_fields('marketplace_sync_options'); 
        do_settings_sections('marketplace_sync_options'); 
        ?>

        <?php foreach ($marketplaces as $key => $marketplace) :
            $options = get_option("marketplace_sync_{$key}", array());
            
            // Aktif durumunu kontrol et
            $is_active = false;
            if ($key === 'etsy') {
                $is_active = !empty($options['api_key']) && !empty($options['access_token']) && !empty($options['shop_id']);
            } elseif ($key === 'shopify') {
                $is_active = !empty($options['shop_url']) && !empty($options['access_token']);
            } elseif ($key === 'hepsiburada') {
                $is_active = !empty($options['username']) && !empty($options['password']) && !empty($options['merchant_id']);
            } elseif ($key === 'amazon') {
                $is_active = !empty($options['access_key']) && !empty($options['secret_key']) && 
                            !empty($options['seller_id']) && !empty($options['marketplace_id']);
            } else {
                $is_active = !empty($options['api_key']) && !empty($options['api_secret']);
                if ($key === 'trendyol' || $key === 'pazarama') {
                    $is_active = $is_active && !empty($options['seller_id']);
                }
            }
        ?>
        <div class="card">
            <div class="card-header">
                <h2>
                    <?php echo esc_html($marketplace['name']); ?> 
                    <?php esc_html_e('API Ayarları', 'marketplace-sync'); ?>
                    <span class="status-indicator <?php echo $is_active ? 'active' : 'inactive'; ?>">
                        <?php echo $is_active ? esc_html__('Aktif', 'marketplace-sync') : esc_html__('Pasif', 'marketplace-sync'); ?>
                    </span>
                    <?php if ($is_active) : ?>
                    <button type="button" class="button button-small test-connection" 
                            data-marketplace="<?php echo esc_attr($key); ?>"
                            style="margin-left: 10px;">
                        <?php esc_html_e('Bağlantıyı Test Et', 'marketplace-sync'); ?>
                    </button>
                    <?php endif; ?>
                </h2>
            </div>
            <table class="form-table">
                <?php foreach ($marketplace['fields'] as $field_key => $field) : 
                    $field_id = esc_attr("marketplace_sync_{$key}_{$field_key}");
                    $field_name = esc_attr("marketplace_sync_{$key}[{$field_key}]");
                    $field_value = isset($options[$field_key]) ? $options[$field_key] : '';
                ?>
                <tr>
                    <th scope="row">
                        <label for="<?php echo $field_id; ?>">
                            <?php echo esc_html($field['label']); ?>
                        </label>
                    </th>
                    <td>
                        <input type="<?php echo esc_attr($field['type']); ?>"
                               name="<?php echo $field_name; ?>"
                               id="<?php echo $field_id; ?>"
                               value="<?php echo esc_attr($field_value); ?>"
                               class="regular-text"
                               autocomplete="off">
                        <p class="description"><?php echo esc_html($field['desc']); ?></p>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php endforeach; ?>

        <?php submit_button(esc_html__('Ayarları Kaydet', 'marketplace-sync'), 'primary', 'submit', true); ?>
    </form>

    <div class="card" style="margin-top: 20px;">
        <h2><?php esc_html_e('API Bağlantı Bilgileri', 'marketplace-sync'); ?></h2>
        <div class="api-info">
            <h3><?php esc_html_e('API Anahtarlarını Nereden Bulabilirim?', 'marketplace-sync'); ?></h3>
            
            <ul>
                <li><strong>Trendyol:</strong> <a href="https://partner.trendyol.com" target="_blank">Trendyol Seller Center</a> → Entegrasyonlar → API Ayarları</li>
                <li><strong>N11:</strong> <a href="https://www.n11.com/hesabim/magaza-yonetimi-api" target="_blank">N11 Mağaza Yönetimi</a> → API → API Bilgileri</li>
                <li><strong>HepsiBurada:</strong> <a href="https://merchant.hepsiburada.com" target="_blank">HepsiBurada Merchant Portal</a> → Entegrasyon → API</li>
                <li><strong>Amazon:</strong> <a href="https://sellercentral.amazon.com.tr" target="_blank">Amazon Seller Central</a> → Ayarlar → Kullanıcı İzinleri → MWS API</li>
                <li><strong>Pazarama:</strong> <a href="https://seller.pazarama.com" target="_blank">Pazarama Seller</a> → Entegrasyon → API</li>
                <li><strong>Etsy:</strong> <a href="https://www.etsy.com/developers" target="_blank">Etsy Developers</a> → Apps → Create New App</li>
                <li><strong>Shopify:</strong> <a href="https://admin.shopify.com" target="_blank">Shopify Admin</a> → Apps → Develop Apps → Create Private App</li>
            </ul>
        </div>
    </div>
</div>
