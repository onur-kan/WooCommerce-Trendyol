/**
 * Marketplace Sync Admin JavaScript
 */

(function($) {
    'use strict';
    
    var MarketplaceSync = {
        
        init: function() {
            this.bindEvents();
        },
        
        bindEvents: function() {
            // Product sync
            $(document).on('click', '.mps-sync-product', this.syncProduct);
            $(document).on('click', '.mps-sync-selected', this.syncSelected);
            
            // Test connection
            $(document).on('click', '#mps-test-connection', this.testConnection);
            
            // Log details toggle
            $(document).on('click', '.mps-view-details', this.toggleDetails);
        },
        
        /**
         * Sync single product
         */
        syncProduct: function(e) {
            e.preventDefault();
            
            var $btn = $(this);
            var productId = $btn.data('product-id');
            var marketplace = $btn.data('marketplace') || 'trendyol';
            
            if (!confirm(mpsAdmin.i18n.confirm_sync)) {
                return;
            }
            
            $btn.prop('disabled', true).text(mpsAdmin.i18n.syncing);
            
            $.ajax({
                url: mpsAdmin.ajax_url,
                type: 'POST',
                data: {
                    action: 'mps_sync_products',
                    product_ids: [productId],
                    marketplace: marketplace,
                    nonce: mpsAdmin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        MarketplaceSync.showNotice('success', response.data.message);
                    } else {
                        MarketplaceSync.showNotice('error', response.data.message);
                    }
                },
                error: function() {
                    MarketplaceSync.showNotice('error', mpsAdmin.i18n.error);
                },
                complete: function() {
                    $btn.prop('disabled', false).text($btn.data('original-text'));
                }
            });
        },
        
        /**
         * Sync selected products
         */
        syncSelected: function(e) {
            e.preventDefault();
            
            var $btn = $(this);
            var productIds = [];
            var marketplace = $btn.data('marketplace') || 'trendyol';
            
            $('.mps-product-checkbox:checked').each(function() {
                productIds.push($(this).val());
            });
            
            if (productIds.length === 0) {
                alert('Lütfen en az bir ürün seçin.');
                return;
            }
            
            if (!confirm(mpsAdmin.i18n.confirm_sync)) {
                return;
            }
            
            $btn.prop('disabled', true).text(mpsAdmin.i18n.syncing);
            
            $.ajax({
                url: mpsAdmin.ajax_url,
                type: 'POST',
                data: {
                    action: 'mps_sync_products',
                    product_ids: productIds,
                    marketplace: marketplace,
                    nonce: mpsAdmin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        MarketplaceSync.showNotice('success', response.data.message);
                        if (response.data.results) {
                            MarketplaceSync.showSyncResults(response.data.results);
                        }
                    } else {
                        MarketplaceSync.showNotice('error', response.data.message);
                    }
                },
                error: function() {
                    MarketplaceSync.showNotice('error', mpsAdmin.i18n.error);
                },
                complete: function() {
                    $btn.prop('disabled', false).text($btn.data('original-text'));
                }
            });
        },
        
        /**
         * Test API connection
         */
        testConnection: function(e) {
            e.preventDefault();
            
            var $btn = $(this);
            var marketplace = $btn.data('marketplace') || 'trendyol';
            var originalText = $btn.text();
            
            $btn.prop('disabled', true).text('Test ediliyor...');
            
            $.ajax({
                url: mpsAdmin.ajax_url,
                type: 'POST',
                data: {
                    action: 'mps_test_connection',
                    marketplace: marketplace,
                    nonce: mpsAdmin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        MarketplaceSync.showNotice('success', response.data.message);
                    } else {
                        MarketplaceSync.showNotice('error', response.data.message);
                    }
                },
                error: function() {
                    MarketplaceSync.showNotice('error', 'Bir hata oluştu.');
                },
                complete: function() {
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        },
        
        /**
         * Toggle log details
         */
        toggleDetails: function(e) {
            e.preventDefault();
            
            var $btn = $(this);
            var logId = $btn.data('log-id');
            var $detailsRow = $('#mps-log-' + logId);
            
            $detailsRow.toggle();
            
            if ($detailsRow.is(':visible')) {
                $btn.text('Gizle');
            } else {
                $btn.text('Detay');
            }
        },
        
        /**
         * Show sync results
         */
        showSyncResults: function(results) {
            var message = 'Senkronizasyon Sonuçları:\n\n';
            message += 'Başarılı: ' + results.success.length + '\n';
            
            if (results.failed.length > 0) {
                message += 'Hatalı: ' + results.failed.length + '\n\n';
                message += 'Hatalı Ürünler:\n';
                results.failed.forEach(function(item) {
                    message += '- #' + item.product_id + ': ' + item.message + '\n';
                });
            }
            
            alert(message);
        },
        
        /**
         * Show admin notice
         */
        showNotice: function(type, message) {
            var noticeClass = 'notice-' + type;
            var $notice = $('<div class="notice ' + noticeClass + ' is-dismissible"><p>' + message + '</p></div>');
            
            $('.wrap h1').after($notice);
            
            // Auto dismiss after 5 seconds
            setTimeout(function() {
                $notice.fadeOut(function() {
                    $(this).remove();
                });
            }, 5000);
            
            // Make dismissible
            $(document).trigger('wp-updates-notice-added');
        }
    };
    
    // Initialize on document ready
    $(document).ready(function() {
        MarketplaceSync.init();
    });
    
})(jQuery);
