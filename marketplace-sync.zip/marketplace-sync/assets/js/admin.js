jQuery(document).ready(function($) {
    'use strict';

    // Stok senkronizasyonu
    $('.sync-stock').on('click', function(e) {
        e.preventDefault();
        
        var button = $(this);
        var marketplace = button.data('marketplace');
        var originalText = button.text();
        
        // Buton durumunu değiştir
        button.prop('disabled', true)
              .text(marketplaceSync.strings.updating);
        
        $.ajax({
            url: marketplaceSync.ajaxurl,
            type: 'POST',
            data: {
                action: 'marketplace_sync_stock',
                marketplace: marketplace,
                nonce: marketplaceSync.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Başarılı mesajı göster
                    showNotice('success', response.data.message || marketplaceSync.strings.success);
                    
                    // Sayfayı 2 saniye sonra yenile
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    showNotice('error', response.data || marketplaceSync.strings.error);
                    button.prop('disabled', false).text(originalText);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('AJAX Error:', textStatus, errorThrown);
                showNotice('error', marketplaceSync.strings.error + ': ' + textStatus);
                button.prop('disabled', false).text(originalText);
            }
        });
    });

    // Bağlantı testi
    $('.test-connection').on('click', function(e) {
        e.preventDefault();
        
        var button = $(this);
        var marketplace = button.data('marketplace');
        var originalText = button.text();
        
        button.prop('disabled', true)
              .text(marketplaceSync.strings.testing);
        
        $.ajax({
            url: marketplaceSync.ajaxurl,
            type: 'POST',
            data: {
                action: 'marketplace_sync_test_connection',
                marketplace: marketplace,
                nonce: marketplaceSync.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data.message || marketplaceSync.strings.testSuccess);
                } else {
                    showNotice('error', response.data || marketplaceSync.strings.testError);
                }
                button.prop('disabled', false).text(originalText);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('AJAX Error:', textStatus, errorThrown);
                showNotice('error', marketplaceSync.strings.testError + ': ' + textStatus);
                button.prop('disabled', false).text(originalText);
            }
        });
    });

    // Bildirim göster
    function showNotice(type, message) {
        var noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
        var notice = $('<div class="notice ' + noticeClass + ' is-dismissible"><p>' + message + '</p></div>');
        
        $('.wrap h1').after(notice);
        
        // Kapatma butonu ekle
        notice.append('<button type="button" class="notice-dismiss"><span class="screen-reader-text">Bildirimi kapat</span></button>');
        
        // Kapatma işlevi
        notice.find('.notice-dismiss').on('click', function() {
            notice.fadeOut(function() {
                $(this).remove();
            });
        });
        
        // 5 saniye sonra otomatik kapat (sadece başarılı mesajlar için)
        if (type === 'success') {
            setTimeout(function() {
                notice.fadeOut(function() {
                    $(this).remove();
                });
            }, 5000);
        }
    }

    // Form kaydetme uyarısı
    $('#marketplace-sync-settings-form').on('submit', function() {
        var button = $(this).find('input[type="submit"]');
        button.prop('disabled', true).val(marketplaceSync.strings.updating);
    });
});
