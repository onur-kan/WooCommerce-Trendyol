<?php
/**
 * Logs Page
 */

if (!defined('ABSPATH')) {
    exit;
}

$logger = new MPS_Logger();

// Pagination
$per_page = 50;
$current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$offset = ($current_page - 1) * $per_page;

// Filters
$filters = array();
if (!empty($_GET['marketplace'])) {
    $filters['marketplace'] = sanitize_text_field($_GET['marketplace']);
}
if (!empty($_GET['status'])) {
    $filters['status'] = sanitize_text_field($_GET['status']);
}

// Get logs
$logs = $logger->get_logs($per_page, $offset, $filters);
$total_logs = $logger->get_log_count($filters);
$total_pages = ceil($total_logs / $per_page);

?>

<div class="wrap">
    <h1><?php _e('Marketplace Sync - Senkronizasyon Logları', 'marketplace-sync'); ?></h1>
    
    <!-- Filters -->
    <div class="mps-filters">
        <form method="get">
            <input type="hidden" name="page" value="marketplace-sync-logs">
            
            <select name="marketplace">
                <option value=""><?php _e('Tüm Marketplace\'ler', 'marketplace-sync'); ?></option>
                <option value="trendyol" <?php selected($filters['marketplace'] ?? '', 'trendyol'); ?>>Trendyol</option>
                <option value="system" <?php selected($filters['marketplace'] ?? '', 'system'); ?>>System</option>
            </select>
            
            <select name="status">
                <option value=""><?php _e('Tüm Durumlar', 'marketplace-sync'); ?></option>
                <option value="success" <?php selected($filters['status'] ?? '', 'success'); ?>><?php _e('Başarılı', 'marketplace-sync'); ?></option>
                <option value="failed" <?php selected($filters['status'] ?? '', 'failed'); ?>><?php _e('Hatalı', 'marketplace-sync'); ?></option>
                <option value="info" <?php selected($filters['status'] ?? '', 'info'); ?>><?php _e('Bilgi', 'marketplace-sync'); ?></option>
            </select>
            
            <button type="submit" class="button"><?php _e('Filtrele', 'marketplace-sync'); ?></button>
            <a href="<?php echo admin_url('admin.php?page=marketplace-sync-logs'); ?>" class="button"><?php _e('Temizle', 'marketplace-sync'); ?></a>
        </form>
    </div>
    
    <!-- Logs Table -->
    <?php if (!empty($logs)): ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th width="140"><?php _e('Tarih', 'marketplace-sync'); ?></th>
                    <th width="200"><?php _e('Ürün', 'marketplace-sync'); ?></th>
                    <th width="100"><?php _e('Marketplace', 'marketplace-sync'); ?></th>
                    <th width="120"><?php _e('İşlem', 'marketplace-sync'); ?></th>
                    <th width="80"><?php _e('Durum', 'marketplace-sync'); ?></th>
                    <th><?php _e('Mesaj', 'marketplace-sync'); ?></th>
                    <th width="80"><?php _e('Detay', 'marketplace-sync'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($log->created_at)); ?></td>
                        <td>
                            <?php if ($log->product_id > 0): ?>
                                <a href="<?php echo get_edit_post_link($log->product_id); ?>" target="_blank">
                                    <?php echo get_the_title($log->product_id) ?: '#' . $log->product_id; ?>
                                </a>
                            <?php else: ?>
                                <span class="mps-system-log">System</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html(ucfirst($log->marketplace)); ?></td>
                        <td><?php echo esc_html($log->action); ?></td>
                        <td>
                            <span class="mps-status mps-status-<?php echo esc_attr($log->status); ?>">
                                <?php 
                                $status_labels = array(
                                    'success' => __('Başarılı', 'marketplace-sync'),
                                    'failed' => __('Hatalı', 'marketplace-sync'),
                                    'info' => __('Bilgi', 'marketplace-sync'),
                                );
                                echo esc_html($status_labels[$log->status] ?? ucfirst($log->status)); 
                                ?>
                            </span>
                        </td>
                        <td><?php echo esc_html($log->message); ?></td>
                        <td>
                            <?php if ($log->request_data || $log->response_data): ?>
                                <button type="button" class="button button-small mps-view-details" data-log-id="<?php echo $log->id; ?>">
                                    <?php _e('Detay', 'marketplace-sync'); ?>
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    
                    <!-- Details Row (Hidden) -->
                    <?php if ($log->request_data || $log->response_data): ?>
                        <tr class="mps-log-details" id="mps-log-<?php echo $log->id; ?>" style="display: none;">
                            <td colspan="7">
                                <div class="mps-details-content">
                                    <?php if ($log->request_data): ?>
                                        <div class="mps-details-section">
                                            <h4><?php _e('Request Data:', 'marketplace-sync'); ?></h4>
                                            <pre><?php echo esc_html(json_encode(json_decode($log->request_data), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); ?></pre>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($log->response_data): ?>
                                        <div class="mps-details-section">
                                            <h4><?php _e('Response Data:', 'marketplace-sync'); ?></h4>
                                            <pre><?php echo esc_html(json_encode(json_decode($log->response_data), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); ?></pre>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <div class="tablenav">
                <div class="tablenav-pages">
                    <?php
                    echo paginate_links(array(
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => __('&laquo;'),
                        'next_text' => __('&raquo;'),
                        'total' => $total_pages,
                        'current' => $current_page
                    ));
                    ?>
                </div>
            </div>
        <?php endif; ?>
        
    <?php else: ?>
        <div class="mps-empty-state">
            <p><?php _e('Henüz log kaydı bulunmuyor.', 'marketplace-sync'); ?></p>
        </div>
    <?php endif; ?>
</div>

<style>
.mps-filters {
    background: #fff;
    padding: 15px;
    margin: 20px 0;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.mps-filters form {
    display: flex;
    gap: 10px;
    align-items: center;
}

.mps-filters select {
    max-width: 200px;
}

.mps-status {
    padding: 3px 8px;
    border-radius: 3px;
    font-size: 11px;
    font-weight: bold;
    display: inline-block;
}

.mps-status-success {
    background: #d4edda;
    color: #155724;
}

.mps-status-failed {
    background: #f8d7da;
    color: #721c24;
}

.mps-status-info {
    background: #d1ecf1;
    color: #0c5460;
}

.mps-system-log {
    color: #999;
    font-style: italic;
}

.mps-log-details {
    background: #f9f9f9;
}

.mps-details-content {
    padding: 15px;
}

.mps-details-section {
    margin-bottom: 15px;
}

.mps-details-section h4 {
    margin: 0 0 10px 0;
    color: #666;
}

.mps-details-section pre {
    background: #fff;
    border: 1px solid #ddd;
    padding: 10px;
    border-radius: 3px;
    overflow-x: auto;
    max-height: 300px;
    font-size: 12px;
}

.mps-empty-state {
    background: #fff;
    padding: 40px;
    text-align: center;
    border: 1px solid #ddd;
    border-radius: 4px;
    margin: 20px 0;
}

.mps-empty-state p {
    color: #666;
    font-size: 16px;
}
</style>

<script>
jQuery(document).ready(function($) {
    $('.mps-view-details').on('click', function() {
        var logId = $(this).data('log-id');
        var $detailsRow = $('#mps-log-' + logId);
        
        $detailsRow.toggle();
        
        if ($detailsRow.is(':visible')) {
            $(this).text('<?php _e('Gizle', 'marketplace-sync'); ?>');
        } else {
            $(this).text('<?php _e('Detay', 'marketplace-sync'); ?>');
        }
    });
});
</script>
