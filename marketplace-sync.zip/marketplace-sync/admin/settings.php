<?php
/**
 * Settings Page
 */

if (!defined('ABSPATH')) {
    exit;
}

$settings = new MPS_Settings();
$current_settings = $settings->get_all();

// Handle form submission
if (isset($_POST['mps_save_settings']) && check_admin_referer('mps_settings')) {
    $new_settings = array(
        'trendyol_api_key' => sanitize_text_field($_POST['trendyol_api_key'] ?? ''),
        'trendyol_api_secret' => sanitize_text_field($_POST['trendyol_api_secret'] ?? ''),
        'trendyol_supplier_id' => sanitize_text_field($_POST['trendyol_supplier_id'] ?? ''),
        'auto_sync' => isset($_POST['auto_sync']) ? 'yes' : 'no',
        'sync_stock' => isset($_POST['sync_stock']) ? 'yes' : 'no',
        'sync_price' => isset($_POST['sync_price']) ? 'yes' : 'no',
    );
    
    $settings->update($new_settings);
    $current_settings = $new_settings;
    
    echo '<div class="notice notice-success is-dismissible"><p>' . __('Ayarlar kaydedildi.', 'marketplace-sync') . '</p></div>';
}

?>

<div class="wrap">
    <h1><?php _e('Marketplace Sync - Ayarlar', 'marketplace-sync'); ?></h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('mps_settings'); ?>
        
        <div class="mps-settings">
            <!-- Trendyol Settings -->
            <div class="mps-card">
                <h2>🛒 <?php _e('Trendyol Ayarları', 'marketplace-sync'); ?></h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="trendyol_api_key"><?php _e('API Key', 'marketplace-sync'); ?></label>
                        </th>
                        <td>
                            <input type="text" 
                                   name="trendyol_api_key" 
                                   id="trendyol_api_key" 
                                   value="<?php echo esc_attr($current_settings['trendyol_api_key'] ?? ''); ?>" 
                                   class="regular-text">
                            <p class="description">
                                <?php _e('Trendyol API Key\'inizi girin.', 'marketplace-sync'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="trendyol_api_secret"><?php _e('API Secret', 'marketplace-sync'); ?></label>
                        </th>
                        <td>
                            <input type="password" 
                                   name="trendyol_api_secret" 
                                   id="trendyol_api_secret" 
                                   value="<?php echo esc_attr($current_settings['trendyol_api_secret'] ?? ''); ?>" 
                                   class="regular-text">
                            <p class="description">
                                <?php _e('Trendyol API Secret\'ınızı girin.', 'marketplace-sync'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="trendyol_supplier_id"><?php _e('Supplier ID', 'marketplace-sync'); ?></label>
                        </th>
                        <td>
                            <input type="text" 
                                   name="trendyol_supplier_id" 
                                   id="trendyol_supplier_id" 
                                   value="<?php echo esc_attr($current_settings['trendyol_supplier_id'] ?? ''); ?>" 
                                   class="regular-text">
                            <p class="description">
                                <?php _e('Trendyol Supplier ID\'nizi girin.', 'marketplace-sync'); ?>
                            </p>
                        </td>
                    </tr>
                </table>
                
                <p>
                    <button type="button" class="button" id="mps-test-trendyol">
                        <?php _e('Trendyol Bağlantısını Test Et', 'marketplace-sync'); ?>
                    </button>
                </p>
            </div>
            
            <!-- Sync Settings -->
            <div class="mps-card">
                <h2>⚙️ <?php _e('Senkronizasyon Ayarları', 'marketplace-sync'); ?></h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Otomatik Senkronizasyon', 'marketplace-sync'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" 
                                       name="auto_sync" 
                                       <?php checked($current_settings['auto_sync'] ?? 'no', 'yes'); ?>>
                                <?php _e('Ürünleri otomatik olarak senkronize et (Saatlik)', 'marketplace-sync'); ?>
                            </label>
                            <p class="description">
                                <?php _e('Aktif edildiğinde, ürünler saatte bir otomatik olarak senkronize edilir.', 'marketplace-sync'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Stok Senkronizasyonu', 'marketplace-sync'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" 
                                       name="sync_stock" 
                                       <?php checked($current_settings['sync_stock'] ?? 'yes', 'yes'); ?>>
                                <?php _e('Stok miktarlarını senkronize et', 'marketplace-sync'); ?>
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Fiyat Senkronizasyonu', 'marketplace-sync'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" 
                                       name="sync_price" 
                                       <?php checked($current_settings['sync_price'] ?? 'yes', 'yes'); ?>>
                                <?php _e('Fiyatları senkronize et', 'marketplace-sync'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Help -->
            <div class="mps-card">
                <h2>❓ <?php _e('Yardım', 'marketplace-sync'); ?></h2>
                <p>
                    <?php _e('Trendyol API bilgilerinizi almak için:', 'marketplace-sync'); ?>
                </p>
                <ol>
                    <li><?php _e('Trendyol Satıcı Paneli\'ne giriş yapın', 'marketplace-sync'); ?></li>
                    <li><?php _e('Ayarlar > Entegrasyon sayfasına gidin', 'marketplace-sync'); ?></li>
                    <li><?php _e('API Key, API Secret ve Supplier ID bilgilerinizi kopyalayın', 'marketplace-sync'); ?></li>
                </ol>
                <p>
                    <strong><?php _e('Not:', 'marketplace-sync'); ?></strong>
                    <?php _e('Ürünlerinizin SKU alanı dolu olmalıdır. SKU, Trendyol\'deki barkod olarak kullanılır.', 'marketplace-sync'); ?>
                </p>
            </div>
        </div>
        
        <p class="submit">
            <button type="submit" name="mps_save_settings" class="button button-primary">
                <?php _e('Ayarları Kaydet', 'marketplace-sync'); ?>
            </button>
        </p>
    </form>
</div>

<style>
.mps-settings {
    max-width: 900px;
}

.mps-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 20px;
    margin: 20px 0;
}

.mps-card h2 {
    margin-top: 0;
    padding-bottom: 10px;
    border-bottom: 1px solid #ddd;
}
</style>

<script>
jQuery(document).ready(function($) {
    $('#mps-test-trendyol').on('click', function() {
        var $btn = $(this);
        $btn.prop('disabled', true).text('<?php _e('Test ediliyor...', 'marketplace-sync'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'mps_test_connection',
                marketplace: 'trendyol',
                nonce: mpsAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('✓ ' + response.data.message);
                } else {
                    alert('✗ ' + response.data.message);
                }
            },
            error: function() {
                alert('<?php _e('Bir hata oluştu.', 'marketplace-sync'); ?>');
            },
            complete: function() {
                $btn.prop('disabled', false).text('<?php _e('Trendyol Bağlantısını Test Et', 'marketplace-sync'); ?>');
            }
        });
    });
});
</script>
