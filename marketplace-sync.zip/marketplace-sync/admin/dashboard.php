<?php
/**
 * Dashboard Page
 */

if (!defined('ABSPATH')) {
    exit;
}

$settings = new MPS_Settings();
$logger = new MPS_Logger();

// Get statistics
global $wpdb;
$total_products = wp_count_posts('product')->publish;
$synced_products = $wpdb->get_var("SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key = '_mps_trendyol_synced' AND meta_value = 'yes'");
$recent_logs = $logger->get_logs(10);
$failed_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}mps_sync_log WHERE status = 'failed' AND created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)");
$success_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}mps_sync_log WHERE status = 'success' AND created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)");

?>

<div class="wrap">
    <h1><?php _e('Marketplace Sync - Gösterge Paneli', 'marketplace-sync'); ?></h1>
    
    <div class="mps-dashboard">
        <!-- Stats Cards -->
        <div class="mps-stats-grid">
            <div class="mps-stat-card">
                <div class="mps-stat-icon">📦</div>
                <div class="mps-stat-content">
                    <div class="mps-stat-value"><?php echo number_format($total_products); ?></div>
                    <div class="mps-stat-label"><?php _e('Toplam Ürün', 'marketplace-sync'); ?></div>
                </div>
            </div>
            
            <div class="mps-stat-card">
                <div class="mps-stat-icon">✅</div>
                <div class="mps-stat-content">
                    <div class="mps-stat-value"><?php echo number_format($synced_products); ?></div>
                    <div class="mps-stat-label"><?php _e('Senkronize Ürün', 'marketplace-sync'); ?></div>
                </div>
            </div>
            
            <div class="mps-stat-card">
                <div class="mps-stat-icon">✓</div>
                <div class="mps-stat-content">
                    <div class="mps-stat-value"><?php echo number_format($success_count); ?></div>
                    <div class="mps-stat-label"><?php _e('Başarılı (7 Gün)', 'marketplace-sync'); ?></div>
                </div>
            </div>
            
            <div class="mps-stat-card">
                <div class="mps-stat-icon">⚠️</div>
                <div class="mps-stat-content">
                    <div class="mps-stat-value"><?php echo number_format($failed_count); ?></div>
                    <div class="mps-stat-label"><?php _e('Hatalı (7 Gün)', 'marketplace-sync'); ?></div>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="mps-card">
            <h2><?php _e('Hızlı İşlemler', 'marketplace-sync'); ?></h2>
            <div class="mps-quick-actions">
                <a href="<?php echo admin_url('edit.php?post_type=product'); ?>" class="button button-primary">
                    <?php _e('Ürünleri Görüntüle', 'marketplace-sync'); ?>
                </a>
                <a href="<?php echo admin_url('admin.php?page=marketplace-sync-settings'); ?>" class="button">
                    <?php _e('Ayarlar', 'marketplace-sync'); ?>
                </a>
                <a href="<?php echo admin_url('admin.php?page=marketplace-sync-logs'); ?>" class="button">
                    <?php _e('Logları Görüntüle', 'marketplace-sync'); ?>
                </a>
                <button type="button" class="button" id="mps-test-connection">
                    <?php _e('Bağlantıyı Test Et', 'marketplace-sync'); ?>
                </button>
            </div>
        </div>
        
        <!-- Recent Activity -->
        <div class="mps-card">
            <h2><?php _e('Son İşlemler', 'marketplace-sync'); ?></h2>
            <?php if (!empty($recent_logs)): ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Tarih', 'marketplace-sync'); ?></th>
                            <th><?php _e('Ürün', 'marketplace-sync'); ?></th>
                            <th><?php _e('Marketplace', 'marketplace-sync'); ?></th>
                            <th><?php _e('İşlem', 'marketplace-sync'); ?></th>
                            <th><?php _e('Durum', 'marketplace-sync'); ?></th>
                            <th><?php _e('Mesaj', 'marketplace-sync'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_logs as $log): ?>
                            <tr>
                                <td><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($log->created_at)); ?></td>
                                <td>
                                    <?php if ($log->product_id > 0): ?>
                                        <a href="<?php echo get_edit_post_link($log->product_id); ?>">
                                            <?php echo get_the_title($log->product_id); ?>
                                        </a>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html(ucfirst($log->marketplace)); ?></td>
                                <td><?php echo esc_html($log->action); ?></td>
                                <td>
                                    <span class="mps-status mps-status-<?php echo esc_attr($log->status); ?>">
                                        <?php echo esc_html(ucfirst($log->status)); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html($log->message); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p><?php _e('Henüz işlem kaydı bulunmuyor.', 'marketplace-sync'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.mps-dashboard {
    max-width: 1200px;
}

.mps-stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin: 20px 0;
}

.mps-stat-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 15px;
}

.mps-stat-icon {
    font-size: 32px;
}

.mps-stat-value {
    font-size: 32px;
    font-weight: bold;
    color: #2271b1;
}

.mps-stat-label {
    color: #666;
    font-size: 14px;
}

.mps-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 20px;
    margin: 20px 0;
}

.mps-card h2 {
    margin-top: 0;
    padding-bottom: 10px;
    border-bottom: 1px solid #ddd;
}

.mps-quick-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-top: 15px;
}

.mps-status {
    padding: 3px 8px;
    border-radius: 3px;
    font-size: 12px;
    font-weight: bold;
}

.mps-status-success {
    background: #d4edda;
    color: #155724;
}

.mps-status-failed {
    background: #f8d7da;
    color: #721c24;
}

.mps-status-info {
    background: #d1ecf1;
    color: #0c5460;
}
</style>

<script>
jQuery(document).ready(function($) {
    $('#mps-test-connection').on('click', function() {
        var $btn = $(this);
        $btn.prop('disabled', true).text('<?php _e('Test ediliyor...', 'marketplace-sync'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'mps_test_connection',
                marketplace: 'trendyol',
                nonce: mpsAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('✓ ' + response.data.message);
                } else {
                    alert('✗ ' + response.data.message);
                }
            },
            error: function() {
                alert('<?php _e('Bir hata oluştu.', 'marketplace-sync'); ?>');
            },
            complete: function() {
                $btn.prop('disabled', false).text('<?php _e('Bağlantıyı Test Et', 'marketplace-sync'); ?>');
            }
        });
    });
});
</script>
