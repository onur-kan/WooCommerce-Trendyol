<?php
/**
 * API Handler Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class MPS_API {
    
    private $settings;
    private $logger;
    
    public function __construct() {
        $this->settings = new MPS_Settings();
        $this->logger = new MPS_Logger();
    }
    
    /**
     * Test API connection
     */
    public function test_connection($marketplace = 'trendyol') {
        switch ($marketplace) {
            case 'trendyol':
                return $this->test_trendyol_connection();
            default:
                return array(
                    'success' => false,
                    'message' => __('Desteklenmeyen marketplace.', 'marketplace-sync')
                );
        }
    }
    
    /**
     * Test Trendyol connection
     */
    private function test_trendyol_connection() {
        $credentials = $this->settings->get_trendyol_credentials();
        
        if (empty($credentials['api_key']) || empty($credentials['api_secret']) || empty($credentials['supplier_id'])) {
            return array(
                'success' => false,
                'message' => __('Lütfen API bilgilerini doldurun.', 'marketplace-sync')
            );
        }
        
        $response = $this->make_trendyol_request('suppliers/' . $credentials['supplier_id'] . '/products', 'GET');
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (wp_remote_retrieve_response_code($response) === 200) {
            return array(
                'success' => true,
                'message' => __('Bağlantı başarılı!', 'marketplace-sync')
            );
        }
        
        return array(
            'success' => false,
            'message' => isset($body['message']) ? $body['message'] : __('Bağlantı başarısız.', 'marketplace-sync')
        );
    }
    
    /**
     * Make Trendyol API request
     */
    public function make_trendyol_request($endpoint, $method = 'GET', $data = array()) {
        $credentials = $this->settings->get_trendyol_credentials();
        
        $url = 'https://api.trendyol.com/sapigw/suppliers/' . $credentials['supplier_id'] . '/' . $endpoint;
        
        $args = array(
            'method' => $method,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Basic ' . base64_encode($credentials['api_key'] . ':' . $credentials['api_secret']),
                'User-Agent' => $credentials['supplier_id'],
            ),
            'timeout' => 30,
        );
        
        if ($method !== 'GET' && !empty($data)) {
            $args['body'] = json_encode($data);
        }
        
        $this->logger->log('API Request', $endpoint, array(
            'method' => $method,
            'url' => $url,
            'data' => $data
        ));
        
        $response = wp_remote_request($url, $args);
        
        if (!is_wp_error($response)) {
            $this->logger->log('API Response', $endpoint, array(
                'code' => wp_remote_retrieve_response_code($response),
                'body' => wp_remote_retrieve_body($response)
            ));
        }
        
        return $response;
    }
    
    /**
     * Create product on Trendyol
     */
    public function create_trendyol_product($product_data) {
        return $this->make_trendyol_request('products', 'POST', array('items' => array($product_data)));
    }
    
    /**
     * Update product on Trendyol
     */
    public function update_trendyol_product($product_data) {
        return $this->make_trendyol_request('products', 'PUT', array('items' => array($product_data)));
    }
    
    /**
     * Update price and stock
     */
    public function update_trendyol_price_stock($items) {
        return $this->make_trendyol_request('products/price-and-inventory', 'POST', array('items' => $items));
    }
    
    /**
     * Get product from Trendyol
     */
    public function get_trendyol_product($barcode) {
        $response = $this->make_trendyol_request('products?barcode=' . $barcode, 'GET');
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        return isset($body['content']) && !empty($body['content']) ? $body['content'][0] : false;
    }
}
