<?php
/**
 * Settings Handler Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class MPS_Settings {
    
    private $settings;
    
    public function __construct() {
        $this->settings = get_option('mps_settings', array());
    }
    
    /**
     * Get all settings
     */
    public function get_all() {
        return $this->settings;
    }
    
    /**
     * Get a specific setting
     */
    public function get($key, $default = '') {
        return isset($this->settings[$key]) ? $this->settings[$key] : $default;
    }
    
    /**
     * Update a setting
     */
    public function set($key, $value) {
        $this->settings[$key] = $value;
        return update_option('mps_settings', $this->settings);
    }
    
    /**
     * Update multiple settings
     */
    public function update($new_settings) {
        $this->settings = array_merge($this->settings, $new_settings);
        return update_option('mps_settings', $this->settings);
    }
    
    /**
     * Get Trendyol API credentials
     */
    public function get_trendyol_credentials() {
        return array(
            'api_key' => $this->get('trendyol_api_key'),
            'api_secret' => $this->get('trendyol_api_secret'),
            'supplier_id' => $this->get('trendyol_supplier_id'),
        );
    }
    
    /**
     * Check if auto sync is enabled
     */
    public function is_auto_sync_enabled() {
        return $this->get('auto_sync') === 'yes';
    }
    
    /**
     * Check if stock sync is enabled
     */
    public function is_stock_sync_enabled() {
        return $this->get('sync_stock', 'yes') === 'yes';
    }
    
    /**
     * Check if price sync is enabled
     */
    public function is_price_sync_enabled() {
        return $this->get('sync_price', 'yes') === 'yes';
    }
}
