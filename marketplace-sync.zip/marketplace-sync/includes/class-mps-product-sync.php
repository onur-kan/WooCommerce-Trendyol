<?php
/**
 * Product Sync Handler Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class MPS_Product_Sync {
    
    private $api;
    private $settings;
    private $logger;
    
    public function __construct() {
        $this->api = new MPS_API();
        $this->settings = new MPS_Settings();
        $this->logger = new MPS_Logger();
    }
    
    /**
     * Sync multiple products
     */
    public function sync_products($product_ids, $marketplace = 'trendyol') {
        $results = array(
            'success' => array(),
            'failed' => array()
        );
        
        foreach ($product_ids as $product_id) {
            $result = $this->sync_single_product($product_id, $marketplace);
            
            if ($result['success']) {
                $results['success'][] = $product_id;
            } else {
                $results['failed'][] = array(
                    'product_id' => $product_id,
                    'message' => $result['message']
                );
            }
        }
        
        return $results;
    }
    
    /**
     * Sync single product
     */
    public function sync_single_product($product_id, $marketplace = 'trendyol') {
        $product = wc_get_product($product_id);
        
        if (!$product) {
            return array(
                'success' => false,
                'message' => __('Ürün bulunamadı.', 'marketplace-sync')
            );
        }
        
        switch ($marketplace) {
            case 'trendyol':
                return $this->sync_to_trendyol($product);
            default:
                return array(
                    'success' => false,
                    'message' => __('Desteklenmeyen marketplace.', 'marketplace-sync')
                );
        }
    }
    
    /**
     * Sync product to Trendyol
     */
    private function sync_to_trendyol($product) {
        $product_id = $product->get_id();
        $barcode = $product->get_sku();
        
        if (empty($barcode)) {
            $this->logger->log_sync($product_id, 'trendyol', 'sync', 'failed', __('SKU/Barkod bulunamadı.', 'marketplace-sync'));
            return array(
                'success' => false,
                'message' => __('SKU/Barkod bulunamadı.', 'marketplace-sync')
            );
        }
        
        // Check if product exists on Trendyol
        $existing_product = $this->api->get_trendyol_product($barcode);
        
        if ($existing_product) {
            // Update existing product
            return $this->update_trendyol_product($product);
        } else {
            // Create new product
            return $this->create_trendyol_product($product);
        }
    }
    
    /**
     * Create product on Trendyol
     */
    private function create_trendyol_product($product) {
        $product_id = $product->get_id();
        $product_data = $this->prepare_trendyol_product_data($product);
        
        $response = $this->api->create_trendyol_product($product_data);
        
        if (is_wp_error($response)) {
            $message = $response->get_error_message();
            $this->logger->log_sync($product_id, 'trendyol', 'create', 'failed', $message);
            return array(
                'success' => false,
                'message' => $message
            );
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($code === 200 || $code === 201) {
            update_post_meta($product_id, '_mps_trendyol_synced', 'yes');
            update_post_meta($product_id, '_mps_trendyol_sync_date', current_time('mysql'));
            
            $this->logger->log_sync($product_id, 'trendyol', 'create', 'success', __('Ürün başarıyla oluşturuldu.', 'marketplace-sync'), $product_data, $body);
            
            return array(
                'success' => true,
                'message' => __('Ürün başarıyla oluşturuldu.', 'marketplace-sync')
            );
        }
        
        $error_message = isset($body['message']) ? $body['message'] : __('Ürün oluşturulamadı.', 'marketplace-sync');
        $this->logger->log_sync($product_id, 'trendyol', 'create', 'failed', $error_message, $product_data, $body);
        
        return array(
            'success' => false,
            'message' => $error_message
        );
    }
    
    /**
     * Update product on Trendyol
     */
    private function update_trendyol_product($product) {
        $product_id = $product->get_id();
        
        // Update only price and stock if settings say so
        if ($this->settings->is_price_sync_enabled() || $this->settings->is_stock_sync_enabled()) {
            return $this->update_trendyol_price_stock($product);
        }
        
        // Full product update
        $product_data = $this->prepare_trendyol_product_data($product);
        $response = $this->api->update_trendyol_product($product_data);
        
        if (is_wp_error($response)) {
            $message = $response->get_error_message();
            $this->logger->log_sync($product_id, 'trendyol', 'update', 'failed', $message);
            return array(
                'success' => false,
                'message' => $message
            );
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($code === 200) {
            update_post_meta($product_id, '_mps_trendyol_synced', 'yes');
            update_post_meta($product_id, '_mps_trendyol_sync_date', current_time('mysql'));
            
            $this->logger->log_sync($product_id, 'trendyol', 'update', 'success', __('Ürün başarıyla güncellendi.', 'marketplace-sync'), $product_data, $body);
            
            return array(
                'success' => true,
                'message' => __('Ürün başarıyla güncellendi.', 'marketplace-sync')
            );
        }
        
        $error_message = isset($body['message']) ? $body['message'] : __('Ürün güncellenemedi.', 'marketplace-sync');
        $this->logger->log_sync($product_id, 'trendyol', 'update', 'failed', $error_message, $product_data, $body);
        
        return array(
            'success' => false,
            'message' => $error_message
        );
    }
    
    /**
     * Update only price and stock
     */
    private function update_trendyol_price_stock($product) {
        $product_id = $product->get_id();
        $barcode = $product->get_sku();
        
        $items = array(
            array(
                'barcode' => $barcode,
                'quantity' => $this->settings->is_stock_sync_enabled() ? $product->get_stock_quantity() : 0,
                'salePrice' => $this->settings->is_price_sync_enabled() ? (float) $product->get_price() : 0,
                'listPrice' => $this->settings->is_price_sync_enabled() ? (float) $product->get_regular_price() : 0,
            )
        );
        
        $response = $this->api->update_trendyol_price_stock($items);
        
        if (is_wp_error($response)) {
            $message = $response->get_error_message();
            $this->logger->log_sync($product_id, 'trendyol', 'update_price_stock', 'failed', $message);
            return array(
                'success' => false,
                'message' => $message
            );
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($code === 200) {
            update_post_meta($product_id, '_mps_trendyol_synced', 'yes');
            update_post_meta($product_id, '_mps_trendyol_sync_date', current_time('mysql'));
            
            $this->logger->log_sync($product_id, 'trendyol', 'update_price_stock', 'success', __('Fiyat ve stok güncellendi.', 'marketplace-sync'), $items, $body);
            
            return array(
                'success' => true,
                'message' => __('Fiyat ve stok güncellendi.', 'marketplace-sync')
            );
        }
        
        $error_message = isset($body['message']) ? $body['message'] : __('Fiyat ve stok güncellenemedi.', 'marketplace-sync');
        $this->logger->log_sync($product_id, 'trendyol', 'update_price_stock', 'failed', $error_message, $items, $body);
        
        return array(
            'success' => false,
            'message' => $error_message
        );
    }
    
    /**
     * Prepare product data for Trendyol
     */
    private function prepare_trendyol_product_data($product) {
        $product_id = $product->get_id();
        
        // Get images
        $images = array();
        $image_id = $product->get_image_id();
        if ($image_id) {
            $images[] = array('url' => wp_get_attachment_url($image_id));
        }
        
        $gallery_ids = $product->get_gallery_image_ids();
        foreach ($gallery_ids as $gallery_id) {
            $images[] = array('url' => wp_get_attachment_url($gallery_id));
        }
        
        // Get attributes
        $attributes = array();
        foreach ($product->get_attributes() as $attribute) {
            if ($attribute->get_variation()) {
                continue;
            }
            
            $attribute_name = wc_attribute_label($attribute->get_name());
            $attribute_values = $attribute->get_options();
            
            if (!empty($attribute_values)) {
                $attributes[] = array(
                    'attributeName' => $attribute_name,
                    'attributeValue' => is_array($attribute_values) ? implode(', ', $attribute_values) : $attribute_values
                );
            }
        }
        
        return array(
            'barcode' => $product->get_sku(),
            'title' => $product->get_name(),
            'productMainId' => get_post_meta($product_id, '_mps_trendyol_main_id', true) ?: '',
            'brandId' => get_post_meta($product_id, '_mps_trendyol_brand_id', true) ?: 0,
            'categoryId' => get_post_meta($product_id, '_mps_trendyol_category_id', true) ?: 0,
            'quantity' => $product->get_stock_quantity() ?: 0,
            'stockCode' => $product->get_sku(),
            'dimensionalWeight' => 0,
            'description' => wp_strip_all_tags($product->get_description()),
            'currencyType' => 'TRY',
            'listPrice' => (float) $product->get_regular_price(),
            'salePrice' => (float) $product->get_price(),
            'cargoCompanyId' => get_post_meta($product_id, '_mps_trendyol_cargo_company', true) ?: 10,
            'images' => $images,
            'attributes' => $attributes,
        );
    }
}
