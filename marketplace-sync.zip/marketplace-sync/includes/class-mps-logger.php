<?php
/**
 * Logger Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class MPS_Logger {
    
    /**
     * Log sync operation
     */
    public function log_sync($product_id, $marketplace, $action, $status, $message, $request_data = null, $response_data = null) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'mps_sync_log';
        
        $wpdb->insert(
            $table_name,
            array(
                'product_id' => $product_id,
                'marketplace' => $marketplace,
                'action' => $action,
                'status' => $status,
                'message' => $message,
                'request_data' => $request_data ? json_encode($request_data) : null,
                'response_data' => $response_data ? json_encode($response_data) : null,
                'created_at' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );
    }
    
    /**
     * Log general message
     */
    public function log($action, $message, $data = null) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'mps_sync_log';
        
        $wpdb->insert(
            $table_name,
            array(
                'product_id' => 0,
                'marketplace' => 'system',
                'action' => $action,
                'status' => 'info',
                'message' => $message,
                'request_data' => $data ? json_encode($data) : null,
                'created_at' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s', '%s')
        );
    }
    
    /**
     * Get logs
     */
    public function get_logs($limit = 50, $offset = 0, $filters = array()) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'mps_sync_log';
        
        $where = array('1=1');
        
        if (!empty($filters['product_id'])) {
            $where[] = $wpdb->prepare('product_id = %d', $filters['product_id']);
        }
        
        if (!empty($filters['marketplace'])) {
            $where[] = $wpdb->prepare('marketplace = %s', $filters['marketplace']);
        }
        
        if (!empty($filters['status'])) {
            $where[] = $wpdb->prepare('status = %s', $filters['status']);
        }
        
        $where_clause = implode(' AND ', $where);
        
        $query = "SELECT * FROM $table_name WHERE $where_clause ORDER BY created_at DESC LIMIT %d OFFSET %d";
        
        return $wpdb->get_results($wpdb->prepare($query, $limit, $offset));
    }
    
    /**
     * Get log count
     */
    public function get_log_count($filters = array()) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'mps_sync_log';
        
        $where = array('1=1');
        
        if (!empty($filters['product_id'])) {
            $where[] = $wpdb->prepare('product_id = %d', $filters['product_id']);
        }
        
        if (!empty($filters['marketplace'])) {
            $where[] = $wpdb->prepare('marketplace = %s', $filters['marketplace']);
        }
        
        if (!empty($filters['status'])) {
            $where[] = $wpdb->prepare('status = %s', $filters['status']);
        }
        
        $where_clause = implode(' AND ', $where);
        
        return $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE $where_clause");
    }
    
    /**
     * Clear old logs
     */
    public function clear_old_logs($days = 30) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'mps_sync_log';
        
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $table_name WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }
}
