# Marketplace Sync

WooCommerce ürünlerinizi marketplace platformlarıyla (Trendyol, Hepsiburada, vb.) otomatik olarak senkronize edin.

## Özellikler

- ✅ Trendyol entegrasyonu
- ✅ Otomatik senkronizasyon
- ✅ Stok ve fiyat güncelleme
- ✅ Toplu ürün senkronizasyonu
- ✅ Detaylı log sistemi
- ✅ Kolay kurulum ve kullanım

## Kurulum

1. `marketplace-sync` klasörünü `/wp-content/plugins/` dizinine yükleyin
2. WordPress admin panelinden eklentiyi aktif edin
3. **Marketplace Sync > Ayarlar** sayfasından API bilgilerinizi girin
4. Ürünlerinizi senkronize etmeye başlayın!

## Gereksinimler

- WordPress 5.8 veya üzeri
- WooCommerce 5.0 veya üzeri
- PHP 7.4 veya üzeri

## Trendyol API Bilgilerini Alma

1. [Trendyol Satıcı Paneli](https://sellercenter.trendyol.com/)'ne giriş yapın
2. **Ayarlar > Entegrasyon** sayfasına gidin
3. API Key, API Secret ve Supplier ID bilgilerinizi kopyalayın
4. WordPress admin panelinden **Marketplace Sync > Ayarlar** sayfasına gidin
5. API bilgilerinizi yapıştırın ve kaydedin

## Kullanım

### Tek Ürün Senkronizasyonu

1. **Ürünler** sayfasına gidin
2. Senkronize etmek istediğiniz ürünün üzerine gelin
3. **Trendyol'a Senkronize Et** butonuna tıklayın

### Toplu Senkronizasyon

1. **Ürünler** sayfasına gidin
2. Senkronize etmek istediğiniz ürünleri seçin
3. Toplu işlemler menüsünden **Trendyol'a Senkronize Et** seçeneğini seçin
4. **Uygula** butonuna tıklayın

### Otomatik Senkronizasyon

1. **Marketplace Sync > Ayarlar** sayfasına gidin
2. **Otomatik Senkronizasyon** seçeneğini aktif edin
3. Ürünleriniz saatte bir otomatik olarak senkronize edilecektir

## Önemli Notlar

- Ürünlerinizin **SKU** alanı dolu olmalıdır. SKU, Trendyol'deki barkod olarak kullanılır.
- İlk senkronizasyonda ürün bilgileri Trendyol'a gönderilir
- Sonraki senkronizasyonlarda sadece fiyat ve stok güncellenir (ayarlara göre)
- Trendyol'a özel alanlar (kategori, marka, vb.) ürün düzenleme sayfasından ayarlanabilir

## Loglar

Tüm senkronizasyon işlemleri **Marketplace Sync > Loglar** sayfasında görüntülenebilir. Hata ayıklama için detaylı request ve response verileri kaydedilir.

## Destek

Sorun yaşarsanız veya öneriniz varsa [GitHub Issues](https://github.com/cemasma/marketplace-sync/issues) sayfasından bize ulaşabilirsiniz.

## Lisans

GPL v2 or later

## Geliştirici

[Cem Asma](https://github.com/cemasma)

## Changelog

### 1.0.0
- İlk sürüm
- Trendyol entegrasyonu
- Otomatik senkronizasyon
- Log sistemi
