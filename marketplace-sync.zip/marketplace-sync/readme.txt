=== Marketplace Sync ===
Contributors: durasi
Tags: woocommerce, marketplace, api, integration, trendyol, n11, hepsiburada, amazon, etsy, shopify, pazarama
Requires at least: 5.0
Tested up to: 6.7
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

WooCommerce mağazanızı Trendyol, N11, Hepsiburada, Amazon, Etsy, Shopify ve Pazarama ile entegre edin.

== Description ==

**Marketplace Sync**, çevrimiçi mağazanızı popüler pazar yerleri ile entegre ederek yönetimi kolaylaştıran güçlü bir WooCommerce eklentisidir. 7 farklı pazar yeri desteğiyle, WordPress yönetim panelinizden doğrudan stok yönetimi yapabilir, fiyatları senkronize edebilir, siparişleri takip edebilir ve ürün eşleştirmesi yapabilirsiniz.

= Temel Özellikler =

* **7 Pazar Yeri Desteği**: Trendyol, N11, Hepsiburada, Amazon, Etsy, Shopify ve Pazarama
* **Merkezi Stok Yönetimi**: Tüm pazar yerlerinde tek noktadan kontrol
* **Otomatik Senkronizasyon**: Envanter ve fiyat güncellemeleri
* **Varyasyonlu Ürün Desteği**: Toplu ürün güncellemeleri
* **Sipariş Takibi**: Durum güncellemeleri ve yönetimi
* **Güvenli API Bağlantıları**: OAuth 2.0, REST ve SOAP desteği
* **Detaylı Loglama**: Hata kayıtları ve işlem geçmişi
* **Kullanıcı Dostu Arayüz**: Kolay kurulum ve yönetim
* **Çoklu Dil Desteği**: Türkçe ve İngilizce

= Desteklenen Pazar Yerleri =

**Trendyol**
* Stok senkronizasyonu
* Fiyat güncelleme
* Sipariş takibi
* Barkod bazlı ürün yönetimi

**N11**
* SOAP API entegrasyonu
* Stok ve fiyat yönetimi
* Sipariş yönetimi
* Toplu işlem desteği

**HepsiBurada**
* REST API entegrasyonu
* Stok ve fiyat senkronizasyonu
* Merchant bazlı yönetim

**Amazon**
* MWS API desteği
* ASIN bazlı ürün yönetimi
* Çoklu marketplace desteği
* Envanter raporlama

**Pazarama**
* OAuth 2.0 güvenliği
* Stok ve fiyat yönetimi
* Otomatik token yenileme

**Etsy**
* Listing yönetimi
* Stok senkronizasyonu
* Shop bazlı işlemler

**Shopify**
* Admin API entegrasyonu
* Inventory level yönetimi
* Location bazlı stok takibi
* Variant desteği

== Installation ==

1. Eklenti dosyalarını `/wp-content/plugins/marketplace-sync` dizinine yükleyin
2. WordPress'in 'Eklentiler' menüsünden eklentiyi etkinleştirin
3. Pazar yeri ayarlarını yapılandırmak için WordPress yönetim panelindeki "Marketplace Sync" menüsüne gidin
4. "API Ayarları" bölümünden her pazar yeri için API bilgilerinizi girin
5. "Bağlantıyı Test Et" butonuyla API bağlantılarınızı kontrol edin
6. WooCommerce ürünlerinize pazar yeri ID'lerini ekleyin
7. "Ürünleri Senkronize Et" butonuyla stok senkronizasyonunu başlatın

= API Anahtarlarını Nereden Bulabilirim? =

* **Trendyol**: [Trendyol Seller Center](https://partner.trendyol.com) → Entegrasyonlar → API Ayarları
* **N11**: [N11 Mağaza Yönetimi](https://www.n11.com/hesabim/magaza-yonetimi-api) → API → API Bilgileri
* **HepsiBurada**: [HepsiBurada Merchant Portal](https://merchant.hepsiburada.com) → Entegrasyon → API
* **Amazon**: [Amazon Seller Central](https://sellercentral.amazon.com.tr) → Ayarlar → Kullanıcı İzinleri → MWS API
* **Pazarama**: [Pazarama Seller](https://seller.pazarama.com) → Entegrasyon → API
* **Etsy**: [Etsy Developers](https://www.etsy.com/developers) → Apps → Create New App
* **Shopify**: [Shopify Admin](https://admin.shopify.com) → Apps → Develop Apps → Create Private App

== Frequently Asked Questions ==

= WooCommerce gerekli mi? =

Evet, bu eklenti WooCommerce ile birlikte çalışır ve WooCommerce'in yüklü olması gerekir.

= Hangi PHP sürümü gerekli? =

En az PHP 7.4 sürümü gereklidir. PHP 8.0 ve üzeri önerilir.

= Tüm ürünlerim otomatik olarak senkronize olacak mı? =

Hayır, her ürün için ilgili pazar yerinin ürün ID'sini (barkod, ASIN, listing ID vb.) girmeniz gerekir.

= Stok senkronizasyonu ne sıklıkla yapılır? =

Manuel olarak "Ürünleri Senkronize Et" butonuyla veya WooCommerce'te ürün güncellendiğinde otomatik olarak çalışır.

= Hata loglarını nerede görebilirim? =

Ana kontrol panelinde "Son İşlem Logları" bölümünde tüm senkronizasyon işlemlerini ve hatalarını görebilirsiniz.

= API limitlerini aşarsam ne olur? =

Her pazar yerinin kendi API limitleri vardır. Limit aşımı durumunda ilgili hata log kayıtlarında görünür.

== Screenshots ==

1. Ana kontrol paneli - Tüm pazar yerlerinin durumunu görüntüleyin
2. API ayarları sayfası - Her pazar yeri için API bilgilerini girin
3. Ürün düzenleme ekranı - Pazar yeri ID'lerini girin
4. Senkronizasyon logları - Tüm işlemleri takip edin

== Changelog ==

= 1.0.0 - 2024-11-20 =
* İlk sürüm
* 7 pazar yeri desteği (Trendyol, N11, Hepsiburada, Amazon, Etsy, Shopify, Pazarama)
* Stok yönetimi ve senkronizasyonu
* Fiyat güncelleme özellikleri
* Sipariş takibi
* Ürün eşleştirme sistemi
* Güvenli API bağlantıları
* Detaylı loglama sistemi
* Türkçe ve İngilizce dil desteği

== Upgrade Notice ==

= 1.0.0 =
İlk sürüm. Lütfen yüklemeden önce WordPress ve WooCommerce sürümlerinizin minimum gereksinimleri karşıladığından emin olun.

== Harici Hizmetler ==

Bu eklenti, ürün verilerini senkronize etmek için çeşitli pazar yeri API'larına bağlanır. Her pazar yeri için ilgili API dokümantasyonunu ve hizmet şartlarını aşağıda bulabilirsiniz:

= Trendyol =
* Hizmet: Trendyol Satıcı Merkezi API
* API Dokümantasyonu: https://developers.trendyol.com/
* Hizmet Şartları: https://www.trendyol.com/sozlesmeler/satici-uye-sozlesmesi

= N11 =
* Hizmet: N11 Satıcı API
* API Dokümantasyonu: https://api.n11.com/ws/
* Hizmet Şartları: https://www.n11.com/genel/satici-uyelik-sozlesmesi-76

= HepsiBurada =
* Hizmet: HepsiBurada Pazar Yeri API
* API Dokümantasyonu: https://developers.hepsiburada.com/
* Hizmet Şartları: https://www.hepsiburada.com/satici-sozlesmeleri

= Amazon =
* Hizmet: Amazon MWS API
* API Dokümantasyonu: https://developer-docs.amazon.com/
* Hizmet Şartları: https://sellercentral.amazon.com/gp/help/external/G1791

= Pazarama =
* Hizmet: Pazarama Satıcı API
* API Dokümantasyonu: https://developer.pazarama.com/
* Hizmet Şartları: https://www.pazarama.com/satici-sozlesmesi

= Etsy =
* Hizmet: Etsy Open API
* API Dokümantasyonu: https://developers.etsy.com/
* Hizmet Şartları: https://www.etsy.com/legal/sellers/

= Shopify =
* Hizmet: Shopify Admin API
* API Dokümantasyonu: https://shopify.dev/api/admin
* Hizmet Şartları: https://www.shopify.com/legal/terms

== Privacy Policy ==

Bu eklenti, pazaryeri entegrasyonları için gerekli olan API bilgilerini (API anahtarları, token'lar vb.) WordPress veritabanında güvenli şekilde saklar. Hiçbir kullanıcı verisi üçüncü şahıslarla paylaşılmaz veya eklenti geliştiricilerinin sunucularına gönderilmez. Tüm API iletişimleri doğrudan sizin sunucunuzdan ilgili pazaryerinin API'sine yapılır.
