# 🚀 Marketplace Sync - Hızlı Başlangıç

## ⚡ 5 Dakikada Hazır!

### 1️⃣ Plugin Yükle (2 dk)
```
WordPress Admin → Eklentiler → Yeni Ekle → Yükle
marketplace-sync.zip → Etkinleştir
```

### 2️⃣ API Ayarları (2 dk)
```
Marketplace Sync → API Ayarları
→ Trendyol bilgilerini gir
→ Kaydet → Bağlantıyı Test Et
```

### 3️⃣ Ürün Eşleştir (1 dk)
```
Ürünler → Bir ürün seç
→ Envanter → Trendyol Barkod gir
→ Güncelle
```

### 4️⃣ Senkronize Et (30 sn)
```
Marketplace Sync → Kontrol Paneli
→ "Ürünleri Senkronize Et"
```

## ✅ Tamamlandı!

**Sorun mu var?** `MARKETPLACE-SYNC-KURULUM.md` dosyasını okuyun

**Destek:** support@isarud.com
