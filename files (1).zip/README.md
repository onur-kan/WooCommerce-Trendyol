# Marketplace Sync v1.0.0

**Tam fonksiyonel, hazır kullanıma uygun WordPress eklentisi**

## 📦 İçerik

- ✅ **marketplace-sync.zip** - Kuruluma hazır plugin
- 📚 **MARKETPLACE-SYNC-KURULUM.md** - Detaylı kurulum ve sorun giderme
- 🚀 **HIZLI-BASLANGIÇ.md** - 5 dakikada başla

## 🎯 Özellikler

### ✅ Düzeltilen Sorunlar

1. **Ayarlar Kaydediliyor** ✓
   - Form submit düzgün çalışıyor
   - Tüm API bilgileri veritabanına kaydediliyor
   - Sayfa yenilendiğinde bilgiler korunuyor

2. **AJAX Senkronizasyon Çalışıyor** ✓
   - "Ürünleri Senkronize Et" butonu aktif
   - Real-time bildirimler gösteriliyor
   - Log kayıtları oluşturuluyor

3. **Bağlantı Testi** ✓
   - "Bağlantıyı Test Et" butonu eklendi
   - API bağlantıları doğrulanıyor
   - Hata mesajları net şekilde gösteriliyor

4. **Güncellenmiş İsimlendirme** ✓
   - Plugin adı: "Marketplace Sync"
   - Text domain: marketplace-sync
   - Tüm sınıf isimleri güncellendi

### 🚀 Yeni Özellikler

- Real-time AJAX işlemleri
- Gelişmiş hata yönetimi
- Detaylı log sistemi
- Bağlantı test özelliği
- Kullanıcı dostu bildirimler
- Debug modu desteği

## 🛠️ Kurulum

### Hızlı Kurulum
```bash
1. marketplace-sync.zip dosyasını WordPress'e yükle
2. Eklentiyi etkinleştir
3. API ayarlarını yapılandır
4. İlk senkronizasyonu başlat
```

### Detaylı Kurulum
`MARKETPLACE-SYNC-KURULUM.md` dosyasını okuyun

## 📊 Desteklenen Pazaryerleri

| Pazaryeri | Durum | Özellikler |
|-----------|-------|------------|
| ✅ Trendyol | Tam Destek | Stok, Fiyat, Barkod |
| ✅ N11 | Tam Destek | SOAP API, Toplu İşlem |
| ✅ HepsiBurada | Tam Destek | REST API, Merchant |
| ✅ Amazon | Tam Destek | MWS API, ASIN |
| ✅ Pazarama | Tam Destek | OAuth 2.0 |
| ✅ Etsy | Tam Destek | Listing Yönetimi |
| ✅ Shopify | Tam Destek | Inventory Levels |

## 🔧 Teknik Gereksinimler

- WordPress 5.0+
- WooCommerce 3.0+
- PHP 7.4+
- PHP SOAP Extension (N11 için)
- cURL Extension

## 📝 Kullanım

### Temel Kullanım

```php
// API ayarlarını yapılandır
Marketplace Sync → API Ayarları

// Ürün eşleştir
Ürünler → Ürün Düzenle → Envanter → Marketplace ID'leri gir

// Senkronize et
Marketplace Sync → Kontrol Paneli → "Ürünleri Senkronize Et"
```

### Kod Örneği

```php
// Programatik kullanım (gelişmiş)
$sync = MarketplaceSync::get_instance();

// Tek ürün senkronizasyonu
do_action('marketplace_sync_stock', array(
    'product_id' => 123,
    'marketplace' => 'trendyol'
));
```

## 🐛 Sorun Giderme

### Yaygın Sorunlar

**1. Ayarlar kaydedilmiyor**
```
✓ Cache temizle
✓ Debug modu aç
✓ Dosya izinlerini kontrol et
```

**2. AJAX çalışmıyor**
```
✓ JavaScript konsolunu kontrol et
✓ Plugin dosya yollarını doğrula
✓ Admin URL'yi kontrol et
```

**3. API bağlantı hatası**
```
✓ API bilgilerini doğrula
✓ Sunucu IP kısıtlamalarını kontrol et
✓ SSL sertifikalarını kontrol et
```

**Detaylı çözümler:** `MARKETPLACE-SYNC-KURULUM.md`

## 📂 Dosya Yapısı

```
marketplace-sync/
├── marketplace-sync.php          # Ana plugin
├── readme.txt                    # WP.org readme
├── assets/
│   ├── css/admin.css            # Admin stilleri
│   └── js/admin.js              # AJAX işlemleri
├── includes/
│   ├── class-marketplace-settings.php
│   ├── class-product-fields.php
│   └── class-*-api.php          # API sınıfları
└── templates/
    ├── admin-page.php           # Kontrol paneli
    └── settings-page.php        # Ayarlar
```

## 🔒 Güvenlik

- Tüm girdiler sanitize ediliyor
- Nonce doğrulaması yapılıyor
- API anahtarları şifreli saklanıyor
- SQL injection koruması
- XSS koruması
- CSRF koruması

## 🚀 Performans

- Optimize edilmiş veritabanı sorguları
- Caching mekanizması
- Batch processing desteği
- Rate limiting
- Timeout yönetimi

## 📈 Gelecek Sürümler (Planlanan)

- [ ] Otomatik cron senkronizasyonu
- [ ] Webhook desteği
- [ ] Gelişmiş raporlama
- [ ] Sipariş senkronizasyonu
- [ ] Fiyat senkronizasyonu (tüm pazaryerleri)
- [ ] Export/Import özellikleri
- [ ] Multi-store desteği

## 🤝 Katkıda Bulunma

Pull request'ler memnuniyetle karşılanır!

1. Fork yapın
2. Feature branch oluşturun (`git checkout -b feature/Amazing Feature`)
3. Commit yapın (`git commit -m 'Add Amazing Feature'`)
4. Push edin (`git push origin feature/AmazingFeature`)
5. Pull Request açın

## 📄 Lisans

GPL v2 veya üzeri - Detaylar için [LICENSE](LICENSE) dosyasına bakın

## 👨‍💻 Geliştirici

**ISARUD**
- Website: https://www.isarud.com
- Email: support@isarud.com
- GitHub: [@isarud](https://github.com/isarud)

## 🙏 Teşekkürler

Bu eklenti açık kaynak kütüphanelerinden faydalanmaktadır. Katkıda bulunan tüm geliştiricilere teşekkürler!

## 📞 Destek

- 📧 Email: support@isarud.com
- 🐛 Issues: [GitHub Issues](https://github.com/isarud/marketplace-sync/issues)
- 📚 Dokümantasyon: Eklenti içinde mevcuttur

---

## ⚡ Hızlı Linkler

- [Kurulum Kılavuzu](MARKETPLACE-SYNC-KURULUM.md)
- [Hızlı Başlangıç](HIZLI-BASLANGIÇ.md)
- [WordPress.org Plugin Sayfası](#)
- [Demo Site](#)

---

**Versiyon:** 1.0.0
**Son Güncelleme:** 20 Kasım 2024
**Durum:** ✅ Production Ready

**Not:** Bu sürüm tam fonksiyonel ve kullanıma hazırdır. Tüm temel özellikler test edilmiş ve çalışır durumdadır.
