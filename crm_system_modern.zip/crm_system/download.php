<?php
require_once 'config.php';
requireLogin();

$file_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$thumb = isset($_GET['thumb']);

// Dosya bilgisini çek ve yetki kontrolü yap
$stmt = $pdo->prepare("SELECT f.*, dr.user_id 
                      FROM files f
                      INNER JOIN daily_reports dr ON f.report_id = dr.id
                      WHERE f.id = ? AND dr.user_id = ?");
$stmt->execute([$file_id, $_SESSION['user_id']]);
$file = $stmt->fetch();

if (!$file) {
    die('Dosya bulunamadı veya erişim izniniz yok.');
}

$file_path = UPLOAD_DIR . $file['stored_name'];

if (!file_exists($file_path)) {
    die('Dosya bulunamadı.');
}

$ext = strtolower(pathinfo($file['original_name'], PATHINFO_EXTENSION));
$is_image = in_array($ext, ['jpg', 'jpeg', 'png', 'gif']);

// Thumbnail için
if ($thumb && $is_image) {
    header('Content-Type: ' . $file['file_type']);
    
    // Basit thumbnail oluştur
    list($width, $height) = getimagesize($file_path);
    $max_size = 200;
    
    if ($width > $height) {
        $new_width = $max_size;
        $new_height = ($height / $width) * $max_size;
    } else {
        $new_height = $max_size;
        $new_width = ($width / $height) * $max_size;
    }
    
    $thumb_image = imagecreatetruecolor($new_width, $new_height);
    
    switch ($ext) {
        case 'jpg':
        case 'jpeg':
            $source = imagecreatefromjpeg($file_path);
            break;
        case 'png':
            $source = imagecreatefrompng($file_path);
            imagealphablending($thumb_image, false);
            imagesavealpha($thumb_image, true);
            break;
        case 'gif':
            $source = imagecreatefromgif($file_path);
            break;
        default:
            readfile($file_path);
            exit;
    }
    
    imagecopyresampled($thumb_image, $source, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
    
    switch ($ext) {
        case 'jpg':
        case 'jpeg':
            imagejpeg($thumb_image, null, 85);
            break;
        case 'png':
            imagepng($thumb_image);
            break;
        case 'gif':
            imagegif($thumb_image);
            break;
    }
    
    imagedestroy($source);
    imagedestroy($thumb_image);
    exit;
}

// Normal indirme
header('Content-Type: ' . $file['file_type']);
header('Content-Disposition: attachment; filename="' . $file['original_name'] . '"');
header('Content-Length: ' . $file['file_size']);
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: public');

readfile($file_path);
exit;
?>
