<?php
require_once '../config.php';
requireAdmin();

// Filtreleme
$where = ["1=1"];
$params = [];

if (!empty($_GET['user_id'])) {
    $where[] = "dr.user_id = ?";
    $params[] = $_GET['user_id'];
}

if (!empty($_GET['start_date'])) {
    $where[] = "dr.report_date >= ?";
    $params[] = $_GET['start_date'];
}

if (!empty($_GET['end_date'])) {
    $where[] = "dr.report_date <= ?";
    $params[] = $_GET['end_date'];
}

if (!empty($_GET['project_id'])) {
    $where[] = "dr.project_id = ?";
    $params[] = $_GET['project_id'];
}

$where_clause = implode(' AND ', $where);

// Sayfalama
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 50;
$offset = ($page - 1) * $per_page;

// Toplam kayıt
$count_sql = "SELECT COUNT(*) as total FROM daily_reports dr WHERE $where_clause";
$stmt = $pdo->prepare($count_sql);
$stmt->execute($params);
$total_records = $stmt->fetch()['total'];
$total_pages = ceil($total_records / $per_page);

// Raporları çek
$sql = "SELECT dr.*, u.full_name, u.username, p.name as project_name, c.name as customer_name,
        (SELECT COUNT(*) FROM files WHERE report_id = dr.id) as file_count
        FROM daily_reports dr
        LEFT JOIN users u ON dr.user_id = u.id
        LEFT JOIN projects p ON dr.project_id = p.id
        LEFT JOIN customers c ON dr.customer_id = c.id
        WHERE $where_clause
        ORDER BY dr.report_date DESC, dr.created_at DESC
        LIMIT $per_page OFFSET $offset";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$reports = $stmt->fetchAll();

// Filtre için veriler
$users = $pdo->query("SELECT id, full_name, username FROM users WHERE is_active = 1 ORDER BY full_name")->fetchAll();
$projects = $pdo->query("SELECT id, name FROM projects WHERE status = 'aktif' ORDER BY name")->fetchAll();

// İstatistikler
$stats_sql = "SELECT 
              COUNT(*) as total,
              SUM(hours_spent) as total_hours,
              COUNT(DISTINCT user_id) as user_count
              FROM daily_reports dr WHERE $where_clause";
$stmt = $pdo->prepare($stats_sql);
$stmt->execute($params);
$stats = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tüm Raporlar - CRM Sistemi</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>📋 Tüm Raporlar</h1>
            <p class="subtitle">Sistemdeki tüm günlük raporlar</p>
        </div>
        
        <!-- Özet İstatistikler -->
        <div class="summary-card" style="background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%); color: white; padding: 20px; border-radius: 12px; margin-bottom: 30px; display: flex; justify-content: space-around; flex-wrap: wrap; gap: 20px;">
            <div style="text-align: center;">
                <h3 style="font-size: 32px; margin-bottom: 5px;"><?php echo $stats['total']; ?></h3>
                <p style="font-size: 14px; opacity: 0.9;">Toplam Rapor</p>
            </div>
            <div style="text-align: center;">
                <h3 style="font-size: 32px; margin-bottom: 5px;"><?php echo number_format($stats['total_hours'] ?? 0, 1); ?></h3>
                <p style="font-size: 14px; opacity: 0.9;">Toplam Saat</p>
            </div>
            <div style="text-align: center;">
                <h3 style="font-size: 32px; margin-bottom: 5px;"><?php echo $stats['user_count']; ?></h3>
                <p style="font-size: 14px; opacity: 0.9;">Aktif Kullanıcı</p>
            </div>
        </div>
        
        <!-- Filtreler -->
        <div class="filter-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 30px;">
            <h3 style="margin-bottom: 20px;">🔍 Filtrele</h3>
            <form method="GET" action="">
                <div class="filter-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px;">
                    <div class="form-group" style="margin: 0;">
                        <label>Kullanıcı</label>
                        <select name="user_id" class="form-control">
                            <option value="">Tüm Kullanıcılar</option>
                            <?php foreach ($users as $user): ?>
                                <option value="<?php echo $user['id']; ?>"
                                    <?php echo (isset($_GET['user_id']) && $_GET['user_id'] == $user['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($user['full_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group" style="margin: 0;">
                        <label>Başlangıç Tarihi</label>
                        <input type="date" name="start_date" class="form-control"
                               value="<?php echo $_GET['start_date'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group" style="margin: 0;">
                        <label>Bitiş Tarihi</label>
                        <input type="date" name="end_date" class="form-control"
                               value="<?php echo $_GET['end_date'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group" style="margin: 0;">
                        <label>Proje</label>
                        <select name="project_id" class="form-control">
                            <option value="">Tüm Projeler</option>
                            <?php foreach ($projects as $project): ?>
                                <option value="<?php echo $project['id']; ?>"
                                    <?php echo (isset($_GET['project_id']) && $_GET['project_id'] == $project['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($project['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="filter-buttons" style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <button type="submit" class="btn btn-primary">Filtrele</button>
                    <a href="all_reports.php" class="btn btn-secondary">Temizle</a>
                </div>
            </form>
        </div>
        
        <!-- Raporlar Tablosu -->
        <div class="recent-section">
            <h2>Raporlar (<?php echo $total_records; ?>)</h2>
            
            <?php if (empty($reports)): ?>
                <div class="empty-state">
                    <p>Rapor bulunamadı.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Tarih</th>
                                <th>Kullanıcı</th>
                                <th>Proje</th>
                                <th>Müşteri</th>
                                <th>Açıklama</th>
                                <th>Süre</th>
                                <th>Dosya</th>
                                <th>İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($reports as $report): ?>
                            <tr>
                                <td data-label="Tarih">
                                    <?php echo date('d.m.Y', strtotime($report['report_date'])); ?>
                                </td>
                                <td data-label="Kullanıcı">
                                    <strong><?php echo htmlspecialchars($report['full_name']); ?></strong>
                                </td>
                                <td data-label="Proje">
                                    <?php echo $report['project_name'] ? htmlspecialchars($report['project_name']) : '-'; ?>
                                </td>
                                <td data-label="Müşteri">
                                    <?php echo $report['customer_name'] ? htmlspecialchars($report['customer_name']) : '-'; ?>
                                </td>
                                <td data-label="Açıklama">
                                    <?php 
                                    $desc = htmlspecialchars($report['description']);
                                    echo mb_strlen($desc) > 80 ? mb_substr($desc, 0, 80) . '...' : $desc; 
                                    ?>
                                </td>
                                <td data-label="Süre">
                                    <?php echo $report['hours_spent'] ? number_format($report['hours_spent'], 1) . 'h' : '-'; ?>
                                </td>
                                <td data-label="Dosya">
                                    <?php if ($report['file_count'] > 0): ?>
                                        <span class="badge">📎 <?php echo $report['file_count']; ?></span>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td data-label="İşlem">
                                    <a href="view_report_admin.php?id=<?php echo $report['id']; ?>" class="btn-link">Görüntüle</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Sayfalama -->
                <?php if ($total_pages > 1): ?>
                <div class="pagination" style="display: flex; justify-content: center; align-items: center; gap: 10px; margin-top: 30px;">
                    <?php if ($page > 1): ?>
                        <a href="?page=1<?php echo !empty($_SERVER['QUERY_STRING']) ? '&' . http_build_query(array_diff_key($_GET, ['page' => ''])) : ''; ?>" 
                           style="padding: 8px 12px; border-radius: 6px; text-decoration: none; color: var(--text-color); border: 1px solid var(--border-color);">« İlk</a>
                        <a href="?page=<?php echo $page-1; ?><?php echo !empty($_SERVER['QUERY_STRING']) ? '&' . http_build_query(array_diff_key($_GET, ['page' => ''])) : ''; ?>"
                           style="padding: 8px 12px; border-radius: 6px; text-decoration: none; color: var(--text-color); border: 1px solid var(--border-color);">‹ Önceki</a>
                    <?php endif; ?>
                    
                    <span style="padding: 8px 12px; border-radius: 6px; background: var(--primary-color); color: white; border: 1px solid var(--primary-color);">
                        <?php echo $page; ?> / <?php echo $total_pages; ?>
                    </span>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo $page+1; ?><?php echo !empty($_SERVER['QUERY_STRING']) ? '&' . http_build_query(array_diff_key($_GET, ['page' => ''])) : ''; ?>"
                           style="padding: 8px 12px; border-radius: 6px; text-decoration: none; color: var(--text-color); border: 1px solid var(--border-color);">Sonraki ›</a>
                        <a href="?page=<?php echo $total_pages; ?><?php echo !empty($_SERVER['QUERY_STRING']) ? '&' . http_build_query(array_diff_key($_GET, ['page' => ''])) : ''; ?>"
                           style="padding: 8px 12px; border-radius: 6px; text-decoration: none; color: var(--text-color); border: 1px solid var(--border-color);">Son »</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
