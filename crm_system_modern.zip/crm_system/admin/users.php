<?php
require_once '../config.php';
requireAdmin();

$error = '';
$success = '';

// Kullanıcı ekleme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];
    $full_name = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);
    $role = $_POST['role'];
    
    if (empty($username) || empty($password) || empty($full_name)) {
        $error = 'Kullanıcı adı, şifre ve ad soyad zorunludur.';
    } else {
        try {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, email, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$username, $hashed_password, $full_name, $email, $role]);
            $success = 'Kullanıcı başarıyla eklendi.';
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $error = 'Bu kullanıcı adı zaten kullanılıyor.';
            } else {
                $error = 'Bir hata oluştu.';
            }
        }
    }
}

// Kullanıcı durumu değiştirme
if (isset($_GET['toggle']) && isset($_GET['id'])) {
    $user_id = (int)$_GET['id'];
    $stmt = $pdo->prepare("UPDATE users SET is_active = NOT is_active WHERE id = ?");
    $stmt->execute([$user_id]);
    header('Location: users.php');
    exit;
}

// Kullanıcıları çek
$users = $pdo->query("SELECT u.*, 
                     (SELECT COUNT(*) FROM daily_reports WHERE user_id = u.id) as report_count
                     FROM users u
                     ORDER BY u.created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kullanıcı Yönetimi - CRM Sistemi</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .add-form {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .status-badge {
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-active {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-inactive {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .role-badge {
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .role-admin {
            background: #fef3c7;
            color: #92400e;
        }
        
        .role-user {
            background: #dbeafe;
            color: #1e40af;
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>👥 Kullanıcı Yönetimi</h1>
            <p class="subtitle">Sistem kullanıcılarını yönetin</p>
        </div>
        
        <!-- Kullanıcı Ekleme Formu -->
        <div class="add-form">
            <h3 style="margin-bottom: 20px;">➕ Yeni Kullanıcı Ekle</h3>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <div class="form-grid">
                    <div class="form-group" style="margin: 0;">
                        <label>Kullanıcı Adı *</label>
                        <input type="text" name="username" class="form-control" required>
                    </div>
                    
                    <div class="form-group" style="margin: 0;">
                        <label>Şifre *</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    
                    <div class="form-group" style="margin: 0;">
                        <label>Ad Soyad *</label>
                        <input type="text" name="full_name" class="form-control" required>
                    </div>
                    
                    <div class="form-group" style="margin: 0;">
                        <label>E-posta</label>
                        <input type="email" name="email" class="form-control">
                    </div>
                    
                    <div class="form-group" style="margin: 0;">
                        <label>Rol *</label>
                        <select name="role" class="form-control" required>
                            <option value="user">Kullanıcı</option>
                            <option value="admin">Yönetici</option>
                        </select>
                    </div>
                    
                    <div style="display: flex; align-items: flex-end;">
                        <button type="submit" class="btn btn-primary" style="width: 100%;">
                            Kullanıcı Ekle
                        </button>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- Kullanıcı Listesi -->
        <div class="recent-section">
            <h2>Kullanıcılar (<?php echo count($users); ?>)</h2>
            
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Kullanıcı Adı</th>
                            <th>Ad Soyad</th>
                            <th>E-posta</th>
                            <th>Rol</th>
                            <th>Durum</th>
                            <th>Rapor Sayısı</th>
                            <th>Son Giriş</th>
                            <th>İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td data-label="Kullanıcı Adı">
                                <strong><?php echo htmlspecialchars($user['username']); ?></strong>
                            </td>
                            <td data-label="Ad Soyad">
                                <?php echo htmlspecialchars($user['full_name']); ?>
                            </td>
                            <td data-label="E-posta">
                                <?php echo $user['email'] ? htmlspecialchars($user['email']) : '-'; ?>
                            </td>
                            <td data-label="Rol">
                                <span class="role-badge role-<?php echo $user['role']; ?>">
                                    <?php echo $user['role'] === 'admin' ? 'Yönetici' : 'Kullanıcı'; ?>
                                </span>
                            </td>
                            <td data-label="Durum">
                                <span class="status-badge status-<?php echo $user['is_active'] ? 'active' : 'inactive'; ?>">
                                    <?php echo $user['is_active'] ? 'Aktif' : 'Pasif'; ?>
                                </span>
                            </td>
                            <td data-label="Rapor">
                                <?php echo $user['report_count']; ?>
                            </td>
                            <td data-label="Son Giriş">
                                <?php echo $user['last_login'] ? date('d.m.Y H:i', strtotime($user['last_login'])) : 'Hiç'; ?>
                            </td>
                            <td data-label="İşlem">
                                <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                    <a href="?toggle=1&id=<?php echo $user['id']; ?>" class="btn-link">
                                        <?php echo $user['is_active'] ? 'Pasifleştir' : 'Aktifleştir'; ?>
                                    </a>
                                <?php else: ?>
                                    <span style="color: var(--text-light);">Siz</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
