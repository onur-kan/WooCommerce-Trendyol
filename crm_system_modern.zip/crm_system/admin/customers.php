<?php
require_once '../config.php';
requireAdmin();

$error = '';
$success = '';

// Müşteri ekleme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $name = sanitize($_POST['name']);
    $contact_person = sanitize($_POST['contact_person'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $address = sanitize($_POST['address'] ?? '');
    $notes = sanitize($_POST['notes'] ?? '');
    
    if (empty($name)) {
        $error = 'Müşteri adı zorunludur.';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO customers (name, contact_person, email, phone, address, notes, created_by) 
                                  VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $contact_person, $email, $phone, $address, $notes, $_SESSION['user_id']]);
            $success = 'Müşteri başarıyla eklendi.';
        } catch (PDOException $e) {
            $error = 'Bir hata oluştu.';
        }
    }
}

// Müşterileri çek
$customers = $pdo->query("SELECT c.*, u.full_name as creator_name,
                         (SELECT COUNT(*) FROM projects WHERE customer_id = c.id) as project_count,
                         (SELECT COUNT(*) FROM daily_reports WHERE customer_id = c.id) as report_count
                         FROM customers c
                         LEFT JOIN users u ON c.created_by = u.id
                         ORDER BY c.created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Müşteri Yönetimi - CRM Sistemi</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>🏢 Müşteri Yönetimi</h1>
            <p class="subtitle">Müşterileri yönetin</p>
        </div>
        
        <!-- Müşteri Ekleme Formu -->
        <div class="add-form" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 30px;">
            <h3 style="margin-bottom: 20px;">➕ Yeni Müşteri Ekle</h3>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Müşteri Adı *</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label>İletişim Kişisi</label>
                        <input type="text" name="contact_person" class="form-control">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>E-posta</label>
                        <input type="email" name="email" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label>Telefon</label>
                        <input type="text" name="phone" class="form-control">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Adres</label>
                    <textarea name="address" class="form-control" rows="2"></textarea>
                </div>
                
                <div class="form-group">
                    <label>Notlar</label>
                    <textarea name="notes" class="form-control" rows="3"></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">Müşteri Ekle</button>
            </form>
        </div>
        
        <!-- Müşteri Listesi -->
        <div class="recent-section">
            <h2>Müşteriler (<?php echo count($customers); ?>)</h2>
            
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Müşteri Adı</th>
                            <th>İletişim Kişisi</th>
                            <th>E-posta</th>
                            <th>Telefon</th>
                            <th>Proje Sayısı</th>
                            <th>Rapor Sayısı</th>
                            <th>Oluşturan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($customers as $customer): ?>
                        <tr>
                            <td data-label="Müşteri">
                                <strong><?php echo htmlspecialchars($customer['name']); ?></strong>
                            </td>
                            <td data-label="İletişim">
                                <?php echo $customer['contact_person'] ? htmlspecialchars($customer['contact_person']) : '-'; ?>
                            </td>
                            <td data-label="E-posta">
                                <?php echo $customer['email'] ? htmlspecialchars($customer['email']) : '-'; ?>
                            </td>
                            <td data-label="Telefon">
                                <?php echo $customer['phone'] ? htmlspecialchars($customer['phone']) : '-'; ?>
                            </td>
                            <td data-label="Proje">
                                <?php echo $customer['project_count']; ?>
                            </td>
                            <td data-label="Rapor">
                                <?php echo $customer['report_count']; ?>
                            </td>
                            <td data-label="Oluşturan">
                                <?php echo htmlspecialchars($customer['creator_name']); ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
