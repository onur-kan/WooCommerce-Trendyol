<?php
require_once '../config.php';
requireAdmin();

// Genel istatistikler
$stats = [];

// Kullanıcılar
$stmt = $pdo->query("SELECT COUNT(*) as total, 
                    SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active 
                    FROM users");
$user_stats = $stmt->fetch();
$stats['total_users'] = $user_stats['total'];
$stats['active_users'] = $user_stats['active'];

// Projeler
$stmt = $pdo->query("SELECT COUNT(*) as total,
                    SUM(CASE WHEN status = 'aktif' THEN 1 ELSE 0 END) as active
                    FROM projects");
$project_stats = $stmt->fetch();
$stats['total_projects'] = $project_stats['total'];
$stats['active_projects'] = $project_stats['active'];

// Müşteriler
$stmt = $pdo->query("SELECT COUNT(*) as total FROM customers");
$stats['total_customers'] = $stmt->fetch()['total'];

// Raporlar
$stmt = $pdo->query("SELECT COUNT(*) as total FROM daily_reports");
$stats['total_reports'] = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM daily_reports 
                    WHERE MONTH(report_date) = MONTH(CURDATE()) 
                    AND YEAR(report_date) = YEAR(CURDATE())");
$stats['monthly_reports'] = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM daily_reports 
                    WHERE YEARWEEK(report_date) = YEARWEEK(CURDATE())");
$stats['weekly_reports'] = $stmt->fetch()['total'];

// Son aktiviteler
$stmt = $pdo->query("SELECT dr.*, u.full_name, p.name as project_name 
                    FROM daily_reports dr
                    LEFT JOIN users u ON dr.user_id = u.id
                    LEFT JOIN projects p ON dr.project_id = p.id
                    ORDER BY dr.created_at DESC
                    LIMIT 10");
$recent_activities = $stmt->fetchAll();

// En aktif kullanıcılar (bu ay)
$stmt = $pdo->query("SELECT u.full_name, COUNT(*) as report_count, SUM(dr.hours_spent) as total_hours
                    FROM daily_reports dr
                    INNER JOIN users u ON dr.user_id = u.id
                    WHERE MONTH(dr.report_date) = MONTH(CURDATE()) 
                    AND YEAR(dr.report_date) = YEAR(CURDATE())
                    GROUP BY u.id
                    ORDER BY report_count DESC
                    LIMIT 5");
$top_users = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yönetim Paneli - CRM Sistemi</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .admin-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }
        
        .admin-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        
        .admin-card h3 {
            font-size: 18px;
            margin-bottom: 15px;
            color: var(--dark-color);
        }
        
        .top-user {
            display: flex;
            justify-content: space-between;
            padding: 10px;
            background: var(--light-color);
            border-radius: 6px;
            margin-bottom: 8px;
        }
        
        .activity-item {
            padding: 12px;
            border-left: 3px solid var(--primary-color);
            background: var(--light-color);
            margin-bottom: 10px;
            border-radius: 4px;
        }
        
        .activity-time {
            font-size: 12px;
            color: var(--text-light);
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>⚙️ Yönetim Paneli</h1>
            <p class="subtitle">Sistem genel görünümü</p>
        </div>
        
        <!-- İstatistikler -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">👥</div>
                <div class="stat-content">
                    <h3><?php echo $stats['active_users']; ?> / <?php echo $stats['total_users']; ?></h3>
                    <p>Aktif / Toplam Kullanıcı</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">💼</div>
                <div class="stat-content">
                    <h3><?php echo $stats['active_projects']; ?> / <?php echo $stats['total_projects']; ?></h3>
                    <p>Aktif / Toplam Proje</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">🏢</div>
                <div class="stat-content">
                    <h3><?php echo $stats['total_customers']; ?></h3>
                    <p>Toplam Müşteri</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">📊</div>
                <div class="stat-content">
                    <h3><?php echo $stats['total_reports']; ?></h3>
                    <p>Toplam Rapor</p>
                </div>
            </div>
            
            <div class="stat-card admin-stat">
                <div class="stat-icon">📅</div>
                <div class="stat-content">
                    <h3><?php echo $stats['weekly_reports']; ?></h3>
                    <p>Bu Hafta</p>
                </div>
            </div>
            
            <div class="stat-card admin-stat">
                <div class="stat-icon">📈</div>
                <div class="stat-content">
                    <h3><?php echo $stats['monthly_reports']; ?></h3>
                    <p>Bu Ay</p>
                </div>
            </div>
        </div>
        
        <!-- Hızlı İşlemler -->
        <div class="quick-actions">
            <h2>Hızlı İşlemler</h2>
            <div class="action-buttons">
                <a href="users.php" class="btn btn-primary">
                    <span class="icon">👥</span> Kullanıcılar
                </a>
                <a href="projects.php" class="btn btn-primary">
                    <span class="icon">💼</span> Projeler
                </a>
                <a href="customers.php" class="btn btn-primary">
                    <span class="icon">🏢</span> Müşteriler
                </a>
                <a href="all_reports.php" class="btn btn-primary">
                    <span class="icon">📋</span> Tüm Raporlar
                </a>
            </div>
        </div>
        
        <!-- İki Sütunlu Grid -->
        <div class="admin-grid">
            <!-- En Aktif Kullanıcılar -->
            <div class="admin-card">
                <h3>🏆 En Aktif Kullanıcılar (Bu Ay)</h3>
                <?php if (empty($top_users)): ?>
                    <p style="color: var(--text-light);">Henüz veri yok</p>
                <?php else: ?>
                    <?php foreach ($top_users as $index => $user): ?>
                    <div class="top-user">
                        <span>
                            <?php echo $index + 1; ?>. <?php echo htmlspecialchars($user['full_name']); ?>
                        </span>
                        <span style="font-weight: 600; color: var(--primary-color);">
                            <?php echo $user['report_count']; ?> rapor
                            <?php if ($user['total_hours']): ?>
                                (<?php echo number_format($user['total_hours'], 1); ?>h)
                            <?php endif; ?>
                        </span>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Son Aktiviteler -->
            <div class="admin-card">
                <h3>⚡ Son Aktiviteler</h3>
                <?php if (empty($recent_activities)): ?>
                    <p style="color: var(--text-light);">Henüz aktivite yok</p>
                <?php else: ?>
                    <?php foreach ($recent_activities as $activity): ?>
                    <div class="activity-item">
                        <strong><?php echo htmlspecialchars($activity['full_name']); ?></strong>
                        <?php if ($activity['project_name']): ?>
                            - <?php echo htmlspecialchars($activity['project_name']); ?>
                        <?php endif; ?>
                        <div class="activity-time">
                            <?php echo date('d.m.Y H:i', strtotime($activity['created_at'])); ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
