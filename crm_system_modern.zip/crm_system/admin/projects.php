<?php
require_once '../config.php';
requireAdmin();

$error = '';
$success = '';

// Proje ekleme/düzenleme
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $name = sanitize($_POST['name']);
    $customer_id = !empty($_POST['customer_id']) ? (int)$_POST['customer_id'] : null;
    $description = sanitize($_POST['description'] ?? '');
    $status = $_POST['status'] ?? 'aktif';
    $start_date = $_POST['start_date'] ?? null;
    $end_date = $_POST['end_date'] ?? null;
    
    if (empty($name)) {
        $error = 'Proje adı zorunludur.';
    } else {
        try {
            if ($action === 'add') {
                $stmt = $pdo->prepare("INSERT INTO projects (name, customer_id, description, status, start_date, end_date, created_by) 
                                      VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $customer_id, $description, $status, $start_date, $end_date, $_SESSION['user_id']]);
                $success = 'Proje başarıyla eklendi.';
            } elseif ($action === 'edit') {
                $project_id = (int)$_POST['project_id'];
                $stmt = $pdo->prepare("UPDATE projects SET name = ?, customer_id = ?, description = ?, 
                                      status = ?, start_date = ?, end_date = ? WHERE id = ?");
                $stmt->execute([$name, $customer_id, $description, $status, $start_date, $end_date, $project_id]);
                $success = 'Proje başarıyla güncellendi.';
            }
        } catch (PDOException $e) {
            $error = 'Bir hata oluştu: ' . $e->getMessage();
        }
    }
}

// Projeleri çek
$projects = $pdo->query("SELECT p.*, c.name as customer_name, u.full_name as creator_name,
                        (SELECT COUNT(*) FROM daily_reports WHERE project_id = p.id) as report_count
                        FROM projects p
                        LEFT JOIN customers c ON p.customer_id = c.id
                        LEFT JOIN users u ON p.created_by = u.id
                        ORDER BY p.created_at DESC")->fetchAll();

// Müşterileri çek
$customers = $pdo->query("SELECT id, name FROM customers ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proje Yönetimi - CRM Sistemi</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>💼 Proje Yönetimi</h1>
            <p class="subtitle">Projeleri yönetin</p>
        </div>
        
        <!-- Proje Ekleme Formu -->
        <div class="add-form" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 30px;">
            <h3 style="margin-bottom: 20px;">➕ Yeni Proje Ekle</h3>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Proje Adı *</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Müşteri</label>
                        <select name="customer_id" class="form-control">
                            <option value="">-- Müşteri Seçin --</option>
                            <?php foreach ($customers as $customer): ?>
                                <option value="<?php echo $customer['id']; ?>">
                                    <?php echo htmlspecialchars($customer['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Durum</label>
                        <select name="status" class="form-control">
                            <option value="aktif">Aktif</option>
                            <option value="tamamlandi">Tamamlandı</option>
                            <option value="beklemede">Beklemede</option>
                            <option value="iptal">İptal</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Başlangıç Tarihi</label>
                        <input type="date" name="start_date" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label>Bitiş Tarihi</label>
                        <input type="date" name="end_date" class="form-control">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Açıklama</label>
                    <textarea name="description" class="form-control" rows="3"></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">Proje Ekle</button>
            </form>
        </div>
        
        <!-- Proje Listesi -->
        <div class="recent-section">
            <h2>Projeler (<?php echo count($projects); ?>)</h2>
            
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Proje Adı</th>
                            <th>Müşteri</th>
                            <th>Durum</th>
                            <th>Başlangıç</th>
                            <th>Bitiş</th>
                            <th>Rapor Sayısı</th>
                            <th>Oluşturan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($projects as $project): ?>
                        <tr>
                            <td data-label="Proje">
                                <strong><?php echo htmlspecialchars($project['name']); ?></strong>
                            </td>
                            <td data-label="Müşteri">
                                <?php echo $project['customer_name'] ? htmlspecialchars($project['customer_name']) : '-'; ?>
                            </td>
                            <td data-label="Durum">
                                <span class="badge" style="
                                    background: <?php 
                                        echo $project['status'] === 'aktif' ? '#d1fae5' : 
                                            ($project['status'] === 'tamamlandi' ? '#dbeafe' : '#fee2e2'); 
                                    ?>;
                                    color: <?php 
                                        echo $project['status'] === 'aktif' ? '#065f46' : 
                                            ($project['status'] === 'tamamlandi' ? '#1e40af' : '#991b1b'); 
                                    ?>;
                                ">
                                    <?php echo ucfirst($project['status']); ?>
                                </span>
                            </td>
                            <td data-label="Başlangıç">
                                <?php echo $project['start_date'] ? date('d.m.Y', strtotime($project['start_date'])) : '-'; ?>
                            </td>
                            <td data-label="Bitiş">
                                <?php echo $project['end_date'] ? date('d.m.Y', strtotime($project['end_date'])) : '-'; ?>
                            </td>
                            <td data-label="Rapor">
                                <?php echo $project['report_count']; ?>
                            </td>
                            <td data-label="Oluşturan">
                                <?php echo htmlspecialchars($project['creator_name']); ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
