<?php
// Veritabanı Bağlantı Ayarları
// Kurulum sırasında bu bilgileri güncelleyin

define('DB_HOST', 'localhost');        // Genelde localhost kalır
define('DB_NAME', 'isyeri_crm');       // cPanel'de oluşturduğunuz veritabanı adı
define('DB_USER', 'veritabani_user');  // Veritabanı kullanıcı adı
define('DB_PASS', 'veritabani_sifre'); // Veritabanı şifresi
define('DB_CHARSET', 'utf8mb4');

// Site Ayarları
define('SITE_URL', 'http://yourdomain.com/crm'); // Sitenizin URL'i
define('UPLOAD_DIR', __DIR__ . '/uploads/');     // Dosya yükleme klasörü
define('MAX_FILE_SIZE', 10485760);                // Max 10MB

// Güvenlik
define('SESSION_LIFETIME', 3600); // 1 saat (saniye cinsinden)

// Timezone
date_default_timezone_set('Europe/Istanbul');

// Veritabanı bağlantısı
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    die("Veritabanı bağlantı hatası: " . $e->getMessage());
}

// Oturum başlat
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Yardımcı fonksiyonlar
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: index.php');
        exit;
    }
}
?>
