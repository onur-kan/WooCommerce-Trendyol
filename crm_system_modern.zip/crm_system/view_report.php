<?php
require_once 'config.php';
requireLogin();

$report_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Raporu çek
$stmt = $pdo->prepare("SELECT dr.*, u.full_name, p.name as project_name, c.name as customer_name, c.contact_person, c.phone
                      FROM daily_reports dr
                      LEFT JOIN users u ON dr.user_id = u.id
                      LEFT JOIN projects p ON dr.project_id = p.id
                      LEFT JOIN customers c ON dr.customer_id = c.id
                      WHERE dr.id = ? AND dr.user_id = ?");
$stmt->execute([$report_id, $_SESSION['user_id']]);
$report = $stmt->fetch();

if (!$report) {
    header('Location: reports.php');
    exit;
}

// Dosyaları çek
$stmt = $pdo->prepare("SELECT * FROM files WHERE report_id = ? ORDER BY uploaded_at");
$stmt->execute([$report_id]);
$files = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rapor Detayı - CRM Sistemi</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .report-detail {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            max-width: 900px;
            margin: 0 auto;
        }
        
        .report-header {
            border-bottom: 2px solid var(--border-color);
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .report-date {
            font-size: 24px;
            color: var(--primary-color);
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .report-meta {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .meta-item {
            padding: 15px;
            background: var(--light-color);
            border-radius: 8px;
        }
        
        .meta-label {
            font-size: 13px;
            color: var(--text-light);
            margin-bottom: 5px;
        }
        
        .meta-value {
            font-size: 16px;
            font-weight: 600;
            color: var(--dark-color);
        }
        
        .report-content {
            padding: 20px;
            background: #f9fafb;
            border-radius: 8px;
            line-height: 1.8;
            margin-bottom: 30px;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        
        .files-section {
            margin-top: 30px;
        }
        
        .files-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .file-card {
            border: 2px solid var(--border-color);
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            transition: all 0.3s;
            cursor: pointer;
        }
        
        .file-card:hover {
            border-color: var(--primary-color);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        
        .file-icon {
            font-size: 48px;
            margin-bottom: 10px;
        }
        
        .file-card img {
            max-width: 100%;
            border-radius: 6px;
            margin-bottom: 10px;
        }
        
        .file-name {
            font-size: 13px;
            color: var(--text-color);
            word-break: break-all;
        }
        
        .file-size {
            font-size: 11px;
            color: var(--text-light);
            margin-top: 5px;
        }
        
        .action-bar {
            display: flex;
            gap: 10px;
            margin-top: 30px;
            flex-wrap: wrap;
        }
        
        @media print {
            .action-bar, .navbar, .footer {
                display: none;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>📄 Rapor Detayı</h1>
        </div>
        
        <div class="report-detail">
            <div class="report-header">
                <div class="report-date">
                    📅 <?php echo strftime('%d %B %Y, %A', strtotime($report['report_date'])); ?>
                </div>
                <p style="color: var(--text-light);">
                    Oluşturulma: <?php echo date('d.m.Y H:i', strtotime($report['created_at'])); ?>
                </p>
            </div>
            
            <div class="report-meta">
                <div class="meta-item">
                    <div class="meta-label">👤 Çalışan</div>
                    <div class="meta-value"><?php echo htmlspecialchars($report['full_name']); ?></div>
                </div>
                
                <?php if ($report['project_name']): ?>
                <div class="meta-item">
                    <div class="meta-label">💼 Proje</div>
                    <div class="meta-value"><?php echo htmlspecialchars($report['project_name']); ?></div>
                </div>
                <?php endif; ?>
                
                <?php if ($report['customer_name']): ?>
                <div class="meta-item">
                    <div class="meta-label">🏢 Müşteri</div>
                    <div class="meta-value"><?php echo htmlspecialchars($report['customer_name']); ?></div>
                    <?php if ($report['contact_person']): ?>
                        <div style="font-size: 13px; color: var(--text-light); margin-top: 5px;">
                            İletişim: <?php echo htmlspecialchars($report['contact_person']); ?>
                        </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                
                <?php if ($report['hours_spent']): ?>
                <div class="meta-item">
                    <div class="meta-label">⏱️ Harcanan Süre</div>
                    <div class="meta-value"><?php echo number_format($report['hours_spent'], 1); ?> saat</div>
                </div>
                <?php endif; ?>
            </div>
            
            <h3 style="margin-bottom: 15px;">📝 Yapılan İşler</h3>
            <div class="report-content">
                <?php echo nl2br(htmlspecialchars($report['description'])); ?>
            </div>
            
            <?php if (!empty($files)): ?>
            <div class="files-section">
                <h3 style="margin-bottom: 15px;">📎 Ekli Dosyalar (<?php echo count($files); ?>)</h3>
                <div class="files-grid">
                    <?php foreach ($files as $file): ?>
                    <a href="download.php?id=<?php echo $file['id']; ?>" class="file-card" style="text-decoration: none;">
                        <?php
                        $ext = strtolower(pathinfo($file['original_name'], PATHINFO_EXTENSION));
                        $is_image = in_array($ext, ['jpg', 'jpeg', 'png', 'gif']);
                        ?>
                        
                        <?php if ($is_image): ?>
                            <img src="download.php?id=<?php echo $file['id']; ?>&thumb=1" alt="<?php echo htmlspecialchars($file['original_name']); ?>">
                        <?php else: ?>
                            <div class="file-icon">
                                <?php
                                $icons = [
                                    'pdf' => '📄',
                                    'doc' => '📝', 'docx' => '📝',
                                    'xls' => '📊', 'xlsx' => '📊',
                                    'txt' => '📃'
                                ];
                                echo $icons[$ext] ?? '📎';
                                ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="file-name"><?php echo htmlspecialchars($file['original_name']); ?></div>
                        <div class="file-size"><?php echo formatFileSize($file['file_size']); ?></div>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="action-bar">
                <a href="reports.php" class="btn btn-secondary">
                    ← Geri Dön
                </a>
                <a href="edit_report.php?id=<?php echo $report['id']; ?>" class="btn btn-primary">
                    ✏️ Düzenle
                </a>
                <button onclick="window.print()" class="btn btn-secondary">
                    🖨️ Yazdır
                </button>
                <a href="delete_report.php?id=<?php echo $report['id']; ?>" 
                   class="btn btn-danger" 
                   onclick="return confirm('Bu raporu silmek istediğinizden emin misiniz?')">
                    🗑️ Sil
                </a>
            </div>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>

<?php
function formatFileSize($bytes) {
    if ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' B';
    }
}
?>
