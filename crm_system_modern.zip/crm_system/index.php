<?php
require_once 'config.php';
requireLogin();

// İstatistikler
$stats = [];

// Kullanıcının bu ayki rapor sayısı
$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM daily_reports 
                      WHERE user_id = ? AND MONTH(report_date) = MONTH(CURDATE()) 
                      AND YEAR(report_date) = YEAR(CURDATE())");
$stmt->execute([$_SESSION['user_id']]);
$stats['monthly_reports'] = $stmt->fetch()['count'];

// Bu haftaki rapor sayısı
$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM daily_reports 
                      WHERE user_id = ? AND YEARWEEK(report_date) = YEARWEEK(CURDATE())");
$stmt->execute([$_SESSION['user_id']]);
$stats['weekly_reports'] = $stmt->fetch()['count'];

// Toplam rapor sayısı
$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM daily_reports WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$stats['total_reports'] = $stmt->fetch()['count'];

// Admin için ek istatistikler
if (isAdmin()) {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE is_active = 1");
    $stats['active_users'] = $stmt->fetch()['count'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM projects WHERE status = 'aktif'");
    $stats['active_projects'] = $stmt->fetch()['count'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM customers");
    $stats['total_customers'] = $stmt->fetch()['count'];
}

// Son raporlar
$stmt = $pdo->prepare("SELECT dr.*, u.full_name, p.name as project_name, c.name as customer_name,
                      (SELECT COUNT(*) FROM files WHERE report_id = dr.id) as file_count
                      FROM daily_reports dr
                      LEFT JOIN users u ON dr.user_id = u.id
                      LEFT JOIN projects p ON dr.project_id = p.id
                      LEFT JOIN customers c ON dr.customer_id = c.id
                      WHERE dr.user_id = ?
                      ORDER BY dr.report_date DESC, dr.created_at DESC
                      LIMIT 5");
$stmt->execute([$_SESSION['user_id']]);
$recent_reports = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - CRM Sistemi</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="main-content">
        <!-- Top Bar with Search -->
        <div class="top-bar">
            <div class="search-box">
                <input type="text" placeholder="Ara...">
            </div>
            <div class="top-bar-actions">
                <div class="notification-icon">🔔</div>
                <div class="user-avatar">👤</div>
            </div>
        </div>
        
        <div class="container">
            <div class="page-header">
                <h1>Hoş Geldiniz, <?php echo htmlspecialchars($_SESSION['full_name']); ?>! 👋</h1>
                <p class="subtitle">Bugün: <?php echo strftime('%d %B %Y, %A', time()); ?></p>
            </div>
        
        <!-- Modern Stats Cards with Charts -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="stat-card-title">Bu Hafta</div>
                        <div class="stat-card-value"><?php echo number_format($stats['weekly_reports']); ?></div>
                        <div class="stat-card-subtitle">Haftalık Rapor</div>
                    </div>
                    <div class="stat-icon">📅</div>
                </div>
                <div class="stat-card-chart">
                    <svg width="100%" height="100%" viewBox="0 0 300 80" preserveAspectRatio="none">
                        <path d="M0,60 Q75,40 150,50 T300,35" fill="none" stroke="rgba(91,108,232,0.5)" stroke-width="2"/>
                        <path d="M0,60 Q75,40 150,50 T300,35 L300,80 L0,80 Z" fill="url(#gradient1)" opacity="0.3"/>
                        <defs>
                            <linearGradient id="gradient1" x1="0%" y1="0%" x2="0%" y2="100%">
                                <stop offset="0%" style="stop-color:rgb(91,108,232);stop-opacity:0.3" />
                                <stop offset="100%" style="stop-color:rgb(91,108,232);stop-opacity:0" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="stat-card-title">Bu Ay</div>
                        <div class="stat-card-value"><?php echo number_format($stats['monthly_reports']); ?></div>
                        <div class="stat-card-subtitle">Aylık Rapor</div>
                    </div>
                    <div class="stat-icon">📊</div>
                </div>
                <div class="stat-card-chart">
                    <svg width="100%" height="100%" viewBox="0 0 300 80" preserveAspectRatio="none">
                        <path d="M0,50 Q75,20 150,40 T300,25" fill="none" stroke="rgba(139,92,246,0.5)" stroke-width="2"/>
                        <path d="M0,50 Q75,20 150,40 T300,25 L300,80 L0,80 Z" fill="url(#gradient2)" opacity="0.3"/>
                        <defs>
                            <linearGradient id="gradient2" x1="0%" y1="0%" x2="0%" y2="100%">
                                <stop offset="0%" style="stop-color:rgb(139,92,246);stop-opacity:0.3" />
                                <stop offset="100%" style="stop-color:rgb(139,92,246);stop-opacity:0" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-card-header">
                    <div>
                        <div class="stat-card-title">Toplam</div>
                        <div class="stat-card-value"><?php echo number_format($stats['total_reports']); ?></div>
                        <div class="stat-card-subtitle">Tüm Raporlar</div>
                    </div>
                    <div class="stat-icon">📈</div>
                </div>
                <div class="stat-card-chart">
                    <svg width="100%" height="100%" viewBox="0 0 300 80" preserveAspectRatio="none">
                        <path d="M0,55 Q75,35 150,45 T300,30" fill="none" stroke="rgba(61,217,179,0.5)" stroke-width="2"/>
                        <path d="M0,55 Q75,35 150,45 T300,30 L300,80 L0,80 Z" fill="url(#gradient3)" opacity="0.3"/>
                        <defs>
                            <linearGradient id="gradient3" x1="0%" y1="0%" x2="0%" y2="100%">
                                <stop offset="0%" style="stop-color:rgb(61,217,179);stop-opacity:0.3" />
                                <stop offset="100%" style="stop-color:rgb(61,217,179);stop-opacity:0" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
            </div>
            
            <?php if (isAdmin()): ?>
            <div class="stat-card admin-stat">
                <div class="stat-card-header">
                    <div>
                        <div class="stat-card-title">Aktif Kullanıcı</div>
                        <div class="stat-card-value"><?php echo $stats['active_users']; ?></div>
                        <div class="stat-card-subtitle">Toplam Kullanıcı</div>
                    </div>
                    <div class="stat-icon">👥</div>
                </div>
                <div class="stat-card-chart" style="background: linear-gradient(180deg, rgba(245,158,11,0.1) 0%, rgba(245,158,11,0) 100%);"></div>
            </div>
            
            <div class="stat-card admin-stat">
                <div class="stat-card-header">
                    <div>
                        <div class="stat-card-title">Aktif Proje</div>
                        <div class="stat-card-value"><?php echo $stats['active_projects']; ?></div>
                        <div class="stat-card-subtitle">Devam Eden</div>
                    </div>
                    <div class="stat-icon">💼</div>
                </div>
                <div class="stat-card-chart" style="background: linear-gradient(180deg, rgba(245,158,11,0.1) 0%, rgba(245,158,11,0) 100%);"></div>
            </div>
            
            <div class="stat-card admin-stat">
                <div class="stat-card-header">
                    <div>
                        <div class="stat-card-title">Müşteri</div>
                        <div class="stat-card-value"><?php echo $stats['total_customers']; ?></div>
                        <div class="stat-card-subtitle">Toplam Müşteri</div>
                    </div>
                    <div class="stat-icon">🏢</div>
                </div>
                <div class="stat-card-chart" style="background: linear-gradient(180deg, rgba(245,158,11,0.1) 0%, rgba(245,158,11,0) 100%);"></div>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Hızlı İşlemler -->
        <div class="quick-actions">
            <h2>Hızlı İşlemler</h2>
            <div class="action-buttons">
                <a href="add_report.php" class="btn btn-primary">
                    <span class="icon">➕</span>
                    Yeni Rapor Ekle
                </a>
                <a href="reports.php" class="btn btn-secondary">
                    <span class="icon">📋</span>
                    Raporları Görüntüle
                </a>
                <?php if (isAdmin()): ?>
                <a href="admin/index.php" class="btn btn-admin">
                    <span class="icon">⚙️</span>
                    Yönetim Paneli
                </a>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Son Raporlar -->
        <div class="recent-section">
            <h2>Son Raporlarım</h2>
            
            <?php if (empty($recent_reports)): ?>
                <div class="empty-state">
                    <p>Henüz rapor eklemediniz.</p>
                    <a href="add_report.php" class="btn btn-primary">İlk Raporunuzu Ekleyin</a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Tarih</th>
                                <th>Proje</th>
                                <th>Müşteri</th>
                                <th>Açıklama</th>
                                <th>Dosya</th>
                                <th>İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_reports as $report): ?>
                            <tr>
                                <td data-label="Tarih">
                                    <?php echo date('d.m.Y', strtotime($report['report_date'])); ?>
                                </td>
                                <td data-label="Proje">
                                    <?php echo $report['project_name'] ? htmlspecialchars($report['project_name']) : '-'; ?>
                                </td>
                                <td data-label="Müşteri">
                                    <?php echo $report['customer_name'] ? htmlspecialchars($report['customer_name']) : '-'; ?>
                                </td>
                                <td data-label="Açıklama">
                                    <?php 
                                    $desc = htmlspecialchars($report['description']);
                                    echo mb_strlen($desc) > 80 ? mb_substr($desc, 0, 80) . '...' : $desc; 
                                    ?>
                                </td>
                                <td data-label="Dosya">
                                    <?php if ($report['file_count'] > 0): ?>
                                        <span class="badge">📎 <?php echo $report['file_count']; ?></span>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td data-label="İşlem">
                                    <a href="view_report.php?id=<?php echo $report['id']; ?>" class="btn-link">Görüntüle</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div style="text-align: center; margin-top: 20px;">
                    <a href="reports.php" class="btn btn-secondary">Tüm Raporları Görüntüle</a>
                </div>
            <?php endif; ?>
        </div>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>
