<footer class="footer">
    <div class="footer-content">
        <p>&copy; <?php echo date('Y'); ?> İşyeri CRM Sistemi. Tüm hakları saklıdır.</p>
        <p class="footer-links">
            <a href="#">Yardım</a> | 
            <a href="#">Gizlilik</a> | 
            <a href="#">İletişim</a>
        </p>
    </div>
</footer>
