<!DOCTYPE html>
<nav class="navbar" id="sidebar">
    <div class="nav-container">
        <div class="nav-brand">
            <a href="index.php">
                <span class="logo">📊 CRM</span>
            </a>
        </div>
        
        <div class="nav-menu">
            <a href="index.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
                <span class="icon">🏠</span> Dashboard
            </a>
            <a href="add_report.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'add_report.php' ? 'active' : ''; ?>">
                <span class="icon">➕</span> Yeni Rapor
            </a>
            <a href="reports.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>">
                <span class="icon">📋</span> Raporlarım
            </a>
            
            <?php if (isAdmin()): ?>
            <div style="padding: 15px 25px; margin-top: 20px;">
                <div style="height: 1px; background: rgba(255,255,255,0.1);"></div>
            </div>
            <div style="padding: 0 25px 10px; color: rgba(255,255,255,0.5); font-size: 11px; text-transform: uppercase; letter-spacing: 1px; font-weight: 600;">
                Yönetim
            </div>
            <a href="admin/index.php" class="nav-link <?php echo strpos($_SERVER['PHP_SELF'], '/admin/') !== false ? 'active' : ''; ?>">
                <span class="icon">📊</span> Dashboard
            </a>
            <a href="admin/users.php" class="nav-link">
                <span class="icon">👥</span> Kullanıcılar
            </a>
            <a href="admin/projects.php" class="nav-link">
                <span class="icon">💼</span> Projeler
            </a>
            <a href="admin/customers.php" class="nav-link">
                <span class="icon">🏢</span> Müşteriler
            </a>
            <a href="admin/all_reports.php" class="nav-link">
                <span class="icon">📑</span> Tüm Raporlar
            </a>
            <?php endif; ?>
        </div>
        
        <div class="nav-user">
            <div style="color: rgba(255,255,255,0.6); font-size: 11px; margin-bottom: 8px;">
                Hoş geldiniz
            </div>
            <div class="nav-dropdown">
                <a href="#" class="nav-link dropdown-toggle" style="padding: 12px 0;">
                    <span class="icon">👤</span> 
                    <span class="username"><?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                </a>
                <div class="dropdown-menu" style="bottom: 100%; top: auto; margin-bottom: 10px;">
                    <a href="profile.php">👤 Profilim</a>
                    <a href="change_password.php">🔒 Şifre Değiştir</a>
                    <hr>
                    <a href="logout.php" style="color: #ef4444;">🚪 Çıkış Yap</a>
                </div>
            </div>
        </div>
    </div>
</nav>

<button class="nav-toggle" id="navToggle">
    <span></span>
    <span></span>
    <span></span>
</button>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const navToggle = document.getElementById('navToggle');
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.querySelector('.main-content');
    
    if (navToggle) {
        navToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
            if (mainContent) {
                mainContent.classList.toggle('sidebar-collapsed');
            }
        });
    }
    
    // Dropdown menus
    const dropdowns = document.querySelectorAll('.nav-dropdown');
    dropdowns.forEach(function(dropdown) {
        const toggle = dropdown.querySelector('.dropdown-toggle');
        if (toggle) {
            toggle.addEventListener('click', function(e) {
                e.preventDefault();
                dropdown.classList.toggle('active');
            });
        }
    });
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.nav-dropdown')) {
            dropdowns.forEach(function(dropdown) {
                dropdown.classList.remove('active');
            });
        }
    });
});
</script>
