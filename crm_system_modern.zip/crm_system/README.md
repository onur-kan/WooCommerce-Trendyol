# 📊 İşyeri CRM Sistemi

Küçük ve orta ölçekli işyerleri için geliştirilmiş, kullanımı kolay günlük iş takip ve raporlama sistemi.

## ✨ Özellikler

### 👥 Kullanıcı Özellikleri
- ✅ Güvenli kullanıcı giriş sistemi
- ✅ Günlük iş raporları ekleme
- ✅ Proje ve müşteri bazlı raporlama
- ✅ Çoklu dosya yükleme (PDF, Resim, Döküman)
- ✅ Gelişmiş arama ve filtreleme
- ✅ Raporları görüntüleme ve düzenleme
- ✅ Kişisel istatistikler ve grafikler

### ⚙️ Yönetim Özellikleri
- ✅ Kullanıcı yönetimi
- ✅ Proje yönetimi
- ✅ Müşteri yönetimi
- ✅ Tüm raporları görüntüleme
- ✅ Detaylı filtreleme seçenekleri
- ✅ Aktivite takibi
- ✅ Performans istatistikleri

### 🎨 Genel Özellikler
- ✅ Modern ve responsive tasarım
- ✅ Mobil uyumlu arayüz
- ✅ Kolay kurulum
- ✅ Türkçe dil desteği
- ✅ Güvenli dosya yükleme
- ✅ PDF ve Excel export (planlı)

## 🚀 Hızlı Başlangıç

### Gereksinimler
- PHP 7.4+
- MySQL 5.7+ / MariaDB 10.2+
- Web sunucusu (Apache/Nginx)
- cPanel hosting önerilir

### Kurulum
1. Dosyaları web sunucunuza yükleyin
2. Veritabanı oluşturun
3. `config.php` dosyasını düzenleyin
4. Tarayıcıda `install.php` dosyasını çalıştırın
5. Kurulum tamamlandıktan sonra `install.php` dosyasını SİLİN

Detaylı kurulum talimatları için `KURULUM.txt` dosyasını okuyun.

## 🔐 Varsayılan Giriş Bilgileri

**Admin:**
- Kullanıcı Adı: `admin`
- Şifre: `admin123`

**Örnek Kullanıcılar:**
- Kullanıcı Adları: `ahmet`, `ayse`, `mehmet`
- Şifre: `123456`

⚠️ **Güvenlik için ilk girişten sonra tüm şifreleri değiştirin!**

## 📁 Dosya Yapısı

```
crm_system/
├── config.php              # Veritabanı yapılandırması
├── install.php             # Kurulum scripti
├── login.php               # Giriş sayfası
├── index.php               # Ana sayfa
├── add_report.php          # Rapor ekleme
├── reports.php             # Rapor listesi
├── view_report.php         # Rapor detayı
├── download.php            # Dosya indirme
├── assets/                 # CSS ve diğer statik dosyalar
│   └── style.css
├── includes/               # Ortak include dosyaları
│   ├── header.php
│   └── footer.php
├── admin/                  # Yönetim paneli
│   ├── index.php
│   ├── users.php
│   ├── projects.php
│   ├── customers.php
│   └── all_reports.php
├── uploads/                # Yüklenen dosyalar
├── .htaccess              # Apache yapılandırması
├── KURULUM.txt            # Detaylı kurulum kılavuzu
└── README.md              # Bu dosya
```

## 🔒 Güvenlik Notları

- ✅ SQL Injection koruması (PDO prepared statements)
- ✅ XSS koruması (htmlspecialchars)
- ✅ CSRF koruması (session bazlı)
- ✅ Güvenli dosya yükleme
- ✅ Şifre hashleme (password_hash)
- ✅ Oturum yönetimi
- ✅ Yetki kontrolleri

**Öneriler:**
- HTTPS kullanın
- Güçlü şifreler belirleyin
- Düzenli yedekleme yapın
- PHP ve MySQL güncel tutun

## 🎯 Kullanım Senaryoları

### Standart Kullanıcı
1. Sisteme giriş yap
2. "Yeni Rapor Ekle" butonuna tıkla
3. Günün işlerini yaz
4. İlgili proje ve müşteriyi seç
5. Gerekirse dosya ekle
6. Kaydet

### Yönetici
1. Yönetim paneline gir
2. Kullanıcıları, projeleri ve müşterileri yönet
3. Tüm raporları görüntüle ve filtrele
4. İstatistikleri incele
5. Performans takibi yap

## 🛠️ Teknik Detaylar

### Teknolojiler
- **Backend:** PHP 7.4+
- **Veritabanı:** MySQL/MariaDB
- **Frontend:** HTML5, CSS3, Vanilla JavaScript
- **Stil:** Custom CSS (Responsive)

### Veritabanı Tabloları
- `users` - Kullanıcılar
- `customers` - Müşteriler
- `projects` - Projeler
- `daily_reports` - Günlük raporlar
- `files` - Yüklenen dosyalar

## 📝 Lisans

Bu proje özel kullanım için geliştirilmiştir.

## 🤝 Katkıda Bulunma

Önerileriniz ve geri bildirimleriniz için lütfen iletişime geçin.

## 📞 Destek

Sorun yaşarsanız:
1. KURULUM.txt dosyasını kontrol edin
2. Sorun Giderme bölümüne bakın
3. PHP error loglarını kontrol edin

## 🔄 Gelecek Güncellemeler (Roadmap)

- [ ] Excel export özelliği
- [ ] E-posta bildirimleri
- [ ] Dashboard grafikleri
- [ ] Mobil uygulama
- [ ] API entegrasyonu
- [ ] Gelişmiş raporlama
- [ ] Çoklu dil desteği

## 📊 Versiyon

**v1.0** - İlk stabil sürüm (Aralık 2024)

---

**Not:** Bu sistem küçük-orta ölçekli işyerleri için optimize edilmiştir. Maksimum 50 kullanıcı için uygundur.

**Geliştirici Notu:** Sistem güvenlik ve performans odaklı geliştirilmiştir. Öneriler ve geliştirmeler için açığız.

---

© 2024 İşyeri CRM Sistemi - Tüm hakları saklıdır.
