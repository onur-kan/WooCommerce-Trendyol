<?php
require_once 'config.php';
requireLogin();

// Filtreleme
$where = ["dr.user_id = ?"];
$params = [$_SESSION['user_id']];

if (!empty($_GET['start_date'])) {
    $where[] = "dr.report_date >= ?";
    $params[] = $_GET['start_date'];
}

if (!empty($_GET['end_date'])) {
    $where[] = "dr.report_date <= ?";
    $params[] = $_GET['end_date'];
}

if (!empty($_GET['project_id'])) {
    $where[] = "dr.project_id = ?";
    $params[] = $_GET['project_id'];
}

if (!empty($_GET['customer_id'])) {
    $where[] = "dr.customer_id = ?";
    $params[] = $_GET['customer_id'];
}

$where_clause = implode(' AND ', $where);

// Sayfalama
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Toplam kayıt sayısı
$count_sql = "SELECT COUNT(*) as total FROM daily_reports dr WHERE $where_clause";
$stmt = $pdo->prepare($count_sql);
$stmt->execute($params);
$total_records = $stmt->fetch()['total'];
$total_pages = ceil($total_records / $per_page);

// Raporları çek
$sql = "SELECT dr.*, p.name as project_name, c.name as customer_name,
        (SELECT COUNT(*) FROM files WHERE report_id = dr.id) as file_count
        FROM daily_reports dr
        LEFT JOIN projects p ON dr.project_id = p.id
        LEFT JOIN customers c ON dr.customer_id = c.id
        WHERE $where_clause
        ORDER BY dr.report_date DESC, dr.created_at DESC
        LIMIT $per_page OFFSET $offset";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$reports = $stmt->fetchAll();

// Filtre için projeler ve müşteriler
$projects = $pdo->query("SELECT id, name FROM projects WHERE status = 'aktif' ORDER BY name")->fetchAll();
$customers = $pdo->query("SELECT id, name FROM customers ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raporlarım - CRM Sistemi</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .filter-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }
        
        .filter-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .filter-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 30px;
        }
        
        .pagination a, .pagination span {
            padding: 8px 12px;
            border-radius: 6px;
            text-decoration: none;
            color: var(--text-color);
            border: 1px solid var(--border-color);
        }
        
        .pagination a:hover {
            background: var(--light-color);
        }
        
        .pagination .current {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        
        .summary-card {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .summary-item {
            text-align: center;
        }
        
        .summary-item h3 {
            font-size: 32px;
            margin-bottom: 5px;
        }
        
        .summary-item p {
            font-size: 14px;
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>📋 Raporlarım</h1>
            <p class="subtitle">Tüm günlük raporlarınız</p>
        </div>
        
        <!-- Özet -->
        <div class="summary-card">
            <div class="summary-item">
                <h3><?php echo $total_records; ?></h3>
                <p>Toplam Rapor</p>
            </div>
            <div class="summary-item">
                <h3><?php 
                    $stmt = $pdo->prepare("SELECT SUM(hours_spent) as total FROM daily_reports WHERE user_id = ? AND hours_spent IS NOT NULL");
                    $stmt->execute([$_SESSION['user_id']]);
                    $total_hours = $stmt->fetch()['total'] ?? 0;
                    echo number_format($total_hours, 1);
                ?></h3>
                <p>Toplam Saat</p>
            </div>
            <div class="summary-item">
                <h3><?php 
                    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT report_date) as days FROM daily_reports WHERE user_id = ?");
                    $stmt->execute([$_SESSION['user_id']]);
                    echo $stmt->fetch()['days'];
                ?></h3>
                <p>Rapor Günü</p>
            </div>
        </div>
        
        <!-- Filtreler -->
        <div class="filter-card">
            <h3 style="margin-bottom: 20px;">🔍 Filtrele</h3>
            <form method="GET" action="">
                <div class="filter-grid">
                    <div class="form-group" style="margin: 0;">
                        <label>Başlangıç Tarihi</label>
                        <input 
                            type="date" 
                            name="start_date" 
                            class="form-control"
                            value="<?php echo $_GET['start_date'] ?? ''; ?>"
                        >
                    </div>
                    
                    <div class="form-group" style="margin: 0;">
                        <label>Bitiş Tarihi</label>
                        <input 
                            type="date" 
                            name="end_date" 
                            class="form-control"
                            value="<?php echo $_GET['end_date'] ?? ''; ?>"
                        >
                    </div>
                    
                    <div class="form-group" style="margin: 0;">
                        <label>Proje</label>
                        <select name="project_id" class="form-control">
                            <option value="">Tüm Projeler</option>
                            <?php foreach ($projects as $project): ?>
                                <option value="<?php echo $project['id']; ?>"
                                    <?php echo (isset($_GET['project_id']) && $_GET['project_id'] == $project['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($project['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group" style="margin: 0;">
                        <label>Müşteri</label>
                        <select name="customer_id" class="form-control">
                            <option value="">Tüm Müşteriler</option>
                            <?php foreach ($customers as $customer): ?>
                                <option value="<?php echo $customer['id']; ?>"
                                    <?php echo (isset($_GET['customer_id']) && $_GET['customer_id'] == $customer['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($customer['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="filter-buttons">
                    <button type="submit" class="btn btn-primary">Filtrele</button>
                    <a href="reports.php" class="btn btn-secondary">Temizle</a>
                    <a href="export_reports.php<?php echo !empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : ''; ?>" 
                       class="btn btn-success">
                        📥 Excel'e Aktar
                    </a>
                </div>
            </form>
        </div>
        
        <!-- Raporlar Tablosu -->
        <div class="recent-section">
            <h2>Raporlar (<?php echo $total_records; ?>)</h2>
            
            <?php if (empty($reports)): ?>
                <div class="empty-state">
                    <p>Henüz rapor bulunmuyor.</p>
                    <a href="add_report.php" class="btn btn-primary">Yeni Rapor Ekle</a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Tarih</th>
                                <th>Proje</th>
                                <th>Müşteri</th>
                                <th>Açıklama</th>
                                <th>Süre</th>
                                <th>Dosya</th>
                                <th>İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($reports as $report): ?>
                            <tr>
                                <td data-label="Tarih">
                                    <?php echo date('d.m.Y', strtotime($report['report_date'])); ?>
                                </td>
                                <td data-label="Proje">
                                    <?php echo $report['project_name'] ? htmlspecialchars($report['project_name']) : '-'; ?>
                                </td>
                                <td data-label="Müşteri">
                                    <?php echo $report['customer_name'] ? htmlspecialchars($report['customer_name']) : '-'; ?>
                                </td>
                                <td data-label="Açıklama">
                                    <?php 
                                    $desc = htmlspecialchars($report['description']);
                                    echo mb_strlen($desc) > 100 ? mb_substr($desc, 0, 100) . '...' : $desc; 
                                    ?>
                                </td>
                                <td data-label="Süre">
                                    <?php echo $report['hours_spent'] ? number_format($report['hours_spent'], 1) . 'h' : '-'; ?>
                                </td>
                                <td data-label="Dosya">
                                    <?php if ($report['file_count'] > 0): ?>
                                        <span class="badge">📎 <?php echo $report['file_count']; ?></span>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td data-label="İşlem">
                                    <a href="view_report.php?id=<?php echo $report['id']; ?>" class="btn-link">Görüntüle</a> |
                                    <a href="edit_report.php?id=<?php echo $report['id']; ?>" class="btn-link">Düzenle</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Sayfalama -->
                <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=1<?php echo !empty($_SERVER['QUERY_STRING']) ? '&' . http_build_query(array_diff_key($_GET, ['page' => ''])) : ''; ?>">« İlk</a>
                        <a href="?page=<?php echo $page-1; ?><?php echo !empty($_SERVER['QUERY_STRING']) ? '&' . http_build_query(array_diff_key($_GET, ['page' => ''])) : ''; ?>">‹ Önceki</a>
                    <?php endif; ?>
                    
                    <?php
                    $start = max(1, $page - 2);
                    $end = min($total_pages, $page + 2);
                    
                    for ($i = $start; $i <= $end; $i++):
                    ?>
                        <?php if ($i == $page): ?>
                            <span class="current"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="?page=<?php echo $i; ?><?php echo !empty($_SERVER['QUERY_STRING']) ? '&' . http_build_query(array_diff_key($_GET, ['page' => ''])) : ''; ?>">
                                <?php echo $i; ?>
                            </a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo $page+1; ?><?php echo !empty($_SERVER['QUERY_STRING']) ? '&' . http_build_query(array_diff_key($_GET, ['page' => ''])) : ''; ?>">Sonraki ›</a>
                        <a href="?page=<?php echo $total_pages; ?><?php echo !empty($_SERVER['QUERY_STRING']) ? '&' . http_build_query(array_diff_key($_GET, ['page' => ''])) : ''; ?>">Son »</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>
