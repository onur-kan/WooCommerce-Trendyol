<?php
require_once 'config.php';
requireLogin();

$error = '';
$success = '';

// Projeleri ve müşterileri çek
$projects = $pdo->query("SELECT id, name FROM projects WHERE status = 'aktif' ORDER BY name")->fetchAll();
$customers = $pdo->query("SELECT id, name FROM customers ORDER BY name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $report_date = $_POST['report_date'] ?? '';
    $project_id = !empty($_POST['project_id']) ? (int)$_POST['project_id'] : null;
    $customer_id = !empty($_POST['customer_id']) ? (int)$_POST['customer_id'] : null;
    $description = $_POST['description'] ?? '';
    $hours_spent = !empty($_POST['hours_spent']) ? (float)$_POST['hours_spent'] : null;
    
    if (empty($report_date) || empty($description)) {
        $error = 'Tarih ve açıklama alanları zorunludur.';
    } else {
        try {
            $pdo->beginTransaction();
            
            // Raporu ekle
            $stmt = $pdo->prepare("INSERT INTO daily_reports (user_id, project_id, customer_id, report_date, description, hours_spent) 
                                  VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$_SESSION['user_id'], $project_id, $customer_id, $report_date, $description, $hours_spent]);
            $report_id = $pdo->lastInsertId();
            
            // Dosyaları yükle
            if (!empty($_FILES['files']['name'][0])) {
                $upload_errors = [];
                
                foreach ($_FILES['files']['tmp_name'] as $key => $tmp_name) {
                    if ($_FILES['files']['error'][$key] === UPLOAD_ERR_OK) {
                        $file_name = $_FILES['files']['name'][$key];
                        $file_size = $_FILES['files']['size'][$key];
                        $file_tmp = $_FILES['files']['tmp_name'][$key];
                        $file_type = $_FILES['files']['type'][$key];
                        
                        // Dosya boyutu kontrolü
                        if ($file_size > MAX_FILE_SIZE) {
                            $upload_errors[] = "$file_name çok büyük (max 10MB)";
                            continue;
                        }
                        
                        // İzin verilen dosya türleri
                        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'txt'];
                        $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                        
                        if (!in_array($file_extension, $allowed_extensions)) {
                            $upload_errors[] = "$file_name desteklenmeyen format";
                            continue;
                        }
                        
                        // Güvenli dosya adı oluştur
                        $stored_name = uniqid() . '_' . time() . '.' . $file_extension;
                        $upload_path = UPLOAD_DIR . $stored_name;
                        
                        if (move_uploaded_file($file_tmp, $upload_path)) {
                            // Veritabanına kaydet
                            $stmt = $pdo->prepare("INSERT INTO files (report_id, original_name, stored_name, file_type, file_size) 
                                                  VALUES (?, ?, ?, ?, ?)");
                            $stmt->execute([$report_id, $file_name, $stored_name, $file_type, $file_size]);
                        } else {
                            $upload_errors[] = "$file_name yüklenemedi";
                        }
                    }
                }
                
                if (!empty($upload_errors)) {
                    $error = implode('<br>', $upload_errors);
                }
            }
            
            $pdo->commit();
            $success = 'Rapor başarıyla eklendi!';
            
            // Formu temizle
            $_POST = [];
            
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = 'Bir hata oluştu: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yeni Rapor Ekle - CRM Sistemi</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .form-card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            max-width: 800px;
            margin: 0 auto;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .file-preview {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 15px;
        }
        
        .file-preview-item {
            position: relative;
            width: 100px;
            height: 100px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--light-color);
        }
        
        .file-preview-item img {
            max-width: 100%;
            max-height: 100%;
            object-fit: cover;
        }
        
        .file-preview-item .file-icon {
            font-size: 40px;
        }
        
        .file-preview-remove {
            position: absolute;
            top: 5px;
            right: 5px;
            background: var(--danger-color);
            color: white;
            border: none;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }
        
        .char-counter {
            text-align: right;
            font-size: 13px;
            color: var(--text-light);
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>📝 Yeni Rapor Ekle</h1>
            <p class="subtitle">Bugün yaptığınız işleri kaydedin</p>
        </div>
        
        <div class="form-card">
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <?php echo $success; ?>
                    <br><a href="reports.php">Raporlarımı görüntüle</a>
                </div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data" id="reportForm">
                <div class="form-row">
                    <div class="form-group">
                        <label for="report_date">Tarih *</label>
                        <input 
                            type="date" 
                            id="report_date" 
                            name="report_date" 
                            class="form-control"
                            value="<?php echo $_POST['report_date'] ?? date('Y-m-d'); ?>"
                            max="<?php echo date('Y-m-d'); ?>"
                            required
                        >
                    </div>
                    
                    <div class="form-group">
                        <label for="hours_spent">Harcanan Süre (Saat)</label>
                        <input 
                            type="number" 
                            id="hours_spent" 
                            name="hours_spent" 
                            class="form-control"
                            step="0.5"
                            min="0"
                            max="24"
                            placeholder="Örn: 3.5"
                            value="<?php echo $_POST['hours_spent'] ?? ''; ?>"
                        >
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="project_id">Proje</label>
                        <select id="project_id" name="project_id" class="form-control">
                            <option value="">-- Proje Seçin --</option>
                            <?php foreach ($projects as $project): ?>
                                <option value="<?php echo $project['id']; ?>"
                                    <?php echo (isset($_POST['project_id']) && $_POST['project_id'] == $project['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($project['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="customer_id">Müşteri</label>
                        <select id="customer_id" name="customer_id" class="form-control">
                            <option value="">-- Müşteri Seçin --</option>
                            <?php foreach ($customers as $customer): ?>
                                <option value="<?php echo $customer['id']; ?>"
                                    <?php echo (isset($_POST['customer_id']) && $_POST['customer_id'] == $customer['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($customer['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description">Yapılan İşler *</label>
                    <textarea 
                        id="description" 
                        name="description" 
                        class="form-control"
                        rows="8"
                        required
                        placeholder="Bugün ne yaptınız? Detaylı olarak açıklayın..."
                        maxlength="5000"
                    ><?php echo $_POST['description'] ?? ''; ?></textarea>
                    <div class="char-counter">
                        <span id="charCount">0</span> / 5000 karakter
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Dosyalar (Resim, PDF, Döküman)</label>
                    <div class="file-upload-area" id="fileUploadArea">
                        <p>📎 Dosyaları sürükleyip bırakın veya tıklayın</p>
                        <p style="font-size: 13px; color: var(--text-light); margin-top: 10px;">
                            İzin verilen: JPG, PNG, PDF, DOC, XLS (Max 10MB)
                        </p>
                        <input 
                            type="file" 
                            id="files" 
                            name="files[]" 
                            multiple 
                            accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx,.xls,.xlsx,.txt"
                            style="display: none;"
                        >
                    </div>
                    <div class="file-preview" id="filePreview"></div>
                </div>
                
                <div class="form-group" style="margin-top: 30px;">
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <span class="icon">💾</span> Raporu Kaydet
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    
    <script>
        // Karakter sayacı
        const description = document.getElementById('description');
        const charCount = document.getElementById('charCount');
        
        function updateCharCount() {
            charCount.textContent = description.value.length;
        }
        
        description.addEventListener('input', updateCharCount);
        updateCharCount();
        
        // Dosya yükleme
        const fileUploadArea = document.getElementById('fileUploadArea');
        const fileInput = document.getElementById('files');
        const filePreview = document.getElementById('filePreview');
        let selectedFiles = [];
        
        fileUploadArea.addEventListener('click', () => fileInput.click());
        
        fileInput.addEventListener('change', function(e) {
            handleFiles(this.files);
        });
        
        // Drag and drop
        fileUploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.classList.add('dragover');
        });
        
        fileUploadArea.addEventListener('dragleave', function() {
            this.classList.remove('dragover');
        });
        
        fileUploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('dragover');
            handleFiles(e.dataTransfer.files);
        });
        
        function handleFiles(files) {
            const dt = new DataTransfer();
            
            // Mevcut dosyaları koru
            for (let i = 0; i < selectedFiles.length; i++) {
                dt.items.add(selectedFiles[i]);
            }
            
            // Yeni dosyaları ekle
            for (let i = 0; i < files.length; i++) {
                dt.items.add(files[i]);
            }
            
            fileInput.files = dt.files;
            selectedFiles = Array.from(dt.files);
            displayFiles();
        }
        
        function displayFiles() {
            filePreview.innerHTML = '';
            
            selectedFiles.forEach((file, index) => {
                const item = document.createElement('div');
                item.className = 'file-preview-item';
                
                if (file.type.startsWith('image/')) {
                    const img = document.createElement('img');
                    img.src = URL.createObjectURL(file);
                    item.appendChild(img);
                } else {
                    const icon = document.createElement('div');
                    icon.className = 'file-icon';
                    icon.textContent = getFileIcon(file.name);
                    item.appendChild(icon);
                }
                
                const removeBtn = document.createElement('button');
                removeBtn.className = 'file-preview-remove';
                removeBtn.innerHTML = '×';
                removeBtn.type = 'button';
                removeBtn.onclick = () => removeFile(index);
                item.appendChild(removeBtn);
                
                filePreview.appendChild(item);
            });
        }
        
        function removeFile(index) {
            selectedFiles.splice(index, 1);
            const dt = new DataTransfer();
            selectedFiles.forEach(file => dt.items.add(file));
            fileInput.files = dt.files;
            displayFiles();
        }
        
        function getFileIcon(filename) {
            const ext = filename.split('.').pop().toLowerCase();
            const icons = {
                'pdf': '📄',
                'doc': '📝',
                'docx': '📝',
                'xls': '📊',
                'xlsx': '📊',
                'txt': '📃'
            };
            return icons[ext] || '📎';
        }
    </script>
</body>
</html>
