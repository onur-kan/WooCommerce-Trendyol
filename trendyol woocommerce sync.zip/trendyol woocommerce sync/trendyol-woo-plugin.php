<?php
/**
 * Plugin Name: Trendyol WooCommerce Senkronizasyon
 * Plugin URI: https://github.com/yourusername/trendyol-woocommerce
 * Description: Trendyol ve WooCommerce arasında tam senkronizasyon - Kategori eşleştirme, otomatik sync, varyant desteği
 * Version: 2.0.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * Text Domain: trendyol-woo-sync
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 8.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Gerekli WooCommerce kontrolü
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    add_action('admin_notices', function() {
        echo '<div class="error"><p><strong>Trendyol WooCommerce Senkronizasyon</strong> için WooCommerce eklentisi gereklidir!</p></div>';
    });
    return;
}

define('TRENDYOL_WOO_VERSION', '2.0.0');
define('TRENDYOL_WOO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TRENDYOL_WOO_PLUGIN_URL', plugin_dir_url(__FILE__));

class Trendyol_WooCommerce_Sync {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_trendyol_sync_now', array($this, 'ajax_sync_now'));
        add_action('wp_ajax_trendyol_save_settings', array($this, 'ajax_save_settings'));
        add_action('wp_ajax_trendyol_map_category', array($this, 'ajax_map_category'));
        add_action('wp_ajax_trendyol_get_categories', array($this, 'ajax_get_categories'));
        add_action('wp_ajax_trendyol_test_api', array($this, 'ajax_test_api'));
        add_action('wp_ajax_trendyol_import_csv', array($this, 'ajax_import_csv'));
        add_action('wp_ajax_trendyol_sync_orders', array($this, 'ajax_sync_orders'));
        
        // Cron job
        add_action('trendyol_auto_sync_hook', array($this, 'run_auto_sync'));
        
        // Sipariş otomatik çekme cron
        add_action('trendyol_auto_sync_orders_hook', array($this, 'run_auto_sync_orders'));
        
        // WooCommerce sipariş durumu değiştiğinde
        add_action('woocommerce_order_status_changed', array($this, 'on_woo_order_status_changed'), 10, 4);
        
        // Sipariş detay sayfasına kargo bilgisi metabox ekle
        add_action('add_meta_boxes', array($this, 'add_cargo_info_metabox'));
        
        // WooCommerce ürün güncellendiğinde Trendyol'a sync
        add_action('woocommerce_update_product', array($this, 'sync_product_to_trendyol'), 10, 1);
    }
    
    public function activate() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Ayarlar tablosu
        $sql1 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}trendyol_settings (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            supplier_id varchar(100) DEFAULT NULL,
            api_key varchar(255) DEFAULT NULL,
            api_secret varchar(255) DEFAULT NULL,
            sync_interval int(11) DEFAULT 3600,
            last_sync_time datetime DEFAULT NULL,
            auto_sync_enabled tinyint(1) DEFAULT 0,
            category_mappings longtext DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        // Ürünler tablosu
        $sql2 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}trendyol_products (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            woo_product_id bigint(20) DEFAULT NULL,
            trendyol_product_id varchar(100) DEFAULT NULL,
            barcode varchar(50) DEFAULT NULL,
            title varchar(500) DEFAULT NULL,
            description longtext DEFAULT NULL,
            price decimal(10,2) DEFAULT 0.00,
            stock_quantity int(11) DEFAULT 0,
            brand varchar(200) DEFAULT NULL,
            category_id varchar(100) DEFAULT NULL,
            images longtext DEFAULT NULL,
            sync_status varchar(50) DEFAULT 'pending',
            sync_errors longtext DEFAULT NULL,
            last_synced_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY trendyol_product_id (trendyol_product_id),
            KEY woo_product_id (woo_product_id)
        ) $charset_collate;";
        
        // Kategoriler tablosu
        $sql3 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}trendyol_categories (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            trendyol_category_id varchar(100) DEFAULT NULL,
            trendyol_category_name varchar(500) DEFAULT NULL,
            woo_category_id bigint(20) DEFAULT NULL,
            woo_category_name varchar(500) DEFAULT NULL,
            is_active tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY trendyol_category_id (trendyol_category_id)
        ) $charset_collate;";
        
        // Sync log tablosu
        $sql4 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}trendyol_sync_log (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            sync_type varchar(50) DEFAULT NULL,
            direction varchar(50) DEFAULT NULL,
            products_processed int(11) DEFAULT 0,
            products_success int(11) DEFAULT 0,
            products_failed int(11) DEFAULT 0,
            error_details longtext DEFAULT NULL,
            execution_time decimal(10,2) DEFAULT 0.00,
            sync_started_at datetime DEFAULT NULL,
            sync_completed_at datetime DEFAULT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        // Varyantlar tablosu
        $sql5 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}trendyol_product_variants (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            parent_product_id bigint(20) DEFAULT NULL,
            trendyol_variant_id varchar(100) DEFAULT NULL,
            barcode varchar(50) DEFAULT NULL,
            size varchar(50) DEFAULT NULL,
            color varchar(100) DEFAULT NULL,
            price decimal(10,2) DEFAULT 0.00,
            stock_quantity int(11) DEFAULT 0,
            sku varchar(100) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY parent_product_id (parent_product_id)
        ) $charset_collate;";
        
        // Siparişler tablosu
        $sql6 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}trendyol_orders (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            trendyol_order_id varchar(100) DEFAULT NULL,
            woo_order_id bigint(20) DEFAULT NULL,
            order_number varchar(100) DEFAULT NULL,
            customer_name varchar(255) DEFAULT NULL,
            customer_email varchar(255) DEFAULT NULL,
            customer_phone varchar(50) DEFAULT NULL,
            shipping_address text DEFAULT NULL,
            order_status varchar(50) DEFAULT NULL,
            payment_status varchar(50) DEFAULT NULL,
            total_amount decimal(10,2) DEFAULT 0.00,
            currency varchar(10) DEFAULT 'TRY',
            cargo_provider varchar(100) DEFAULT NULL,
            cargo_tracking_number varchar(100) DEFAULT NULL,
            order_date datetime DEFAULT NULL,
            sync_status varchar(50) DEFAULT 'pending',
            sync_errors text DEFAULT NULL,
            last_synced_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY trendyol_order_id (trendyol_order_id),
            KEY woo_order_id (woo_order_id)
        ) $charset_collate;";
        
        // Sipariş ürünleri tablosu
        $sql7 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}trendyol_order_items (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            order_id bigint(20) DEFAULT NULL,
            trendyol_product_id varchar(100) DEFAULT NULL,
            product_name varchar(500) DEFAULT NULL,
            quantity int(11) DEFAULT 1,
            price decimal(10,2) DEFAULT 0.00,
            total decimal(10,2) DEFAULT 0.00,
            barcode varchar(50) DEFAULT NULL,
            sku varchar(100) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY order_id (order_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql1);
        dbDelta($sql2);
        dbDelta($sql3);
        dbDelta($sql4);
        dbDelta($sql5);
        dbDelta($sql6);
        dbDelta($sql7);
        
        // İlk ayar kaydı
        $wpdb->insert(
            $wpdb->prefix . 'trendyol_settings',
            array(
                'sync_interval' => 3600,
                'auto_sync_enabled' => 0
            )
        );
        
        // Cron job ayarla
        if (!wp_next_scheduled('trendyol_auto_sync_hook')) {
            wp_schedule_event(time(), 'hourly', 'trendyol_auto_sync_hook');
        }
        
        // Sipariş cron job
        if (!wp_next_scheduled('trendyol_auto_sync_orders_hook')) {
            wp_schedule_event(time(), 'hourly', 'trendyol_auto_sync_orders_hook');
        }
    }
    
    public function deactivate() {
        wp_clear_scheduled_hook('trendyol_auto_sync_hook');
        wp_clear_scheduled_hook('trendyol_auto_sync_orders_hook');
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'Trendyol Sync',
            'Trendyol Sync',
            'manage_woocommerce',
            'trendyol-sync',
            array($this, 'admin_page'),
            'dashicons-update',
            56
        );
        
        add_submenu_page(
            'trendyol-sync',
            'Ayarlar',
            'Ayarlar',
            'manage_woocommerce',
            'trendyol-sync',
            array($this, 'admin_page')
        );
        
        add_submenu_page(
            'trendyol-sync',
            'Kategori Eşleştirme',
            'Kategori Eşleştirme',
            'manage_woocommerce',
            'trendyol-categories',
            array($this, 'categories_page')
        );
        
        add_submenu_page(
            'trendyol-sync',
            'Ürünler',
            'Ürünler',
            'manage_woocommerce',
            'trendyol-products',
            array($this, 'products_page')
        );
        
        add_submenu_page(
            'trendyol-sync',
            'Loglar',
            'Loglar',
            'manage_woocommerce',
            'trendyol-logs',
            array($this, 'logs_page')
        );
        
        add_submenu_page(
            'trendyol-sync',
            'CSV İçe Aktar',
            'CSV İçe Aktar',
            'manage_woocommerce',
            'trendyol-import',
            array($this, 'import_page')
        );
        
        add_submenu_page(
            'trendyol-sync',
            'Siparişler',
            'Siparişler',
            'manage_woocommerce',
            'trendyol-orders',
            array($this, 'orders_page')
        );
    }
    
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'trendyol') === false) {
            return;
        }
        
        wp_enqueue_style('trendyol-admin-css', TRENDYOL_WOO_PLUGIN_URL . 'assets/admin.css', array(), TRENDYOL_WOO_VERSION);
        wp_enqueue_script('trendyol-admin-js', TRENDYOL_WOO_PLUGIN_URL . 'assets/admin.js', array('jquery'), TRENDYOL_WOO_VERSION, true);
        
        wp_localize_script('trendyol-admin-js', 'trendyolAjax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('trendyol_nonce')
        ));
    }
    
    public function admin_page() {
        global $wpdb;
        $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}trendyol_settings ORDER BY id DESC LIMIT 1");
        
        $template_file = TRENDYOL_WOO_PLUGIN_DIR . 'templates/admin-settings.php';
        if (file_exists($template_file)) {
            include $template_file;
        } else {
            echo '<div class="error"><p>Template dosyası bulunamadı: ' . esc_html($template_file) . '</p></div>';
            echo '<p>Mevcut klasör: ' . esc_html(TRENDYOL_WOO_PLUGIN_DIR) . '</p>';
            echo '<p>Dosyalar: <pre>' . print_r(glob(TRENDYOL_WOO_PLUGIN_DIR . 'templates/*.php'), true) . '</pre></p>';
        }
    }
    
    public function categories_page() {
        global $wpdb;
        $mappings = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}trendyol_categories ORDER BY trendyol_category_name ASC");
        
        $template_file = TRENDYOL_WOO_PLUGIN_DIR . 'templates/admin-categories.php';
        if (file_exists($template_file)) {
            include $template_file;
        } else {
            echo '<div class="error"><p>Template dosyası bulunamadı: ' . esc_html($template_file) . '</p></div>';
        }
    }
    
    public function products_page() {
        global $wpdb;
        $products = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}trendyol_products ORDER BY updated_at DESC LIMIT 100");
        
        $template_file = TRENDYOL_WOO_PLUGIN_DIR . 'templates/admin-products.php';
        if (file_exists($template_file)) {
            include $template_file;
        } else {
            echo '<div class="error"><p>Template dosyası bulunamadı: ' . esc_html($template_file) . '</p></div>';
        }
    }
    
    public function logs_page() {
        global $wpdb;
        $logs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}trendyol_sync_log ORDER BY sync_started_at DESC LIMIT 50");
        
        $template_file = TRENDYOL_WOO_PLUGIN_DIR . 'templates/admin-logs.php';
        if (file_exists($template_file)) {
            include $template_file;
        } else {
            echo '<div class="error"><p>Template dosyası bulunamadı: ' . esc_html($template_file) . '</p></div>';
        }
    }
    
    public function import_page() {
        $template_file = TRENDYOL_WOO_PLUGIN_DIR . 'templates/admin-import.php';
        if (file_exists($template_file)) {
            include $template_file;
        } else {
            echo '<div class="wrap"><div class="error"><p>Template dosyası bulunamadı: ' . esc_html($template_file) . '</p>';
            echo '<p>Lütfen templates klasöründe admin-import.php dosyasını oluşturun.</p></div></div>';
        }
    }
    
    public function orders_page() {
        global $wpdb;
        $orders = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}trendyol_orders ORDER BY order_date DESC LIMIT 100");
        
        $template_file = TRENDYOL_WOO_PLUGIN_DIR . 'templates/admin-orders.php';
        if (file_exists($template_file)) {
            include $template_file;
        } else {
            echo '<div class="wrap"><div class="error"><p>Template dosyası bulunamadı: ' . esc_html($template_file) . '</p></div></div>';
        }
    }
    
    public function ajax_save_settings() {
        check_ajax_referer('trendyol_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Yetkiniz yok');
            return;
        }
        
        global $wpdb;
        
        $supplier_id = isset($_POST['supplier_id']) ? sanitize_text_field($_POST['supplier_id']) : '';
        $api_key = isset($_POST['api_key']) ? sanitize_text_field($_POST['api_key']) : '';
        $api_secret = isset($_POST['api_secret']) ? sanitize_text_field($_POST['api_secret']) : '';
        $sync_interval = isset($_POST['sync_interval']) ? intval($_POST['sync_interval']) : 3600;
        $auto_sync_enabled = isset($_POST['auto_sync_enabled']) ? 1 : 0;
        $order_notification = isset($_POST['order_notification']) ? 1 : 0;
        
        // Bildirim ayarını kaydet
        update_option('trendyol_order_notification', $order_notification);
        
        // Önce mevcut kaydı sil
        $wpdb->query("DELETE FROM {$wpdb->prefix}trendyol_settings");
        
        // Yeni kayıt ekle
        $result = $wpdb->insert(
            $wpdb->prefix . 'trendyol_settings',
            array(
                'supplier_id' => $supplier_id,
                'api_key' => $api_key,
                'api_secret' => $api_secret,
                'sync_interval' => $sync_interval,
                'auto_sync_enabled' => $auto_sync_enabled
            ),
            array('%s', '%s', '%s', '%d', '%d')
        );
        
        if ($result !== false) {
            wp_send_json_success('Ayarlar başarıyla kaydedildi');
        } else {
            wp_send_json_error('Ayarlar kaydedilemedi: ' . $wpdb->last_error);
        }
    }
    
    public function ajax_sync_now() {
        check_ajax_referer('trendyol_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Yetkiniz yok');
        }
        
        $result = $this->sync_from_trendyol();
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    public function ajax_get_categories() {
        check_ajax_referer('trendyol_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Yetkiniz yok');
        }
        
        global $wpdb;
        $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}trendyol_settings ORDER BY id DESC LIMIT 1");
        
        if (!$settings || !$settings->api_key) {
            wp_send_json_error('API ayarları yapılmamış');
        }
        
        $categories = $this->fetch_trendyol_categories($settings);
        
        if ($categories) {
            // Kategorileri veritabanına kaydet
            foreach ($categories as $category) {
                $wpdb->replace(
                    $wpdb->prefix . 'trendyol_categories',
                    array(
                        'trendyol_category_id' => $category['id'],
                        'trendyol_category_name' => $category['name']
                    )
                );
            }
            wp_send_json_success($categories);
        } else {
            wp_send_json_error('Kategoriler alınamadı');
        }
    }
    
    public function ajax_test_api() {
        check_ajax_referer('trendyol_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Yetkiniz yok');
        }
        
        global $wpdb;
        $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}trendyol_settings ORDER BY id DESC LIMIT 1");
        
        if (!$settings || !$settings->api_key || !$settings->supplier_id) {
            wp_send_json_error('Lütfen önce Supplier ID, API Key ve API Secret bilgilerini kaydedin');
        }
        
        // Farklı endpoint'ler test et
        $endpoints = array(
            'products' => 'https://api.trendyol.com/sapigw/suppliers/' . $settings->supplier_id . '/products?size=1&page=0',
            'addresses' => 'https://api.trendyol.com/sapigw/suppliers/' . $settings->supplier_id . '/addresses',
            'brands' => 'https://api.trendyol.com/sapigw/brands'
        );
        
        $user_agent = $settings->supplier_id . ' - SelfIntegration';
        $results = array();
        
        foreach ($endpoints as $name => $url) {
            $ch = curl_init();
            curl_setopt_array($ch, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 15,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_HTTPHEADER => array(
                    'Authorization: Basic ' . base64_encode($settings->api_key . ':' . $settings->api_secret),
                    'Content-Type: application/json',
                    'User-Agent: ' . $user_agent
                )
            ));
            
            $body = curl_exec($ch);
            $response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curl_error = curl_error($ch);
            curl_close($ch);
            
            if ($curl_error) {
                $results[$name] = 'cURL Hatası: ' . $curl_error;
            } else if ($response_code === 200) {
                $results[$name] = '✓ Başarılı (' . $response_code . ')';
            } else {
                $data = json_decode($body, true);
                $error = isset($data['message']) ? $data['message'] : substr($body, 0, 100);
                $results[$name] = '✗ HTTP ' . $response_code . ': ' . $error;
            }
        }
        
        // Sonuçları göster
        $html = '<strong>Test Sonuçları:</strong><br><br>';
        foreach ($results as $endpoint => $result) {
            $html .= '<strong>' . ucfirst($endpoint) . ':</strong> ' . $result . '<br>';
        }
        
        // En az bir başarılı varsa success
        $has_success = false;
        foreach ($results as $result) {
            if (strpos($result, '✓') !== false) {
                $has_success = true;
                break;
            }
        }
        
        if ($has_success) {
            wp_send_json_success($html);
        } else {
            wp_send_json_error($html . '<br><br><strong>ÖNEMLİ:</strong> Sunucu IP\'nizi (' . $_SERVER['SERVER_ADDR'] . ') Trendyol Seller Panel\'den beyaz listeye ekleyin.');
        }
    }
    
    public function ajax_map_category() {
        check_ajax_referer('trendyol_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Yetkiniz yok');
        }
        
        global $wpdb;
        
        $trendyol_cat_id = sanitize_text_field($_POST['trendyol_cat_id']);
        $woo_cat_id = intval($_POST['woo_cat_id']);
        
        $woo_category = get_term($woo_cat_id, 'product_cat');
        
        if (!$woo_category || is_wp_error($woo_category)) {
            wp_send_json_error('WooCommerce kategorisi bulunamadı');
        }
        
        $result = $wpdb->update(
            $wpdb->prefix . 'trendyol_categories',
            array(
                'woo_category_id' => $woo_cat_id,
                'woo_category_name' => $woo_category->name
            ),
            array('trendyol_category_id' => $trendyol_cat_id)
        );
        
        if ($result !== false) {
            wp_send_json_success('Kategori eşleştirildi');
        } else {
            wp_send_json_error('Eşleştirme başarısız');
        }
    }
    
    private function fetch_trendyol_categories($settings) {
        // Trendyol API'den kategorileri çek
        $url = 'https://api.trendyol.com/sapigw/product-categories';
        
        // Trendyol zorunlu User-Agent formatı
        $user_agent = $settings->supplier_id . ' - SelfIntegration';
        
        $response = wp_remote_get($url, array(
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode($settings->api_key . ':' . $settings->api_secret),
                'Content-Type' => 'application/json',
                'User-Agent' => $user_agent
            ),
            'timeout' => 30,
            'sslverify' => true
        ));
        
        if (is_wp_error($response)) {
            error_log('Trendyol Kategori API Hatası: ' . $response->get_error_message());
            return false;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        error_log('Trendyol Kategori Response Code: ' . $response_code);
        error_log('Trendyol Kategori Response: ' . substr($body, 0, 500));
        
        if ($response_code !== 200) {
            return false;
        }
        
        $data = json_decode($body, true);
        
        // Kategorileri düzleştir
        $categories = array();
        if (isset($data['categories']) && is_array($data['categories'])) {
            foreach ($data['categories'] as $category) {
                $categories[] = array(
                    'id' => $category['id'],
                    'name' => $category['name']
                );
                // Alt kategoriler varsa
                if (isset($category['subCategories']) && is_array($category['subCategories'])) {
                    foreach ($category['subCategories'] as $subCat) {
                        $categories[] = array(
                            'id' => $subCat['id'],
                            'name' => $category['name'] . ' > ' . $subCat['name']
                        );
                    }
                }
            }
        }
        
        return !empty($categories) ? $categories : false;
    }
    
    public function sync_from_trendyol() {
        global $wpdb;
        
        $start_time = microtime(true);
        $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}trendyol_settings ORDER BY id DESC LIMIT 1");
        
        if (!$settings || !$settings->api_key) {
            return array('success' => false, 'message' => 'API ayarları yapılmamış');
        }
        
        // Log başlat
        $log_id = $wpdb->insert(
            $wpdb->prefix . 'trendyol_sync_log',
            array(
                'sync_type' => 'products',
                'direction' => 'trendyol_to_woo',
                'sync_started_at' => current_time('mysql')
            )
        );
        $log_id = $wpdb->insert_id;
        
        // Trendyol API - Doğru endpoint ve parametreler
        $url = 'https://api.trendyol.com/sapigw/suppliers/' . $settings->supplier_id . '/products';
        $url = add_query_arg(array(
            'approved' => 'true',
            'size' => 50,
            'page' => 0
        ), $url);
        
        // Trendyol zorunlu User-Agent formatı: "SatıcıID - SelfIntegration"
        $user_agent = $settings->supplier_id . ' - SelfIntegration';
        
        // cURL kullanarak dene (wp_remote_get yerine)
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_HTTPHEADER => array(
                'Authorization: Basic ' . base64_encode($settings->api_key . ':' . $settings->api_secret),
                'Content-Type: application/json',
                'Accept: application/json',
                'User-Agent: ' . $user_agent
            )
        ));
        
        $body = curl_exec($ch);
        $response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);
        
        // Debug için
        error_log('Trendyol API URL: ' . $url);
        error_log('Trendyol User-Agent: ' . $user_agent);
        error_log('Trendyol Auth: Basic ' . base64_encode($settings->api_key . ':' . $settings->api_secret));
        error_log('Trendyol API Response Code: ' . $response_code);
        error_log('Trendyol API Response Body: ' . substr($body, 0, 1000));
        
        if ($curl_error) {
            $wpdb->update(
                $wpdb->prefix . 'trendyol_sync_log',
                array(
                    'products_failed' => 1,
                    'error_details' => 'cURL Hatası: ' . $curl_error,
                    'sync_completed_at' => current_time('mysql')
                ),
                array('id' => $log_id)
            );
            return array('success' => false, 'message' => 'cURL Hatası: ' . $curl_error);
        }
        
        $data = json_decode($body, true);
        
        if ($response_code !== 200) {
            $error_message = 'API HTTP Hatası: ' . $response_code;
            if (isset($data['message'])) {
                $error_message .= ' - ' . $data['message'];
            }
            if (isset($data['errors'])) {
                $error_message .= ' - Hatalar: ' . json_encode($data['errors']);
            }
            
            // Özel hata mesajları
            $error_details = $error_message . "\n\nURL: " . $url . "\nUser-Agent: " . $user_agent . "\nResponse: " . substr($body, 0, 500);
            
            $wpdb->update(
                $wpdb->prefix . 'trendyol_sync_log',
                array(
                    'products_failed' => 1,
                    'error_details' => $error_details,
                    'sync_completed_at' => current_time('mysql')
                ),
                array('id' => $log_id)
            );
            return array('success' => false, 'message' => $error_message);
        }
        
        if (!isset($data['content']) || !is_array($data['content'])) {
            $error_msg = 'Ürün verisi alınamadı. API yanıtı: ' . substr($body, 0, 200);
            $wpdb->update(
                $wpdb->prefix . 'trendyol_sync_log',
                array(
                    'products_failed' => 1,
                    'error_details' => $error_msg,
                    'sync_completed_at' => current_time('mysql')
                ),
                array('id' => $log_id)
            );
            return array('success' => false, 'message' => $error_msg);
        }
        
        $products = $data['content'];
        $processed = 0;
        $success = 0;
        $failed = 0;
        $errors = array();
        
        foreach ($products as $trendyol_product) {
            $processed++;
            
            try {
                $result = $this->create_or_update_woo_product($trendyol_product, $settings);
                
                if ($result['success']) {
                    $success++;
                } else {
                    $failed++;
                    $errors[] = $result['message'];
                }
            } catch (Exception $e) {
                $failed++;
                $errors[] = $e->getMessage();
            }
        }
        
        $execution_time = microtime(true) - $start_time;
        
        // Log güncelle
        $wpdb->update(
            $wpdb->prefix . 'trendyol_sync_log',
            array(
                'products_processed' => $processed,
                'products_success' => $success,
                'products_failed' => $failed,
                'error_details' => !empty($errors) ? json_encode($errors) : null,
                'execution_time' => round($execution_time, 2),
                'sync_completed_at' => current_time('mysql')
            ),
            array('id' => $log_id)
        );
        
        // Son sync zamanını güncelle
        $wpdb->update(
            $wpdb->prefix . 'trendyol_settings',
            array('last_sync_time' => current_time('mysql')),
            array('id' => $settings->id)
        );
        
        return array(
            'success' => true,
            'processed' => $processed,
            'success_count' => $success,
            'failed_count' => $failed,
            'errors' => $errors,
            'execution_time' => round($execution_time, 2)
        );
    }
    
    private function create_or_update_woo_product($trendyol_product, $settings) {
        global $wpdb;
        
        // Kategori eşleştirmesi
        $category_id = null;
        if (isset($trendyol_product['categoryId'])) {
            $category_mapping = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}trendyol_categories WHERE trendyol_category_id = %s",
                $trendyol_product['categoryId']
            ));
            
            if ($category_mapping && $category_mapping->woo_category_id) {
                $category_id = $category_mapping->woo_category_id;
            }
        }
        
        // Ürün var mı kontrol et
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}trendyol_products WHERE trendyol_product_id = %s",
            $trendyol_product['id']
        ));
        
        if ($existing && $existing->woo_product_id) {
            // Mevcut ürünü güncelle
            $product_id = $existing->woo_product_id;
            $product = wc_get_product($product_id);
            
            if (!$product) {
                // Ürün silinmiş, yeni oluştur
                $product_id = null;
            }
        } else {
            $product_id = null;
        }
        
        // WooCommerce ürünü oluştur veya güncelle
        if (!$product_id) {
            $product = new WC_Product_Simple();
        } else {
            $product = wc_get_product($product_id);
        }
        
        $product->set_name($trendyol_product['title']);
        $product->set_description($trendyol_product['description'] ?? '');
        $product->set_regular_price($trendyol_product['salePrice'] ?? 0);
        $product->set_stock_quantity($trendyol_product['quantity'] ?? 0);
        $product->set_manage_stock(true);
        
        if ($trendyol_product['barcode'] ?? false) {
            $product->set_sku($trendyol_product['barcode']);
        }
        
        if ($category_id) {
            $product->set_category_ids(array($category_id));
        }
        
        // Görseller
        if (!empty($trendyol_product['images'])) {
            $image_ids = array();
            foreach ($trendyol_product['images'] as $image_url) {
                $image_id = $this->upload_image_from_url($image_url['url']);
                if ($image_id) {
                    $image_ids[] = $image_id;
                }
            }
            
            if (!empty($image_ids)) {
                $product->set_image_id($image_ids[0]);
                if (count($image_ids) > 1) {
                    $product->set_gallery_image_ids(array_slice($image_ids, 1));
                }
            }
        }
        
        $product_id = $product->save();
        
        // Trendyol veritabanına kaydet
        $wpdb->replace(
            $wpdb->prefix . 'trendyol_products',
            array(
                'woo_product_id' => $product_id,
                'trendyol_product_id' => $trendyol_product['id'],
                'barcode' => $trendyol_product['barcode'] ?? '',
                'title' => $trendyol_product['title'],
                'description' => $trendyol_product['description'] ?? '',
                'price' => $trendyol_product['salePrice'] ?? 0,
                'stock_quantity' => $trendyol_product['quantity'] ?? 0,
                'brand' => $trendyol_product['brand'] ?? '',
                'category_id' => $trendyol_product['categoryId'] ?? '',
                'images' => json_encode($trendyol_product['images'] ?? array()),
                'sync_status' => 'synced',
                'last_synced_at' => current_time('mysql')
            )
        );
        
        return array('success' => true, 'product_id' => $product_id);
    }
    
    private function upload_image_from_url($image_url) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        $tmp = download_url($image_url);
        
        if (is_wp_error($tmp)) {
            return false;
        }
        
        $file_array = array(
            'name' => basename($image_url),
            'tmp_name' => $tmp
        );
        
        $id = media_handle_sideload($file_array, 0);
        
        if (is_wp_error($id)) {
            @unlink($file_array['tmp_name']);
            return false;
        }
        
        return $id;
    }
    
    public function sync_product_to_trendyol($product_id) {
        // WooCommerce'den Trendyol'a sync (opsiyonel - gerekirse ekleriz)
        // Bu fonksiyon WooCommerce'de ürün güncellendiğinde tetiklenir
    }
    
    public function run_auto_sync() {
        global $wpdb;
        
        $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}trendyol_settings ORDER BY id DESC LIMIT 1");
        
        if ($settings && $settings->auto_sync_enabled) {
            $this->sync_from_trendyol();
        }
    }
    
    public function ajax_import_csv() {
        check_ajax_referer('trendyol_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Yetkiniz yok');
        }
        
        if (!isset($_FILES['csv_file'])) {
            wp_send_json_error('Dosya yüklenmedi');
        }
        
        $file = $_FILES['csv_file'];
        $import_images = isset($_POST['import_images']) && $_POST['import_images'] === '1';
        $update_existing = isset($_POST['update_existing']) && $_POST['update_existing'] === '1';
        
        // Dosya tipini kontrol et
        $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($file_extension, array('csv', 'xlsx', 'xls'))) {
            wp_send_json_error('Sadece CSV veya Excel dosyaları kabul edilir');
        }
        
        // CSV'yi oku
        $csv_data = $this->read_csv_file($file['tmp_name'], $file_extension);
        
        if (!$csv_data || count($csv_data) < 2) {
            wp_send_json_error('CSV dosyası okunamadı veya boş');
        }
        
        // İlk satır başlıklar
        $headers = array_shift($csv_data);
        
        // İçe aktarma işlemi
        $result = $this->import_products_from_csv($headers, $csv_data, $import_images, $update_existing);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    private function read_csv_file($file_path, $extension) {
        if ($extension === 'csv') {
            $data = array();
            if (($handle = fopen($file_path, 'r')) !== FALSE) {
                while (($row = fgetcsv($handle, 10000, ',')) !== FALSE) {
                    $data[] = $row;
                }
                fclose($handle);
            }
            return $data;
        }
        
        // Excel desteği için SimpleXLSX kullanılabilir (opsiyonel)
        return false;
    }
    
    private function import_products_from_csv($headers, $rows, $import_images, $update_existing) {
        global $wpdb;
        
        $total = count($rows);
        $success = 0;
        $failed = 0;
        $errors = array();
        
        // Sütun indekslerini bul
        $column_map = $this->map_csv_columns($headers);
        
        foreach ($rows as $index => $row) {
            try {
                // Boş satırları atla
                if (empty(array_filter($row))) {
                    continue;
                }
                
                $product_data = $this->extract_product_data($row, $column_map);
                
                if (empty($product_data['barcode']) || empty($product_data['title'])) {
                    $failed++;
                    $errors[] = "Satır " . ($index + 2) . ": Barkod veya ürün adı eksik";
                    continue;
                }
                
                // Mevcut ürünü kontrol et
                $existing_product_id = null;
                if ($update_existing) {
                    $existing_product_id = $this->find_product_by_sku($product_data['barcode']);
                }
                
                // Ürünü oluştur veya güncelle
                $result = $this->create_woo_product_from_csv($product_data, $existing_product_id, $import_images);
                
                if ($result['success']) {
                    $success++;
                } else {
                    $failed++;
                    $errors[] = "Satır " . ($index + 2) . ": " . $result['message'];
                }
                
            } catch (Exception $e) {
                $failed++;
                $errors[] = "Satır " . ($index + 2) . ": " . $e->getMessage();
            }
        }
        
        return array(
            'success' => true,
            'total' => $total,
            'success' => $success,
            'failed' => $failed,
            'errors' => $errors
        );
    }
    
    private function map_csv_columns($headers) {
        $map = array();
        
        foreach ($headers as $index => $header) {
            $header = trim($header);
            
            // Türkçe karakter ve encoding sorunlarını temizle
            $header = mb_convert_encoding($header, 'UTF-8', 'UTF-8');
            
            if (stripos($header, 'Barkod') !== false) {
                $map['barcode'] = $index;
            } elseif (stripos($header, 'Ürün Adı') !== false || stripos($header, 'ÃœrÃ¼n AdÄ±') !== false) {
                $map['title'] = $index;
            } elseif (stripos($header, 'Açıklama') !== false || stripos($header, 'AÃ§Ä±klama') !== false) {
                $map['description'] = $index;
            } elseif (stripos($header, 'Satılacak Fiyat') !== false || stripos($header, 'SatÄ±lacak Fiyat') !== false) {
                $map['price'] = $index;
            } elseif (stripos($header, 'Stok Adedi') !== false) {
                $map['stock'] = $index;
            } elseif (stripos($header, 'Marka') !== false) {
                $map['brand'] = $index;
            } elseif (stripos($header, 'Kategori') !== false) {
                $map['category'] = $index;
            } elseif (stripos($header, 'Renk') !== false) {
                $map['color'] = $index;
            } elseif (stripos($header, 'Beden') !== false) {
                $map['size'] = $index;
            } elseif (stripos($header, 'Görsel') !== false || stripos($header, 'GÃ¶rsel') !== false) {
                if (!isset($map['images'])) {
                    $map['images'] = array();
                }
                $map['images'][] = $index;
            }
        }
        
        return $map;
    }
    
    private function extract_product_data($row, $column_map) {
        $data = array(
            'barcode' => isset($column_map['barcode']) ? trim($row[$column_map['barcode']]) : '',
            'title' => isset($column_map['title']) ? trim($row[$column_map['title']]) : '',
            'description' => isset($column_map['description']) ? trim($row[$column_map['description']]) : '',
            'price' => isset($column_map['price']) ? floatval(str_replace(',', '.', $row[$column_map['price']])) : 0,
            'stock' => isset($column_map['stock']) ? intval($row[$column_map['stock']]) : 0,
            'brand' => isset($column_map['brand']) ? trim($row[$column_map['brand']]) : '',
            'category' => isset($column_map['category']) ? trim($row[$column_map['category']]) : '',
            'color' => isset($column_map['color']) ? trim($row[$column_map['color']]) : '',
            'size' => isset($column_map['size']) ? trim($row[$column_map['size']]) : '',
            'images' => array()
        );
        
        // Görselleri topla
        if (isset($column_map['images'])) {
            foreach ($column_map['images'] as $img_index) {
                if (isset($row[$img_index]) && !empty(trim($row[$img_index]))) {
                    $data['images'][] = trim($row[$img_index]);
                }
            }
        }
        
        return $data;
    }
    
    private function find_product_by_sku($sku) {
        global $wpdb;
        
        $product_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_sku' AND meta_value = %s LIMIT 1",
            $sku
        ));
        
        return $product_id ? intval($product_id) : null;
    }
    
    private function create_woo_product_from_csv($data, $existing_id, $import_images) {
        try {
            if ($existing_id) {
                $product = wc_get_product($existing_id);
            } else {
                $product = new WC_Product_Simple();
            }
            
            // Temel bilgiler
            $product->set_name($data['title']);
            $product->set_description($data['description']);
            $product->set_sku($data['barcode']);
            $product->set_regular_price($data['price']);
            $product->set_stock_quantity($data['stock']);
            $product->set_manage_stock(true);
            $product->set_stock_status($data['stock'] > 0 ? 'instock' : 'outofstock');
            
            // Kategori eşleştir
            if (!empty($data['category'])) {
                $category_id = $this->find_or_create_category($data['category']);
                if ($category_id) {
                    $product->set_category_ids(array($category_id));
                }
            }
            
            // Görseller
            if ($import_images && !empty($data['images'])) {
                $image_ids = array();
                foreach ($data['images'] as $image_url) {
                    $image_id = $this->upload_image_from_url($image_url);
                    if ($image_id) {
                        $image_ids[] = $image_id;
                    }
                }
                
                if (!empty($image_ids)) {
                    $product->set_image_id($image_ids[0]);
                    if (count($image_ids) > 1) {
                        $product->set_gallery_image_ids(array_slice($image_ids, 1));
                    }
                }
            }
            
            // Ürünü kaydet
            $product_id = $product->save();
            
            return array('success' => true, 'product_id' => $product_id);
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    private function find_or_create_category($category_name) {
        // Önce kategori eşleştirmesine bak
        global $wpdb;
        
        $mapping = $wpdb->get_row($wpdb->prepare(
            "SELECT woo_category_id FROM {$wpdb->prefix}trendyol_categories WHERE trendyol_category_name = %s",
            $category_name
        ));
        
        if ($mapping && $mapping->woo_category_id) {
            return intval($mapping->woo_category_id);
        }
        
        // Kategori yoksa oluştur
        $term = term_exists($category_name, 'product_cat');
        if (!$term) {
            $term = wp_insert_term($category_name, 'product_cat');
        }
        
        return is_array($term) ? $term['term_id'] : 0;
    }
    
    public function ajax_sync_orders() {
        check_ajax_referer('trendyol_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Yetkiniz yok');
        }
        
        $result = $this->sync_orders_from_trendyol();
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    private function sync_orders_from_trendyol() {
        global $wpdb;
        
        $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}trendyol_settings ORDER BY id DESC LIMIT 1");
        
        if (!$settings || !$settings->api_key) {
            return array('success' => false, 'message' => 'API ayarları yapılmamış');
        }
        
        // Son 30 günün siparişlerini çek
        $start_date = date('Y-m-d', strtotime('-30 days'));
        $end_date = date('Y-m-d');
        
        $url = 'https://api.trendyol.com/sapigw/suppliers/' . $settings->supplier_id . '/orders';
        $url = add_query_arg(array(
            'startDate' => strtotime($start_date) * 1000,
            'endDate' => strtotime($end_date) * 1000,
            'page' => 0,
            'size' => 100
        ), $url);
        
        $user_agent = $settings->supplier_id . ' - SelfIntegration';
        
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER => array(
                'Authorization: Basic ' . base64_encode($settings->api_key . ':' . $settings->api_secret),
                'Content-Type: application/json',
                'User-Agent: ' . $user_agent
            )
        ));
        
        $body = curl_exec($ch);
        $response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($response_code !== 200) {
            return array('success' => false, 'message' => 'API HTTP Hatası: ' . $response_code);
        }
        
        $data = json_decode($body, true);
        
        if (!isset($data['content']) || !is_array($data['content'])) {
            return array('success' => false, 'message' => 'Sipariş verisi alınamadı');
        }
        
        $orders = $data['content'];
        $processed = 0;
        $success = 0;
        $failed = 0;
        
        foreach ($orders as $trendyol_order) {
            $processed++;
            
            try {
                $result = $this->save_trendyol_order($trendyol_order);
                if ($result['success']) {
                    $success++;
                } else {
                    $failed++;
                }
            } catch (Exception $e) {
                $failed++;
            }
        }
        
        return array(
            'success' => true,
            'processed' => $processed,
            'success_count' => $success,
            'failed_count' => $failed
        );
    }
    
    private function save_trendyol_order($order_data) {
        global $wpdb;
        
        // Sipariş zaten var mı kontrol et
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}trendyol_orders WHERE trendyol_order_id = %s",
            $order_data['id']
        ));
        
        // Müşteri bilgilerini hazırla
        $customer_name = isset($order_data['customerFirstName']) && isset($order_data['customerLastName']) 
            ? $order_data['customerFirstName'] . ' ' . $order_data['customerLastName'] 
            : 'Trendyol Müşteri';
        
        $shipping_address = '';
        if (isset($order_data['shipmentAddress'])) {
            $addr = $order_data['shipmentAddress'];
            $shipping_address = implode(', ', array_filter(array(
                $addr['address'] ?? '',
                $addr['district'] ?? '',
                $addr['city'] ?? '',
                $addr['cityCode'] ?? ''
            )));
        }
        
        $order_info = array(
            'trendyol_order_id' => $order_data['id'],
            'order_number' => $order_data['orderNumber'] ?? $order_data['id'],
            'customer_name' => $customer_name,
            'customer_email' => $order_data['customerEmail'] ?? '',
            'customer_phone' => $order_data['customerPhone'] ?? '',
            'shipping_address' => $shipping_address,
            'order_status' => $order_data['status'] ?? 'Created',
            'payment_status' => 'paid',
            'total_amount' => $order_data['totalPrice'] ?? 0,
            'currency' => $order_data['currency'] ?? 'TRY',
            'cargo_provider' => $order_data['cargoProviderName'] ?? '',
            'cargo_tracking_number' => $order_data['cargoTrackingNumber'] ?? '',
            'order_date' => date('Y-m-d H:i:s', $order_data['orderDate'] / 1000),
            'sync_status' => 'pending'
        );
        
        if ($existing) {
            // Güncelle
            $wpdb->update(
                $wpdb->prefix . 'trendyol_orders',
                $order_info,
                array('id' => $existing->id)
            );
            $order_id = $existing->id;
        } else {
            // Yeni ekle
            $wpdb->insert($wpdb->prefix . 'trendyol_orders', $order_info);
            $order_id = $wpdb->insert_id;
            
            // Sipariş ürünlerini ekle
            if (isset($order_data['lines']) && is_array($order_data['lines'])) {
                foreach ($order_data['lines'] as $line) {
                    $wpdb->insert(
                        $wpdb->prefix . 'trendyol_order_items',
                        array(
                            'order_id' => $order_id,
                            'trendyol_product_id' => $line['productId'] ?? '',
                            'product_name' => $line['productName'] ?? '',
                            'quantity' => $line['quantity'] ?? 1,
                            'price' => $line['price'] ?? 0,
                            'total' => $line['totalPrice'] ?? 0,
                            'barcode' => $line['barcode'] ?? '',
                            'sku' => $line['merchantSku'] ?? ''
                        )
                    );
                }
            }
            
            // Otomatik WooCommerce siparişi oluştur
            $this->create_woo_order_from_trendyol($order_id);
        }
        
        return array('success' => true, 'order_id' => $order_id);
    }
    
    private function create_woo_order_from_trendyol($trendyol_order_id) {
        global $wpdb;
        
        $order = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}trendyol_orders WHERE id = %d",
            $trendyol_order_id
        ));
        
        if (!$order) {
            return false;
        }
        
        try {
            // WooCommerce siparişi oluştur
            $woo_order = wc_create_order();
            
            // Sipariş ürünlerini ekle
            $items = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}trendyol_order_items WHERE order_id = %d",
                $trendyol_order_id
            ));
            
            foreach ($items as $item) {
                // Ürünü bul (barcode veya SKU ile)
                $product_id = null;
                if ($item->barcode) {
                    $product_id = $this->find_product_by_sku($item->barcode);
                }
                
                if ($product_id) {
                    $product = wc_get_product($product_id);
                    $woo_order->add_product($product, $item->quantity, array(
                        'subtotal' => $item->price * $item->quantity,
                        'total' => $item->total
                    ));
                } else {
                    // Ürün bulunamadıysa not ekle
                    $woo_order->add_order_note(
                        sprintf('Trendyol ürünü bulunamadı: %s (Barkod: %s)', $item->product_name, $item->barcode)
                    );
                }
            }
            
            // Müşteri bilgilerini ekle
            $address = array(
                'first_name' => explode(' ', $order->customer_name)[0] ?? '',
                'last_name' => explode(' ', $order->customer_name)[1] ?? '',
                'email' => $order->customer_email,
                'phone' => $order->customer_phone,
                'address_1' => $order->shipping_address,
                'city' => '',
                'postcode' => '',
                'country' => 'TR'
            );
            
            $woo_order->set_address($address, 'billing');
            $woo_order->set_address($address, 'shipping');
            
            // Sipariş durumu
            $status_map = array(
                'Created' => 'processing',
                'Approved' => 'processing',
                'Shipped' => 'on-hold',
                'Delivered' => 'completed',
                'Cancelled' => 'cancelled'
            );
            
            $woo_status = $status_map[$order->order_status] ?? 'processing';
            $woo_order->set_status($woo_status);
            
            // Ödeme tamamlandı olarak işaretle
            $woo_order->set_date_paid(time());
            $woo_order->payment_complete();
            
            // Kargo bilgisi ekle
            if ($order->cargo_tracking_number) {
                $woo_order->add_order_note(
                    sprintf('Kargo Firması: %s | Takip No: %s', $order->cargo_provider, $order->cargo_tracking_number)
                );
            }
            
            // Trendyol sipariş numarasını ekle
            $woo_order->add_order_note('Trendyol Sipariş No: ' . $order->order_number);
            
            $woo_order->calculate_totals();
            $woo_order_id = $woo_order->save();
            
            // Veritabanını güncelle
            $wpdb->update(
                $wpdb->prefix . 'trendyol_orders',
                array(
                    'woo_order_id' => $woo_order_id,
                    'sync_status' => 'synced',
                    'last_synced_at' => current_time('mysql')
                ),
                array('id' => $trendyol_order_id)
            );
            
            return $woo_order_id;
            
        } catch (Exception $e) {
            $wpdb->update(
                $wpdb->prefix . 'trendyol_orders',
                array(
                    'sync_status' => 'failed',
                    'sync_errors' => $e->getMessage()
                ),
                array('id' => $trendyol_order_id)
            );
            
            return false;
        }
    }
    
    public function add_cargo_info_metabox() {
        add_meta_box(
            'trendyol_cargo_info',
            '📦 Trendyol Kargo Bilgileri',
            array($this, 'render_cargo_info_metabox'),
            'shop_order',
            'side',
            'default'
        );
    }
    
    public function render_cargo_info_metabox($post) {
        $order = wc_get_order($post->ID);
        
        $tracking_number = $order->get_meta('_tracking_number');
        $cargo_provider = $order->get_meta('_cargo_provider');
        
        echo '<div style="padding: 10px;">';
        
        echo '<p><label><strong>Kargo Firması:</strong></label><br>';
        echo '<input type="text" name="cargo_provider" value="' . esc_attr($cargo_provider) . '" style="width: 100%;" placeholder="Örn: Yurtiçi Kargo"></p>';
        
        echo '<p><label><strong>Takip Numarası:</strong></label><br>';
        echo '<input type="text" name="tracking_number" value="' . esc_attr($tracking_number) . '" style="width: 100%;" placeholder="Örn: 123456789"></p>';
        
        echo '<p class="description">Kargo bilgilerini girin ve siparişi "Tamamlandı" durumuna alın. Otomatik olarak Trendyol\'a bildirilecek.</p>';
        
        echo '</div>';
        
        // Save hook
        if (!has_action('woocommerce_process_shop_order_meta')) {
            add_action('woocommerce_process_shop_order_meta', array($this, 'save_cargo_info_metabox'), 10, 2);
        }
    }
    
    public function save_cargo_info_metabox($post_id, $post) {
        if (isset($_POST['tracking_number'])) {
            $order = wc_get_order($post_id);
            $order->update_meta_data('_tracking_number', sanitize_text_field($_POST['tracking_number']));
            $order->update_meta_data('_cargo_provider', sanitize_text_field($_POST['cargo_provider']));
            $order->save();
        }
    }
    
    public function run_auto_sync_orders() {
        global $wpdb;
        
        $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}trendyol_settings ORDER BY id DESC LIMIT 1");
        
        if ($settings && $settings->auto_sync_enabled) {
            $result = $this->sync_orders_from_trendyol();
            
            // Yeni sipariş varsa e-posta gönder
            if ($result['success'] && $result['success_count'] > 0) {
                $this->send_new_order_notification($result);
            }
        }
    }
    
    private function send_new_order_notification($sync_result) {
        $admin_email = get_option('admin_email');
        $subject = 'Trendyol\'dan Yeni Sipariş - ' . $sync_result['success_count'] . ' adet';
        
        $message = "Merhaba,\n\n";
        $message .= "Trendyol'dan toplam " . $sync_result['success_count'] . " yeni sipariş alındı.\n\n";
        $message .= "Detaylar:\n";
        $message .= "- İşlenen: " . $sync_result['processed'] . " sipariş\n";
        $message .= "- Başarılı: " . $sync_result['success_count'] . " sipariş\n";
        $message .= "- Başarısız: " . $sync_result['failed_count'] . " sipariş\n\n";
        $message .= "Siparişleri görüntülemek için: " . admin_url('admin.php?page=trendyol-orders') . "\n\n";
        $message .= "İyi çalışmalar!";
        
        wp_mail($admin_email, $subject, $message);
    }
    
    public function on_woo_order_status_changed($order_id, $old_status, $new_status, $order) {
        global $wpdb;
        
        // Bu WooCommerce siparişi Trendyol'dan mı?
        $trendyol_order = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}trendyol_orders WHERE woo_order_id = %d",
            $order_id
        ));
        
        if (!$trendyol_order) {
            return; // Trendyol siparişi değil
        }
        
        // Durumu Trendyol'a bildir
        $this->update_trendyol_order_status($trendyol_order, $new_status, $order);
    }
    
    private function update_trendyol_order_status($trendyol_order, $woo_status, $woo_order) {
        global $wpdb;
        
        $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}trendyol_settings ORDER BY id DESC LIMIT 1");
        
        if (!$settings || !$settings->api_key) {
            return false;
        }
        
        // WooCommerce durumunu Trendyol durumuna çevir
        $status_map = array(
            'processing' => 'Processing',
            'on-hold' => 'Processing',
            'completed' => 'Shipped',
            'cancelled' => 'Cancelled'
        );
        
        $trendyol_status = $status_map[$woo_status] ?? null;
        
        if (!$trendyol_status) {
            return false; // Eşleşme yok
        }
        
        // Kargo bilgisi varsa ekle
        $tracking_number = $woo_order->get_meta('_tracking_number');
        $cargo_provider = $woo_order->get_meta('_cargo_provider');
        
        $api_data = array(
            'status' => $trendyol_status
        );
        
        if ($trendyol_status === 'Shipped' && $tracking_number) {
            $api_data['cargoTrackingNumber'] = $tracking_number;
            $api_data['cargoProviderName'] = $cargo_provider ?: 'Diğer';
        }
        
        // Trendyol API'sine gönder
        $url = 'https://api.trendyol.com/sapigw/suppliers/' . $settings->supplier_id . '/orders/' . $trendyol_order->trendyol_order_id;
        $user_agent = $settings->supplier_id . ' - SelfIntegration';
        
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => 'PUT',
            CURLOPT_POSTFIELDS => json_encode($api_data),
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER => array(
                'Authorization: Basic ' . base64_encode($settings->api_key . ':' . $settings->api_secret),
                'Content-Type: application/json',
                'User-Agent: ' . $user_agent
            )
        ));
        
        $body = curl_exec($ch);
        $response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($response_code === 200) {
            // Başarılı
            $woo_order->add_order_note('Trendyol durumu güncellendi: ' . $trendyol_status);
            return true;
        } else {
            // Hata
            $woo_order->add_order_note('Trendyol durum güncelleme hatası: ' . $response_code);
            return false;
        }
    }
}

// Eklentiyi başlat
Trendyol_WooCommerce_Sync::get_instance();