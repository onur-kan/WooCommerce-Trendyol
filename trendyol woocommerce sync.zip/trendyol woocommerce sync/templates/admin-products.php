<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap trendyol-admin">
    <h1>📦 Senkronize Edilmiş Ürünler</h1>
    
    <div class="trendyol-card">
        <?php if (!empty($products)): ?>
            <div class="products-header">
                <p>Toplam <strong><?php echo count($products); ?></strong> ürün gösteriliyor</p>
            </div>

            <table class="wp-list-table widefat fixed striped products-table">
                <thead>
                    <tr>
                        <th width="8%">Görsel</th>
                        <th width="25%">Ürün Adı</th>
                        <th width="12%">Trendyol ID</th>
                        <th width="12%">WooCommerce ID</th>
                        <th width="10%">Fiyat</th>
                        <th width="8%">Stok</th>
                        <th width="12%">Durum</th>
                        <th width="13%">Son Sync</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $product): ?>
                        <?php
                        $images = json_decode($product->images, true);
                        $first_image = !empty($images) ? $images[0]['url'] : '';
                        $woo_product = $product->woo_product_id ? wc_get_product($product->woo_product_id) : null;
                        ?>
                        <tr>
                            <td>
                                <?php if ($first_image): ?>
                                    <img src="<?php echo esc_url($first_image); ?>" 
                                         alt="<?php echo esc_attr($product->title); ?>" 
                                         style="max-width: 60px; height: auto; border-radius: 4px;">
                                <?php else: ?>
                                    <div class="no-image">📷</div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?php echo esc_html($product->title); ?></strong>
                                <?php if ($product->barcode): ?>
                                    <br><small>Barkod: <?php echo esc_html($product->barcode); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <code><?php echo esc_html($product->trendyol_product_id); ?></code>
                            </td>
                            <td>
                                <?php if ($woo_product): ?>
                                    <a href="<?php echo get_edit_post_link($product->woo_product_id); ?>" target="_blank">
                                        #<?php echo esc_html($product->woo_product_id); ?>
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?php echo number_format($product->price, 2); ?> ₺</strong>
                            </td>
                            <td>
                                <span class="stock-badge <?php echo $product->stock_quantity > 0 ? 'in-stock' : 'out-of-stock'; ?>">
                                    <?php echo esc_html($product->stock_quantity); ?>
                                </span>
                            </td>
                            <td>
                                <?php
                                $status_class = 'status-' . $product->sync_status;
                                $status_text = array(
                                    'synced' => '✓ Senkronize',
                                    'pending' => '⏳ Bekliyor',
                                    'failed' => '✗ Başarısız'
                                );
                                ?>
                                <span class="status-badge <?php echo esc_attr($status_class); ?>">
                                    <?php echo $status_text[$product->sync_status] ?? $product->sync_status; ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($product->last_synced_at): ?>
                                    <small><?php echo esc_html(date('d.m.Y H:i', strtotime($product->last_synced_at))); ?></small>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-products">
                <p>📭 Henüz senkronize edilmiş ürün yok.</p>
                <p><a href="admin.php?page=trendyol-sync" class="button button-primary">Senkronizasyon Başlat</a></p>
            </div>
        <?php endif; ?>
    </div>
</div>