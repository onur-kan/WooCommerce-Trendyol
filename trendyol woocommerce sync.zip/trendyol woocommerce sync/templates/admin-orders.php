<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap trendyol-admin">
    <h1>🛒 Trendyol Siparişleri</h1>
    
    <div class="trendyol-card">
        <div class="orders-header">
            <p>Trendyol'dan gelen siparişleri görüntüleyin ve WooCommerce'e aktarın</p>
            <button id="sync-orders-btn" class="button button-primary">
                🔄 Siparişleri Çek
            </button>
        </div>
        
        <div id="orders-sync-result" class="sync-result"></div>

        <?php if (!empty($orders)): ?>
            <table class="wp-list-table widefat fixed striped orders-table">
                <thead>
                    <tr>
                        <th width="10%">Sipariş No</th>
                        <th width="15%">Müşteri</th>
                        <th width="10%">Tutar</th>
                        <th width="10%">Durum</th>
                        <th width="12%">Kargo</th>
                        <th width="13%">Tarih</th>
                        <th width="10%">WooCommerce</th>
                        <th width="10%">Sync Durum</th>
                        <th width="10%">İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><strong><?php echo esc_html($order->order_number); ?></strong></td>
                            <td>
                                <?php echo esc_html($order->customer_name); ?>
                                <?php if ($order->customer_phone): ?>
                                    <br><small><?php echo esc_html($order->customer_phone); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><strong><?php echo number_format($order->total_amount, 2); ?> ₺</strong></td>
                            <td>
                                <?php
                                $status_colors = array(
                                    'Approved' => 'success',
                                    'Created' => 'pending',
                                    'Shipped' => 'info',
                                    'Delivered' => 'success',
                                    'Cancelled' => 'danger'
                                );
                                $color = $status_colors[$order->order_status] ?? 'pending';
                                ?>
                                <span class="status-badge status-<?php echo $color; ?>">
                                    <?php echo esc_html($order->order_status); ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($order->cargo_provider): ?>
                                    <?php echo esc_html($order->cargo_provider); ?>
                                    <?php if ($order->cargo_tracking_number): ?>
                                        <br><code><?php echo esc_html($order->cargo_tracking_number); ?></code>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <small><?php echo date('d.m.Y H:i', strtotime($order->order_date)); ?></small>
                            </td>
                            <td>
                                <?php if ($order->woo_order_id): ?>
                                    <a href="<?php echo admin_url('post.php?post=' . $order->woo_order_id . '&action=edit'); ?>" target="_blank">
                                        #<?php echo $order->woo_order_id; ?>
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">Yok</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                $sync_class = 'status-' . $order->sync_status;
                                $sync_text = array(
                                    'synced' => '✓ Senkronize',
                                    'pending' => '⏳ Bekliyor',
                                    'failed' => '✗ Başarısız'
                                );
                                ?>
                                <span class="status-badge <?php echo esc_attr($sync_class); ?>">
                                    <?php echo $sync_text[$order->sync_status] ?? $order->sync_status; ?>
                                </span>
                            </td>
                            <td>
                                <?php if (!$order->woo_order_id): ?>
                                    <button class="button button-small create-order-btn" 
                                            data-order-id="<?php echo esc_attr($order->id); ?>">
                                        Oluştur
                                    </button>
                                <?php else: ?>
                                    <button class="button button-small" disabled>Mevcut</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-orders">
                <p>📭 Henüz sipariş yok.</p>
                <p>Yukarıdaki "Siparişleri Çek" butonuna tıklayarak Trendyol'dan siparişleri çekin.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- İstatistikler -->
    <?php if (!empty($orders)): ?>
        <div class="trendyol-card" style="margin-top: 20px;">
            <h3>📊 Sipariş İstatistikleri</h3>
            <?php
            global $wpdb;
            $stats = $wpdb->get_row("
                SELECT 
                    COUNT(*) as total_orders,
                    SUM(total_amount) as total_revenue,
                    COUNT(CASE WHEN sync_status = 'synced' THEN 1 END) as synced_orders,
                    COUNT(CASE WHEN sync_status = 'pending' THEN 1 END) as pending_orders
                FROM {$wpdb->prefix}trendyol_orders
            ");
            ?>
            <div class="stats-grid">
                <div class="stat-box">
                    <div class="stat-icon">🛒</div>
                    <div class="stat-number"><?php echo number_format($stats->total_orders); ?></div>
                    <div class="stat-label">Toplam Sipariş</div>
                </div>
                <div class="stat-box">
                    <div class="stat-icon">💰</div>
                    <div class="stat-number"><?php echo number_format($stats->total_revenue, 2); ?> ₺</div>
                    <div class="stat-label">Toplam Ciro</div>
                </div>
                <div class="stat-box">
                    <div class="stat-icon">✓</div>
                    <div class="stat-number"><?php echo number_format($stats->synced_orders); ?></div>
                    <div class="stat-label">Senkronize</div>
                </div>
                <div class="stat-box">
                    <div class="stat-icon">⏳</div>
                    <div class="stat-number"><?php echo number_format($stats->pending_orders); ?></div>
                    <div class="stat-label">Bekleyen</div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<style>
.orders-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 1px solid #ddd;
}

.orders-table {
    font-size: 13px;
}

.no-orders {
    text-align: center;
    padding: 60px;
    color: #666;
    background: #f9f9f9;
    border: 2px dashed #ddd;
    border-radius: 8px;
}

.status-success {
    background: #d4edda;
    color: #155724;
}

.status-info {
    background: #d1ecf1;
    color: #0c5460;
}

.status-danger {
    background: #f8d7da;
    color: #721c24;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
    margin-top: 20px;
}

.stat-box {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 25px;
    border-radius: 8px;
    text-align: center;
}

.stat-box:nth-child(2) {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
}

.stat-box:nth-child(3) {
    background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
}

.stat-box:nth-child(4) {
    background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
}

.stat-icon {
    font-size: 36px;
    margin-bottom: 10px;
}

.stat-number {
    font-size: 28px;
    font-weight: bold;
    margin-bottom: 5px;
}

.stat-label {
    font-size: 13px;
    opacity: 0.9;
}
</style>