<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap trendyol-admin">
    <h1>📤 CSV/Excel İçe Aktar</h1>
    
    <div class="trendyol-card">
        <h2>Trendyol Ürünlerini Yükle</h2>
        <p>Trendyol'dan indirdiğiniz CSV dosyasını buradan yükleyerek tüm ürünleri otomatik olarak WooCommerce'e aktarabilirsiniz.</p>
        
        <form id="csv-upload-form" enctype="multipart/form-data">
            <table class="form-table">
                <tr>
                    <th><label for="csv_file">CSV/Excel Dosyası</label></th>
                    <td>
                        <input type="file" 
                               id="csv_file" 
                               name="csv_file" 
                               accept=".csv,.xlsx,.xls" 
                               required>
                        <p class="description">
                            Trendyol'dan indirdiğiniz CSV veya Excel dosyasını seçin.<br>
                            Desteklenen formatlar: .csv, .xlsx, .xls
                        </p>
                    </td>
                </tr>
                
                <tr>
                    <th><label for="import_images">Görselleri İndir</label></th>
                    <td>
                        <label>
                            <input type="checkbox" 
                                   id="import_images" 
                                   name="import_images" 
                                   checked>
                            Ürün görsellerini otomatik olarak indir ve ekle
                        </label>
                    </td>
                </tr>
                
                <tr>
                    <th><label for="update_existing">Mevcut Ürünleri Güncelle</label></th>
                    <td>
                        <label>
                            <input type="checkbox" 
                                   id="update_existing" 
                                   name="update_existing">
                            Barkod eşleşen ürünleri güncelle (yeni ürün oluşturma)
                        </label>
                    </td>
                </tr>
            </table>
            
            <p class="submit">
                <button type="submit" class="button button-primary button-large">
                    📤 Dosyayı Yükle ve İçe Aktar
                </button>
            </p>
        </form>
        
        <div id="import-progress" style="display: none;">
            <h3>İçe Aktarma Durumu</h3>
            <div class="progress-bar">
                <div class="progress-fill" id="progress-fill"></div>
            </div>
            <p id="progress-text">Hazırlanıyor...</p>
        </div>
        
        <div id="import-result" class="sync-result"></div>
    </div>
    
    <!-- Örnek CSV Formatı -->
    <div class="trendyol-card">
        <h3>📋 CSV Format Bilgisi</h3>
        <p>CSV dosyanız şu sütunları içermelidir:</p>
        <ul style="list-style: disc; padding-left: 20px;">
            <li><strong>Barkod</strong> - Ürün barkodu (zorunlu)</li>
            <li><strong>Ürün Adı</strong> - Ürün başlığı (zorunlu)</li>
            <li><strong>Ürün Açıklaması</strong> - Detaylı açıklama</li>
            <li><strong>Trendyol'da Satılacak Fiyat (KDV Dahil)</strong> - Satış fiyatı</li>
            <li><strong>Ürün Stok Adedi</strong> - Stok miktarı</li>
            <li><strong>Marka</strong> - Ürün markası</li>
            <li><strong>Kategori İsmi</strong> - Kategori adı</li>
            <li><strong>Görsel 1-8</strong> - Ürün görselleri (URL)</li>
            <li><strong>Ürün Rengi</strong> - Renk bilgisi</li>
            <li><strong>Beden</strong> - Beden bilgisi</li>
        </ul>
    </div>
    
    <!-- Yardım -->
    <div class="trendyol-card">
        <h3>❓ Sık Sorulan Sorular</h3>
        <details>
            <summary><strong>CSV dosyasını nereden indirebilirim?</strong></summary>
            <p>Trendyol Seller Panel → Ürünlerim → Ürünlerimi İndir butonuna tıklayın.</p>
        </details>
        
        <details>
            <summary><strong>Kaç ürün yükleyebilirim?</strong></summary>
            <p>Tek seferde binlerce ürün yükleyebilirsiniz. Sistem otomatik olarak gruplar halinde işler.</p>
        </details>
        
        <details>
            <summary><strong>Kategoriler nasıl eşleşir?</strong></summary>
            <p>Önce "Kategori Eşleştirme" sayfasından Trendyol ve WooCommerce kategorilerini eşleştirin. Sistem otomatik olarak doğru kategoriye atar.</p>
        </details>
        
        <details>
            <summary><strong>Görseller nasıl işlenir?</strong></summary>
            <p>Görseller otomatik olarak Trendyol CDN'den indirilir ve WordPress medya kütüphanesine eklenir.</p>
        </details>
    </div>
</div>

<style>
.progress-bar {
    width: 100%;
    height: 30px;
    background: #f0f0f0;
    border-radius: 15px;
    overflow: hidden;
    margin: 20px 0;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #FF6000, #FFA500);
    width: 0%;
    transition: width 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
}

#progress-text {
    text-align: center;
    font-size: 14px;
    color: #666;
}

details {
    margin: 10px 0;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

details summary {
    cursor: pointer;
    font-weight: 600;
    padding: 5px;
}

details summary:hover {
    background: #f9f9f9;
}

details[open] {
    background: #f9f9f9;
}

details p {
    margin: 10px 0 0 20px;
    color: #666;
}
</style>