<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap trendyol-admin">
    <h1>📋 Senkronizasyon Logları</h1>
    
    <div class="trendyol-card">
        <?php if (!empty($logs)): ?>
            <div class="logs-header">
                <p>Son <strong><?php echo count($logs); ?></strong> log kaydı gösteriliyor</p>
            </div>

            <table class="wp-list-table widefat fixed striped logs-table">
                <thead>
                    <tr>
                        <th width="8%">ID</th>
                        <th width="15%">Başlangıç</th>
                        <th width="15%">Bitiş</th>
                        <th width="12%">Yön</th>
                        <th width="10%">İşlenen</th>
                        <th width="10%">Başarılı</th>
                        <th width="10%">Başarısız</th>
                        <th width="10%">Süre (sn)</th>
                        <th width="10%">Durum</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <?php
                        $success_rate = $log->products_processed > 0 
                            ? round(($log->products_success / $log->products_processed) * 100, 1) 
                            : 0;
                        $status_class = $log->products_failed == 0 ? 'success' : ($log->products_success > 0 ? 'partial' : 'failed');
                        ?>
                        <tr>
                            <td><strong>#<?php echo esc_html($log->id); ?></strong></td>
                            <td>
                                <?php if ($log->sync_started_at): ?>
                                    <?php echo esc_html(date('d.m.Y H:i:s', strtotime($log->sync_started_at))); ?>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($log->sync_completed_at): ?>
                                    <?php echo esc_html(date('d.m.Y H:i:s', strtotime($log->sync_completed_at))); ?>
                                <?php else: ?>
                                    <span class="text-muted">Devam ediyor...</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                $direction_text = array(
                                    'trendyol_to_woo' => '🔽 Trendyol → WooCommerce',
                                    'woo_to_trendyol' => '🔼 WooCommerce → Trendyol',
                                );
                                ?>
                                <small><?php echo $direction_text[$log->direction] ?? $log->direction; ?></small>
                            </td>
                            <td>
                                <span class="badge badge-info"><?php echo number_format($log->products_processed); ?></span>
                            </td>
                            <td>
                                <span class="badge badge-success"><?php echo number_format($log->products_success); ?></span>
                            </td>
                            <td>
                                <span class="badge badge-danger"><?php echo number_format($log->products_failed); ?></span>
                            </td>
                            <td>
                                <?php echo number_format($log->execution_time, 2); ?> sn
                            </td>
                            <td>
                                <span class="log-status status-<?php echo esc_attr($status_class); ?>">
                                    <?php if ($status_class == 'success'): ?>
                                        ✓ Başarılı
                                    <?php elseif ($status_class == 'partial'): ?>
                                        ⚠ Kısmi (<?php echo $success_rate; ?>%)
                                    <?php else: ?>
                                        ✗ Başarısız
                                    <?php endif; ?>
                                </span>
                            </td>
                        </tr>
                        <?php if ($log->error_details): ?>
                            <tr class="error-details-row">
                                <td colspan="9">
                                    <div class="error-details">
                                        <strong>🔴 Hata Detayları:</strong>
                                        <pre><?php echo esc_html($log->error_details); ?></pre>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-logs">
                <p>📭 Henüz log kaydı yok.</p>
                <p>İlk senkronizasyonu başlatın ve loglar burada görünecek.</p>
            </div>
        <?php endif; ?>
    </div>

    <?php if (!empty($logs)): ?>
        <div class="trendyol-card" style="margin-top: 20px;">
            <h3>📊 Genel İstatistikler</h3>
            <?php
            global $wpdb;
            $stats = $wpdb->get_row("
                SELECT 
                    COUNT(*) as total_syncs,
                    SUM(products_processed) as total_processed,
                    SUM(products_success) as total_success,
                    SUM(products_failed) as total_failed,
                    AVG(execution_time) as avg_time
                FROM {$wpdb->prefix}trendyol_sync_log
            ");
            
            $overall_success_rate = $stats->total_processed > 0 
                ? round(($stats->total_success / $stats->total_processed) * 100, 1) 
                : 0;
            ?>
            <div class="stats-info">
                <p><strong>Toplam Senkronizasyon:</strong> <?php echo number_format($stats->total_syncs); ?></p>
                <p><strong>Toplam İşlenen Ürün:</strong> <?php echo number_format($stats->total_processed); ?></p>
                <p><strong>Başarı Oranı:</strong> <?php echo $overall_success_rate; ?>%</p>
                <p><strong>Ortalama Süre:</strong> <?php echo number_format($stats->avg_time, 1); ?> saniye</p>
            </div>
        </div>
    <?php endif; ?>
</div>