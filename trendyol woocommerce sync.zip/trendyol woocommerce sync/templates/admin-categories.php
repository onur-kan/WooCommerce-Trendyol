<?php
if (!defined('ABSPATH')) {
    exit;
}

// WooCommerce kategorilerini al
$woo_categories = get_terms(array(
    'taxonomy' => 'product_cat',
    'hide_empty' => false,
));
?>

<div class="wrap trendyol-admin">
    <h1>📁 Kategori Eşleştirme</h1>
    
    <div class="trendyol-card">
        <div class="category-header">
            <p>Trendyol kategorilerini WooCommerce kategorileriyle eşleştirin. Bu sayede ürünler doğru kategorilere aktarılır.</p>
            <button id="fetch-trendyol-categories" class="button button-primary">
                🔄 Trendyol Kategorilerini Çek
            </button>
        </div>

        <div id="category-fetch-result" class="category-result"></div>

        <?php if (!empty($mappings)): ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th width="5%">ID</th>
                        <th width="35%">Trendyol Kategorisi</th>
                        <th width="35%">WooCommerce Kategorisi</th>
                        <th width="15%">Durum</th>
                        <th width="10%">İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($mappings as $mapping): ?>
                        <tr>
                            <td><?php echo esc_html($mapping->trendyol_category_id); ?></td>
                            <td>
                                <strong><?php echo esc_html($mapping->trendyol_category_name); ?></strong>
                            </td>
                            <td>
                                <select class="woo-category-select" 
                                        data-trendyol-id="<?php echo esc_attr($mapping->trendyol_category_id); ?>">
                                    <option value="">-- Kategori Seçin --</option>
                                    <?php foreach ($woo_categories as $woo_cat): ?>
                                        <option value="<?php echo esc_attr($woo_cat->term_id); ?>" 
                                                <?php selected($mapping->woo_category_id, $woo_cat->term_id); ?>>
                                            <?php echo esc_html($woo_cat->name); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <?php if ($mapping->woo_category_id): ?>
                                    <span class="status-badge status-mapped">✓ Eşleştirilmiş</span>
                                <?php else: ?>
                                    <span class="status-badge status-pending">⚠ Bekliyor</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="button button-small map-category-btn" 
                                        data-trendyol-id="<?php echo esc_attr($mapping->trendyol_category_id); ?>">
                                    Kaydet
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-categories">
                <p>📭 Henüz kategori verisi yok. Yukarıdaki butona tıklayarak Trendyol kategorilerini çekin.</p>
            </div>
        <?php endif; ?>
    </div>
</div>