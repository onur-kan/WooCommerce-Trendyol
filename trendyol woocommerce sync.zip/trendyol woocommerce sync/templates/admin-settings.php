<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap trendyol-admin">
    <h1>🔄 Trendyol WooCommerce Senkronizasyon</h1>
    
    <div class="trendyol-header">
        <div class="trendyol-version">Versiyon: <?php echo TRENDYOL_WOO_VERSION; ?></div>
    </div>

    <div class="trendyol-grid">
        <!-- Sol Taraf - Ayarlar -->
        <div class="trendyol-card">
            <h2>⚙️ API Ayarları</h2>
            
            <form id="trendyol-settings-form">
                <table class="form-table">
                    <tr>
                        <th><label for="supplier_id">Supplier ID</label></th>
                        <td>
                            <input type="text" 
                                   id="supplier_id" 
                                   name="supplier_id" 
                                   value="<?php echo esc_attr($settings->supplier_id ?? ''); ?>" 
                                   class="regular-text" 
                                   required>
                            <p class="description">Trendyol Seller Panel'den alınır</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="api_key">API Key</label></th>
                        <td>
                            <input type="text" 
                                   id="api_key" 
                                   name="api_key" 
                                   value="<?php echo esc_attr($settings->api_key ?? ''); ?>" 
                                   class="regular-text" 
                                   required>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="api_secret">API Secret</label></th>
                        <td>
                            <input type="password" 
                                   id="api_secret" 
                                   name="api_secret" 
                                   value="<?php echo esc_attr($settings->api_secret ?? ''); ?>" 
                                   class="regular-text" 
                                   required>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="sync_interval">Senkronizasyon Aralığı</label></th>
                        <td>
                            <select id="sync_interval" name="sync_interval">
                                <option value="1800" <?php selected($settings->sync_interval ?? 3600, 1800); ?>>30 Dakika</option>
                                <option value="3600" <?php selected($settings->sync_interval ?? 3600, 3600); ?>>1 Saat</option>
                                <option value="7200" <?php selected($settings->sync_interval ?? 3600, 7200); ?>>2 Saat</option>
                                <option value="14400" <?php selected($settings->sync_interval ?? 3600, 14400); ?>>4 Saat</option>
                                <option value="21600" <?php selected($settings->sync_interval ?? 3600, 21600); ?>>6 Saat</option>
                                <option value="43200" <?php selected($settings->sync_interval ?? 3600, 43200); ?>>12 Saat</option>
                            </select>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="auto_sync_enabled">Otomatik Senkronizasyon</label></th>
                        <td>
                            <label>
                                <input type="checkbox" 
                                       id="auto_sync_enabled" 
                                       name="auto_sync_enabled" 
                                       value="1" 
                                       <?php checked($settings->auto_sync_enabled ?? 0, 1); ?>>
                                Otomatik senkronizasyonu etkinleştir
                            </label>
                            <p class="description">Ürün ve sipariş senkronizasyonunu otomatik yapar</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><label for="order_notification">Sipariş Bildirimleri</label></th>
                        <td>
                            <label>
                                <input type="checkbox" 
                                       id="order_notification" 
                                       name="order_notification" 
                                       value="1" 
                                       <?php checked(get_option('trendyol_order_notification', 1), 1); ?>>
                                Yeni sipariş geldiğinde e-posta gönder
                            </label>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary button-large">
                        💾 Ayarları Kaydet
                    </button>
                </p>
            </form>
        </div>

        <!-- Sağ Taraf - Hızlı İşlemler -->
        <div class="trendyol-sidebar">
            <!-- API Test Butonu -->
            <div class="trendyol-card">
                <h3>🔍 API Bağlantı Testi</h3>
                <p>API bilgilerinizi test edin</p>
                <button id="test-api-btn" class="button button-secondary button-large" style="width: 100%; margin-bottom: 10px;">
                    🔌 Bağlantıyı Test Et
                </button>
                <div id="test-result" class="sync-result"></div>
            </div>
            
            <!-- Sync Butonu -->
            <div class="trendyol-card">
                <h3>🚀 Hızlı Senkronizasyon</h3>
                <p>Trendyol'daki tüm ürünleri şimdi senkronize et</p>
                <button id="sync-now-btn" class="button button-primary button-large button-hero">
                    ⚡ Şimdi Senkronize Et
                </button>
                <div id="sync-result" class="sync-result"></div>
            </div>

            <!-- Son Sync Bilgisi -->
            <div class="trendyol-card">
                <h3>📊 Son Senkronizasyon</h3>
                <?php if ($settings && $settings->last_sync_time): ?>
                    <p><strong>Tarih:</strong><br><?php echo esc_html($settings->last_sync_time); ?></p>
                <?php else: ?>
                    <p class="no-sync">Henüz senkronizasyon yapılmadı</p>
                <?php endif; ?>
            </div>

            <!-- İstatistikler -->
            <div class="trendyol-card">
                <h3>📈 İstatistikler</h3>
                <?php
                global $wpdb;
                $total_products = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}trendyol_products");
                $synced_products = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}trendyol_products WHERE sync_status = 'synced'");
                $categories = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}trendyol_categories WHERE woo_category_id IS NOT NULL");
                ?>
                <ul class="stats-list">
                    <li>
                        <span class="stat-label">Toplam Ürün:</span>
                        <span class="stat-value"><?php echo number_format($total_products); ?></span>
                    </li>
                    <li>
                        <span class="stat-label">Senkronize:</span>
                        <span class="stat-value"><?php echo number_format($synced_products); ?></span>
                    </li>
                    <li>
                        <span class="stat-label">Eşleşmiş Kategori:</span>
                        <span class="stat-value"><?php echo number_format($categories); ?></span>
                    </li>
                </ul>
            </div>

            <!-- Yardım -->
            <div class="trendyol-card">
                <h3>❓ Yardım</h3>
                <ul class="help-list">
                    <li><a href="admin.php?page=trendyol-categories">📁 Kategorileri Eşleştir</a></li>
                    <li><a href="admin.php?page=trendyol-products">📦 Ürünleri Görüntüle</a></li>
                    <li><a href="admin.php?page=trendyol-logs">📋 Logları İncele</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<style>
.trendyol-admin {
    margin: 20px 20px 0 0;
}

.trendyol-header {
    background: #fff;
    padding: 20px;
    margin-bottom: 20px;
    border-left: 4px solid #FF6000;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.trendyol-version {
    color: #666;
    font-size: 13px;
}

.trendyol-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 20px;
    margin-bottom: 20px;
}

.trendyol-card {
    background: #fff;
    padding: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    border-radius: 4px;
}

.trendyol-card h2,
.trendyol-card h3 {
    margin-top: 0;
    color: #333;
    border-bottom: 2px solid #FF6000;
    padding-bottom: 10px;
}

.button-hero {
    width: 100%;
    padding: 15px !important;
    height: auto !important;
    font-size: 16px !important;
    margin-bottom: 15px;
}

.sync-result {
    margin-top: 15px;
    padding: 10px;
    border-radius: 4px;
    display: none;
}

.sync-result.success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
    display: block;
}

.sync-result.error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
    display: block;
}

.sync-result.loading {
    background: #d1ecf1;
    color: #0c5460;
    border: 1px solid #bee5eb;
    display: block;
}

.stats-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.stats-list li {
    padding: 12px 0;
    border-bottom: 1px solid #eee;
    display: flex;
    justify-content: space-between;
}

.stats-list li:last-child {
    border-bottom: none;
}

.stat-value {
    font-weight: bold;
    color: #FF6000;
    font-size: 18px;
}

.help-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.help-list li {
    padding: 8px 0;
}

.help-list a {
    text-decoration: none;
    color: #0073aa;
}

.help-list a:hover {
    color: #FF6000;
}

.no-sync {
    color: #999;
    font-style: italic;
}

@media (max-width: 1280px) {
    .trendyol-grid {
        grid-template-columns: 1fr;
    }
}
</style>