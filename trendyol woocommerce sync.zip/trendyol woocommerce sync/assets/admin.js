jQuery(document).ready(function($) {
    'use strict';

    // API Test butonu
    $('#test-api-btn').on('click', function() {
        var $btn = $(this);
        var originalText = $btn.text();
        var $result = $('#test-result');
        
        // Önce ayarların kaydedilip kaydedilmediğini kontrol et
        var supplierId = $('#supplier_id').val();
        var apiKey = $('#api_key').val();
        var apiSecret = $('#api_secret').val();
        
        if (!supplierId || !apiKey || !apiSecret) {
            $result.removeClass('loading success').addClass('error')
                .html('⚠ Lütfen önce API bilgilerini kaydedin').show();
            return;
        }
        
        $btn.prop('disabled', true).html('⏳ Test ediliyor...');
        $result.removeClass('success error').addClass('loading').html('API bağlantısı test ediliyor...').show();
        
        $.ajax({
            url: trendyolAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'trendyol_test_api',
                nonce: trendyolAjax.nonce
            },
            timeout: 30000,
            success: function(response) {
                if (response.success) {
                    $result.removeClass('loading error').addClass('success').html('✓ API bağlantısı başarılı!<br>' + response.data);
                } else {
                    $result.removeClass('loading success').addClass('error').html('✗ ' + response.data);
                }
            },
            error: function(xhr, status, error) {
                var errorMsg = '✗ Bağlantı hatası';
                if (status === 'timeout') {
                    errorMsg = '✗ Zaman aşımı - API yanıt vermiyor';
                } else if (xhr.responseText) {
                    errorMsg = '✗ Sunucu hatası: ' + status;
                }
                $result.removeClass('loading success').addClass('error').html(errorMsg);
            },
            complete: function() {
                $btn.prop('disabled', false).text(originalText);
            }
        });
    });

    // Ayarları kaydet
    $('#trendyol-settings-form').on('submit', function(e) {
        e.preventDefault();
        
        var formData = {
            action: 'trendyol_save_settings',
            nonce: trendyolAjax.nonce,
            supplier_id: $('#supplier_id').val(),
            api_key: $('#api_key').val(),
            api_secret: $('#api_secret').val(),
            sync_interval: $('#sync_interval').val(),
            auto_sync_enabled: $('#auto_sync_enabled').is(':checked') ? 1 : 0,
            order_notification: $('#order_notification').is(':checked') ? 1 : 0
        };
        
        var $btn = $(this).find('button[type="submit"]');
        var originalText = $btn.text();
        $btn.prop('disabled', true).html('💾 Kaydediliyor...');
        
        $.ajax({
            url: trendyolAjax.ajax_url,
            type: 'POST',
            data: formData,
            timeout: 15000,
            success: function(response) {
                if (response.success) {
                    showNotification('✓ ' + response.data, 'success');
                } else {
                    showNotification('✗ ' + response.data, 'error');
                }
            },
            error: function(xhr, status, error) {
                console.log('AJAX Error:', xhr.responseText);
                var errorMsg = 'Bir hata oluştu';
                if (status === 'timeout') {
                    errorMsg = 'Zaman aşımı';
                } else if (xhr.responseText) {
                    errorMsg = 'Sunucu hatası - Konsolu kontrol edin';
                }
                showNotification('✗ ' + errorMsg, 'error');
            },
            complete: function() {
                $btn.prop('disabled', false).text(originalText);
            }
        });
    });

    // Şimdi senkronize et
    $('#sync-now-btn').on('click', function() {
        var $btn = $(this);
        var originalText = $btn.text();
        var $result = $('#sync-result');
        
        $btn.prop('disabled', true).html('⏳ Senkronize ediliyor...');
        $result.removeClass('success error').addClass('loading').html('Lütfen bekleyin, ürünler çekiliyor...').show();
        
        $.ajax({
            url: trendyolAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'trendyol_sync_now',
                nonce: trendyolAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    var data = response.data;
                    var html = '<strong>✓ Senkronizasyon tamamlandı!</strong><br>';
                    html += 'İşlenen: ' + data.processed + ' ürün<br>';
                    html += 'Başarılı: ' + data.success_count + ' ürün<br>';
                    html += 'Başarısız: ' + data.failed_count + ' ürün<br>';
                    html += 'Süre: ' + data.execution_time + ' saniye';
                    
                    if (data.errors && data.errors.length > 0) {
                        html += '<br><br><details><summary>Hata detaylarını göster</summary>';
                        html += '<ul style="margin: 10px 0; padding-left: 20px;">';
                        data.errors.slice(0, 5).forEach(function(error) {
                            html += '<li>' + error + '</li>';
                        });
                        html += '</ul></details>';
                    }
                    
                    $result.removeClass('loading error').addClass('success').html(html);
                    
                    // Sayfayı 2 saniye sonra yenile
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    $result.removeClass('loading success').addClass('error').html('✗ ' + response.data.message);
                }
            },
            error: function() {
                $result.removeClass('loading success').addClass('error').html('✗ AJAX hatası oluştu');
            },
            complete: function() {
                $btn.prop('disabled', false).text(originalText);
            }
        });
    });

    // Trendyol kategorilerini çek
    $('#fetch-trendyol-categories').on('click', function() {
        var $btn = $(this);
        var originalText = $btn.text();
        var $result = $('#category-fetch-result');
        
        $btn.prop('disabled', true).html('⏳ Çekiliyor...');
        $result.removeClass('success error').addClass('loading').html('Trendyol kategorileri alınıyor...').show();
        
        $.ajax({
            url: trendyolAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'trendyol_get_categories',
                nonce: trendyolAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    $result.removeClass('loading error').addClass('success').html('✓ ' + response.data.length + ' kategori başarıyla alındı! Sayfa yenileniyor...');
                    
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                } else {
                    $result.removeClass('loading success').addClass('error').html('✗ ' + response.data);
                }
            },
            error: function() {
                $result.removeClass('loading success').addClass('error').html('✗ Bağlantı hatası');
            },
            complete: function() {
                $btn.prop('disabled', false).text(originalText);
            }
        });
    });

    // Kategori eşleştir
    $('.map-category-btn').on('click', function() {
        var $btn = $(this);
        var trendyolId = $btn.data('trendyol-id');
        var $select = $('.woo-category-select[data-trendyol-id="' + trendyolId + '"]');
        var wooCatId = $select.val();
        
        if (!wooCatId) {
            showNotification('⚠ Lütfen bir WooCommerce kategorisi seçin', 'error');
            return;
        }
        
        var originalText = $btn.text();
        $btn.prop('disabled', true).text('⏳');
        
        $.ajax({
            url: trendyolAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'trendyol_map_category',
                nonce: trendyolAjax.nonce,
                trendyol_cat_id: trendyolId,
                woo_cat_id: wooCatId
            },
            success: function(response) {
                if (response.success) {
                    showNotification('✓ ' + response.data, 'success');
                    
                    // Durum badge'ini güncelle
                    var $statusBadge = $btn.closest('tr').find('.status-badge');
                    $statusBadge.removeClass('status-pending').addClass('status-mapped').html('✓ Eşleştirilmiş');
                } else {
                    showNotification('✗ ' + response.data, 'error');
                }
            },
            error: function() {
                showNotification('✗ Bir hata oluştu', 'error');
            },
            complete: function() {
                $btn.prop('disabled', false).text(originalText);
            }
        });
    });

    // Bildirim göster
    function showNotification(message, type) {
        var $notification = $('<div class="trendyol-notification trendyol-notification-' + type + '">' + message + '</div>');
        
        $('body').append($notification);
        
        setTimeout(function() {
            $notification.addClass('show');
        }, 10);
        
        setTimeout(function() {
            $notification.removeClass('show');
            setTimeout(function() {
                $notification.remove();
            }, 300);
        }, 3000);
    }

    // Enter tuşu ile form gönderme
    $('.woo-category-select').on('keypress', function(e) {
        if (e.which === 13) {
            e.preventDefault();
            $(this).closest('tr').find('.map-category-btn').trigger('click');
        }
    });
    
    // CSV Import
    $('#csv-upload-form').on('submit', function(e) {
    $('#csv-upload-form').on('submit', function(e) {
        e.preventDefault();
        
        var fileInput = $('#csv_file')[0];
        if (!fileInput.files.length) {
            showNotification('⚠ Lütfen bir dosya seçin', 'error');
            return;
        }
        
        var formData = new FormData();
        formData.append('action', 'trendyol_import_csv');
        formData.append('nonce', trendyolAjax.nonce);
        formData.append('csv_file', fileInput.files[0]);
        formData.append('import_images', $('#import_images').is(':checked') ? '1' : '0');
        formData.append('update_existing', $('#update_existing').is(':checked') ? '1' : '0');
        
        var $btn = $(this).find('button[type="submit"]');
        var originalText = $btn.html();
        
        $btn.prop('disabled', true).html('⏳ Yükleniyor...');
        $('#import-progress').show();
        $('#import-result').hide();
        $('#progress-fill').css('width', '10%');
        $('#progress-text').text('Dosya yükleniyor...');
        
        $.ajax({
            url: trendyolAjax.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            xhr: function() {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener('progress', function(evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = (evt.loaded / evt.total) * 50;
                        $('#progress-fill').css('width', percentComplete + '%');
                    }
                }, false);
                return xhr;
            },
            success: function(response) {
                if (response.success) {
                    $('#progress-fill').css('width', '100%');
                    $('#progress-text').text('✓ Tamamlandı!');
                    
                    var html = '<strong>✓ İçe aktarma başarılı!</strong><br>';
                    html += 'Toplam: ' + response.data.total + ' ürün<br>';
                    html += 'Başarılı: ' + response.data.success + ' ürün<br>';
                    html += 'Başarısız: ' + response.data.failed + ' ürün<br>';
                    
                    if (response.data.errors && response.data.errors.length > 0) {
                        html += '<br><details><summary>Hata detaylarını göster</summary><ul>';
                        response.data.errors.slice(0, 10).forEach(function(error) {
                            html += '<li>' + error + '</li>';
                        });
                        html += '</ul></details>';
                    }
                    
                    $('#import-result').removeClass('error loading').addClass('success').html(html).show();
                    
                    setTimeout(function() {
                        $('#import-progress').fadeOut();
                    }, 3000);
                } else {
                    $('#import-progress').hide();
                    $('#import-result').removeClass('success loading').addClass('error')
                        .html('✗ ' + response.data).show();
                }
            },
            error: function() {
                $('#import-progress').hide();
                $('#import-result').removeClass('success loading').addClass('error')
                    .html('✗ Sunucu hatası oluştu').show();
            },
            complete: function() {
                $btn.prop('disabled', false).html(originalText);
            }
        });
    });
    
    // Sipariş Senkronizasyonu
    $('#sync-orders-btn').on('click', function() {
        var $btn = $(this);
        var originalText = $btn.text();
        var $result = $('#orders-sync-result');
        
        $btn.prop('disabled', true).html('⏳ Siparişler çekiliyor...');
        $result.removeClass('success error').addClass('loading').html('Trendyol API\'sine bağlanılıyor...').show();
        
        $.ajax({
            url: trendyolAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'trendyol_sync_orders',
                nonce: trendyolAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    var html = '<strong>✓ Sipariş senkronizasyonu tamamlandı!</strong><br>';
                    html += 'İşlenen: ' + response.data.processed + ' sipariş<br>';
                    html += 'Başarılı: ' + response.data.success_count + '<br>';
                    html += 'Başarısız: ' + response.data.failed_count;
                    
                    $result.removeClass('loading error').addClass('success').html(html);
                    
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    $result.removeClass('loading success').addClass('error').html('✗ ' + response.data);
                }
            },
            error: function() {
                $result.removeClass('loading success').addClass('error').html('✗ Sunucu hatası');
            },
            complete: function() {
                $btn.prop('disabled', false).text(originalText);
            }
        });
    });

    // Kategori değiştiğinde otomatik kaydet checkbox'ı (opsiyonel)
    var autoSaveTimeout;
    $('.woo-category-select').on('change', function() {
        var $select = $(this);
        var $btn = $select.closest('tr').find('.map-category-btn');
        
        clearTimeout(autoSaveTimeout);
        
        // 1 saniye bekle, sonra otomatik kaydet (kullanıcı isterse)
        // autoSaveTimeout = setTimeout(function() {
        //     $btn.trigger('click');
        // }, 1000);
        
        // Veya butonu vurgula
        $btn.addClass('button-primary').text('Kaydet ✓');
    });
});