<?php
// logout.php - Çıkış İşlemi
session_start();
session_destroy();
header('Location: login.php');
exit;
?>
