<?php
require_once 'includes/config.php';
requireLogin();
$report_id = $_GET['id'] ?? 0;

$stmt = $pdo->prepare("
    SELECT r.*, u.name, u.surname, u.email
    FROM reports r
    JOIN users u ON r.user_id = u.id
    WHERE r.id = ?
");
$stmt->execute([$report_id]);
$report = $stmt->fetch();

if (!$report) {
    redirect('raporlar.php');
}

// Sadece kendi raporunu veya admin görebilir
if (!isAdmin() && $report['user_id'] != $_SESSION['user_id']) {
    redirect('raporlar.php');
}

// Dosyaları çek
$stmt = $pdo->prepare("SELECT * FROM files WHERE report_id = ?");
$stmt->execute([$report_id]);
$files = $stmt->fetchAll();

$pageTitle = 'Rapor Detayı';
include 'includes/header.php';
?>

<div class="topbar">
    <div class="page-title">
        <h1>Rapor Detayı</h1>
        <p><?php echo getTurkishDate($report['date']); ?></p>
    </div>
    <a href="raporlar.php" class="btn btn-secondary">← Geri Dön</a>
</div>

<div class="table-container">
    <div style="margin-bottom: 32px;">
        <h2 style="font-size: 24px; margin-bottom: 8px;"><?php echo htmlspecialchars($report['title']); ?></h2>
        <div style="color: var(--text-secondary); font-size: 14px;">
            <strong>Kullanıcı:</strong> <?php echo htmlspecialchars($report['name'] . ' ' . $report['surname']); ?> 
            (<?php echo htmlspecialchars($report['email']); ?>)
            <br>
            <strong>Tarih:</strong> <?php echo date('d.m.Y', strtotime($report['date'])); ?>
            <br>
            <strong>Oluşturulma:</strong> <?php echo date('d.m.Y H:i', strtotime($report['created_at'])); ?>
        </div>
    </div>
    
    <div style="margin-bottom: 32px;">
        <h3 style="font-size: 18px; margin-bottom: 16px; color: var(--gold);">Rapor Açıklaması</h3>
        <div style="color: var(--text-primary); line-height: 1.8; white-space: pre-wrap;">
            <?php echo htmlspecialchars($report['description']); ?>
        </div>
    </div>
    
    <?php if (!empty($files)): ?>
    <div>
        <h3 style="font-size: 18px; margin-bottom: 16px; color: var(--gold);">Ek Dosyalar (<?php echo count($files); ?>)</h3>
        <div style="display: grid; gap: 12px;">
            <?php foreach ($files as $file): ?>
            <div style="padding: 16px; background: var(--bg-tertiary); border-radius: 10px; display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <div style="font-weight: 600; margin-bottom: 4px;">
                        <?php echo htmlspecialchars($file['file_name']); ?>
                    </div>
                    <div style="color: var(--text-muted); font-size: 13px;">
                        <?php echo strtoupper(pathinfo($file['file_name'], PATHINFO_EXTENSION)); ?> • 
                        <?php echo formatBytes($file['file_size']); ?>
                    </div>
                </div>
                <a href="<?php echo $file['file_path']; ?>" download class="btn btn-primary" style="padding: 8px 16px;">
                    İndir
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
