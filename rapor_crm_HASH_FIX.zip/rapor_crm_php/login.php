<?php
// login.php - Giriş Sayfası
require_once 'includes/config.php';

// Zaten giriş yapmışsa dashboard'a yönlendir
if (isLoggedIn()) {
    redirect('index.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        $error = 'Lütfen tüm alanları doldurun.';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['name'] = $user['name'];
                $_SESSION['surname'] = $user['surname'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                
                redirect('index.php');
            } else {
                $error = 'E-posta veya şifre hatalı.';
            }
        } catch (Exception $e) {
            $error = 'Bir hata oluştu. Lütfen tekrar deneyin.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--bg-primary);
        }
        .login-card {
            background: var(--bg-secondary);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 48px;
            width: 100%;
            max-width: 450px;
        }
        .login-header {
            text-align: center;
            margin-bottom: 40px;
        }
        .login-logo {
            width: 64px;
            height: 64px;
            background: var(--gold);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            font-size: 32px;
            font-weight: 900;
            color: var(--bg-primary);
        }
        .login-header h1 {
            font-size: 28px;
            margin-bottom: 8px;
        }
        .login-header p {
            color: var(--text-secondary);
            font-size: 14px;
        }
        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #ef4444;
            padding: 14px;
            border-radius: 10px;
            margin-bottom: 24px;
            font-size: 14px;
        }
        .demo-info {
            margin-top: 24px;
            padding: 16px;
            background: rgba(245, 195, 68, 0.1);
            border: 1px solid rgba(245, 195, 68, 0.2);
            border-radius: 10px;
            font-size: 13px;
            color: var(--text-secondary);
            text-align: center;
        }
        .demo-info strong {
            color: var(--gold);
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="login-logo">R</div>
                <h1><?php echo SITE_NAME; ?></h1>
                <p>Günlük Rapor Yönetim Sistemi</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert-error">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label>E-posta</label>
                    <input type="email" name="email" class="form-control" 
                           placeholder="ornek@email.com" required autofocus>
                </div>
                
                <div class="form-group">
                    <label>Şifre</label>
                    <input type="password" name="password" class="form-control" 
                           placeholder="••••••••" required>
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%;">
                    Giriş Yap
                </button>
            </form>
            
            <div class="demo-info">
                <strong>Demo Hesap:</strong><br>
                E-posta: admin@rapor.com<br>
                Şifre: admin123
            </div>
        </div>
    </div>
</body>
</html>
