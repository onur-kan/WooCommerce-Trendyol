<?php
// hash-olustur.php - Şifre Hash Oluşturucu

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    if (!empty($password)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        echo "<h2>Şifre Hash Oluşturuldu:</h2>";
        echo "<p><strong>Şifre:</strong> " . htmlspecialchars($password) . "</p>";
        echo "<p><strong>Hash:</strong></p>";
        echo "<textarea style='width:100%;height:100px;'>" . $hash . "</textarea>";
        echo "<hr>";
        echo "<h3>SQL Sorgusu:</h3>";
        echo "<textarea style='width:100%;height:150px;'>";
        echo "DELETE FROM users WHERE email = 'admin@rapor.com';\n\n";
        echo "INSERT INTO users (name, surname, email, password, role) VALUES\n";
        echo "('Admin', 'User', 'admin@rapor.com', '$hash', 'admin');";
        echo "</textarea>";
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Şifre Hash Oluştur</title>
    <style>
        body { font-family: Arial; padding: 40px; background: #f5f5f5; }
        .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
        input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
        button { width: 100%; padding: 12px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; }
        button:hover { background: #0056b3; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Şifre Hash Oluşturucu</h2>
        <form method="POST">
            <label>Yeni Şifre:</label>
            <input type="text" name="password" placeholder="Örn: admin123" required>
            <button type="submit">Hash Oluştur</button>
        </form>
    </div>
</body>
</html>
