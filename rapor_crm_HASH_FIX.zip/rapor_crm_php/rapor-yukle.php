<?php
// rapor-yukle.php - Rapor Yükleme Sayfası
require_once 'includes/config.php';
requireLogin();

$pageTitle = 'Rapor Yükle';
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    $date = $_POST['date'] ?? '';
    $title = sanitize($_POST['title'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    
    if (empty($date) || empty($title) || empty($description)) {
        $error = 'Lütfen tüm alanları doldurun.';
    } else {
        try {
            // Raporu kaydet
            $stmt = $pdo->prepare("
                INSERT INTO reports (user_id, date, title, description)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$_SESSION['user_id'], $date, $title, $description]);
            $report_id = $pdo->lastInsertId();
            
            // Dosyaları yükle
            if (!empty($_FILES['files']['name'][0])) {
                $upload_dir = UPLOAD_DIR;
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
                foreach ($_FILES['files']['tmp_name'] as $key => $tmp_name) {
                    if ($_FILES['files']['error'][$key] == 0) {
                        $file_name = basename($_FILES['files']['name'][$key]);
                        $file_type = $_FILES['files']['type'][$key];
                        $file_size = $_FILES['files']['size'][$key];
                        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                        
                        // Dosya türü kontrolü
                        if (!in_array($file_ext, ALLOWED_FILE_TYPES)) {
                            continue;
                        }
                        
                        // Dosya boyutu kontrolü
                        if ($file_size > MAX_FILE_SIZE) {
                            continue;
                        }
                        
                        $new_file_name = uniqid() . '_' . $file_name;
                        $file_path = $upload_dir . $new_file_name;
                        
                        if (move_uploaded_file($tmp_name, $file_path)) {
                            $stmt = $pdo->prepare("
                                INSERT INTO files (report_id, file_name, file_type, file_size, file_path)
                                VALUES (?, ?, ?, ?, ?)
                            ");
                            $stmt->execute([$report_id, $file_name, $file_type, $file_size, $file_path]);
                        }
                    }
                }
            }
            
            $success = 'Rapor başarıyla yüklendi!';
            $_POST = []; // Form temizle
        } catch (Exception $e) {
            $error = 'Bir hata oluştu: ' . $e->getMessage();
        }
    }
}

include 'includes/header.php';
?>

<!-- Topbar -->
<div class="topbar">
    <div class="page-title">
        <h1>Yeni Rapor Yükle</h1>
        <p>Günlük çalışma raporunuzu yükleyin</p>
    </div>
    
    <div class="user-profile">
        <div class="user-avatar">
            <?php echo strtoupper(substr($_SESSION['name'], 0, 1)); ?>
        </div>
        <div class="user-info">
            <h4><?php echo $_SESSION['name'] . ' ' . $_SESSION['surname']; ?></h4>
            <p><?php echo isAdmin() ? 'Sistem Yöneticisi' : 'Kullanıcı'; ?></p>
        </div>
    </div>
</div>

<!-- Form -->
<div class="table-container" style="max-width: 800px;">
    <?php if ($success): ?>
        <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); color: #10b981; padding: 16px; border-radius: 10px; margin-bottom: 24px;">
            <?php echo $success; ?>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); color: #ef4444; padding: 16px; border-radius: 10px; margin-bottom: 24px;">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>
    
    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label>Rapor Tarihi *</label>
            <input type="date" name="date" class="form-control" 
                   value="<?php echo date('Y-m-d'); ?>" required>
        </div>
        
        <div class="form-group">
            <label>Rapor Başlığı *</label>
            <input type="text" name="title" class="form-control" 
                   placeholder="Örn: 12 Aralık 2024 Günlük Raporu" 
                   value="<?php echo $_POST['title'] ?? ''; ?>" required>
        </div>
        
        <div class="form-group">
            <label>Rapor Açıklaması *</label>
            <textarea name="description" class="form-control" 
                      placeholder="Bugün yaptığınız işleri detaylı olarak açıklayın..." 
                      required><?php echo $_POST['description'] ?? ''; ?></textarea>
        </div>
        
        <div class="form-group">
            <label>Ek Dosyalar (PDF, Word, Excel, Resim)</label>
            <div class="file-upload-zone" onclick="document.getElementById('fileInput').click()">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
                <p style="color: var(--text-secondary); margin-bottom: 8px;">Dosyaları sürükleyin veya tıklayın</p>
                <p style="color: var(--text-muted); font-size: 13px;">PDF, Word, Excel, JPG, PNG (Maks. 10MB)</p>
                <input type="file" name="files[]" multiple id="fileInput" 
                       accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.gif" 
                       style="display: none;" onchange="updateFileList(this)">
            </div>
            <div id="fileList" style="margin-top: 12px;"></div>
        </div>
        
        <div style="display: flex; gap: 12px;">
            <button type="submit" name="submit" class="btn btn-primary">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Raporu Yükle
            </button>
            <a href="raporlar.php" class="btn btn-secondary">İptal</a>
        </div>
    </form>
</div>

<script>
function updateFileList(input) {
    const fileList = document.getElementById('fileList');
    fileList.innerHTML = '';
    
    if (input.files.length > 0) {
        for (let i = 0; i < input.files.length; i++) {
            const file = input.files[i];
            const fileItem = document.createElement('div');
            fileItem.style.cssText = 'padding: 12px; background: var(--bg-tertiary); border-radius: 8px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center;';
            fileItem.innerHTML = `
                <div>
                    <div style="font-weight: 600; font-size: 14px;">${file.name}</div>
                    <div style="color: var(--text-muted); font-size: 12px;">${(file.size / 1024).toFixed(2)} KB</div>
                </div>
                <span class="badge badge-success">Seçildi</span>
            `;
            fileList.appendChild(fileItem);
        }
    }
}
</script>

<?php include 'includes/footer.php'; ?>
