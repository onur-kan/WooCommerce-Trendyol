# 📦 RAPOR CRM - Kurulum Kılavuzu

## ⚡ Hızlı Kurulum (5 Dakika)

### ADIM 1: Dosyaları Yükleyin
```
1. ZIP'i indirin ve çıkarın
2. cPanel File Manager ile tüm dosyaları /public_html/rapor-crm/ klasörüne yükleyin
```

### ADIM 2: Veritabanı Oluşturun
```
1. cPanel > MySQL Databases
2. Yeni veritabanı oluşturun: rapor_crm
3. Yeni kullanıcı oluşturun ve veritabanına ekleyin
4. cPanel > phpMyAdmin
5. database.sql dosyasını içe aktarın
```

### ADIM 3: Config Düzenleyin
```
includes/config.php dosyasını açın:

define('DB_HOST', 'localhost');
define('DB_NAME', 'sizin_veritabani_adi');
define('DB_USER', 'sizin_kullanici_adi');
define('DB_PASS', 'sizin_sifreniz');
```

### ADIM 4: İzinler
```
cPanel File Manager'da:
uploads/ klasörü → 755
```

### ADIM 5: Test
```
https://yourdomain.com/rapor-crm/

Giriş:
E-posta: admin@rapor.com
Şifre: admin123
```

## ✅ Tamamlandı!

Sistem hazır kullanıma hazır!
