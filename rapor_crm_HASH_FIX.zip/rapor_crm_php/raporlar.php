<?php
require_once 'includes/config.php';
requireLogin();
$pageTitle = 'Raporlar';

// Filtreler
$search = $_GET['search'] ?? '';
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$user_filter = $_GET['user_id'] ?? '';

$sql = "SELECT r.*, u.name, u.surname, 
        (SELECT COUNT(*) FROM files WHERE report_id = r.id) as file_count
        FROM reports r
        JOIN users u ON r.user_id = u.id
        WHERE 1=1";

$params = [];

if (!isAdmin()) {
    $sql .= " AND r.user_id = ?";
    $params[] = $_SESSION['user_id'];
}

if ($search) {
    $sql .= " AND (r.title LIKE ? OR r.description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($start_date) {
    $sql .= " AND r.date >= ?";
    $params[] = $start_date;
}

if ($end_date) {
    $sql .= " AND r.date <= ?";
    $params[] = $end_date;
}

if ($user_filter && isAdmin()) {
    $sql .= " AND r.user_id = ?";
    $params[] = $user_filter;
}

$sql .= " ORDER BY r.date DESC, r.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$reports = $stmt->fetchAll();

// Kullanıcı listesi (admin için)
$users = [];
if (isAdmin()) {
    $users = $pdo->query("SELECT id, name, surname FROM users WHERE role = 'user' ORDER BY name")->fetchAll();
}

include 'includes/header.php';
?>

<div class="topbar">
    <div class="page-title">
        <h1>Raporlar</h1>
        <p><?php echo count($reports); ?> rapor bulundu</p>
    </div>
    <div class="user-profile">
        <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['name'], 0, 1)); ?></div>
        <div class="user-info">
            <h4><?php echo $_SESSION['name'] . ' ' . $_SESSION['surname']; ?></h4>
            <p><?php echo isAdmin() ? 'Sistem Yöneticisi' : 'Kullanıcı'; ?></p>
        </div>
    </div>
</div>

<!-- Filtreler -->
<div class="table-container" style="margin-bottom: 24px;">
    <form method="GET" style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr auto; gap: 12px; align-items: end;">
        <div class="form-group" style="margin: 0;">
            <label>Ara</label>
            <input type="text" name="search" class="form-control" placeholder="Başlık veya açıklama..." value="<?php echo htmlspecialchars($search); ?>">
        </div>
        <div class="form-group" style="margin: 0;">
            <label>Başlangıç</label>
            <input type="date" name="start_date" class="form-control" value="<?php echo $start_date; ?>">
        </div>
        <div class="form-group" style="margin: 0;">
            <label>Bitiş</label>
            <input type="date" name="end_date" class="form-control" value="<?php echo $end_date; ?>">
        </div>
        <?php if (isAdmin()): ?>
        <div class="form-group" style="margin: 0;">
            <label>Kullanıcı</label>
            <select name="user_id" class="form-control">
                <option value="">Tüm Kullanıcılar</option>
                <?php foreach ($users as $u): ?>
                <option value="<?php echo $u['id']; ?>" <?php echo $user_filter == $u['id'] ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($u['name'] . ' ' . $u['surname']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary">Filtrele</button>
    </form>
</div>

<!-- Rapor Listesi -->
<div class="table-container">
    <?php if (empty($reports)): ?>
        <p style="text-align: center; color: var(--text-secondary); padding: 40px;">Rapor bulunamadı.</p>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <?php if (isAdmin()): ?><th>Kullanıcı</th><?php endif; ?>
                <th>Tarih</th>
                <th>Başlık</th>
                <th>Dosya</th>
                <th>Oluşturulma</th>
                <th>İşlemler</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($reports as $r): ?>
            <tr>
                <?php if (isAdmin()): ?>
                <td><?php echo htmlspecialchars($r['name'] . ' ' . $r['surname']); ?></td>
                <?php endif; ?>
                <td><?php echo date('d.m.Y', strtotime($r['date'])); ?></td>
                <td><?php echo htmlspecialchars($r['title']); ?></td>
                <td><?php echo $r['file_count']; ?> dosya</td>
                <td><?php echo date('d.m.Y H:i', strtotime($r['created_at'])); ?></td>
                <td><a href="rapor-detay.php?id=<?php echo $r['id']; ?>" class="btn btn-primary" style="padding: 8px 16px;">Görüntüle</a></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
