<?php
// index.php - Dashboard
require_once 'includes/config.php';
requireLogin();

$pageTitle = 'Genel Bakış';

// İstatistikleri çek
$stats = [];

try {
    // Toplam kullanıcı
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE role = 'user'");
    $stats['total_users'] = $stmt->fetch()['total'];
    
    // Toplam rapor
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM reports");
    $stats['total_reports'] = $stmt->fetch()['total'];
    
    // Bugün yüklenen rapor
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM reports WHERE DATE(created_at) = CURDATE()");
    $stats['today_reports'] = $stmt->fetch()['total'];
    
    // Bugün rapor yükleyen kullanıcılar
    $stmt = $pdo->query("
        SELECT DISTINCT u.id, u.name, u.surname, r.created_at
        FROM reports r
        JOIN users u ON r.user_id = u.id
        WHERE DATE(r.created_at) = CURDATE()
        ORDER BY r.created_at DESC
    ");
    $today_uploaders = $stmt->fetchAll();
    
    // Bugün rapor yüklemeyen kullanıcılar
    $stmt = $pdo->query("
        SELECT u.id, u.name, u.surname, u.email
        FROM users u
        WHERE u.role = 'user'
        AND u.id NOT IN (
            SELECT DISTINCT user_id 
            FROM reports 
            WHERE DATE(created_at) = CURDATE()
        )
    ");
    $no_report_today = $stmt->fetchAll();
    $stats['no_report_today'] = count($no_report_today);
    
    // Son 5 rapor
    $stmt = $pdo->query("
        SELECT r.*, u.name, u.surname
        FROM reports r
        JOIN users u ON r.user_id = u.id
        ORDER BY r.created_at DESC
        LIMIT 5
    ");
    $recent_reports = $stmt->fetchAll();
    
} catch (Exception $e) {
    $stats = ['total_users' => 0, 'total_reports' => 0, 'today_reports' => 0, 'no_report_today' => 0];
    $today_uploaders = [];
    $no_report_today = [];
    $recent_reports = [];
}

include 'includes/header.php';
?>

<!-- Topbar -->
<div class="topbar">
    <div class="page-title">
        <h1>Genel Bakış</h1>
        <p><?php echo getTurkishDate(date('Y-m-d')); ?></p>
    </div>
    
    <div class="user-profile">
        <div class="user-avatar">
            <?php echo strtoupper(substr($_SESSION['name'], 0, 1)); ?>
        </div>
        <div class="user-info">
            <h4><?php echo $_SESSION['name'] . ' ' . $_SESSION['surname']; ?></h4>
            <p><?php echo isAdmin() ? 'Sistem Yöneticisi' : 'Kullanıcı'; ?></p>
        </div>
    </div>
</div>

<!-- Stats Cards -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-label">Toplam Kullanıcı</span>
            <div class="stat-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
            </div>
        </div>
        <div class="stat-value"><?php echo number_format($stats['total_users']); ?></div>
        <div class="stat-change">Aktif kullanıcı sayısı</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-label">Toplam Rapor</span>
            <div class="stat-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
            </div>
        </div>
        <div class="stat-value"><?php echo number_format($stats['total_reports']); ?></div>
        <div class="stat-change">Sistemdeki toplam rapor</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-label">Bugün Yüklenen</span>
            <div class="stat-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
            </div>
        </div>
        <div class="stat-value"><?php echo number_format($stats['today_reports']); ?></div>
        <div class="stat-change">Bugün yüklenen rapor sayısı</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-header">
            <span class="stat-label">Rapor Yüklemeyenler</span>
            <div class="stat-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
        </div>
        <div class="stat-value"><?php echo number_format($stats['no_report_today']); ?></div>
        <div class="stat-change">Bugün henüz rapor yüklemedi</div>
    </div>
</div>

<!-- Content Grid -->
<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
    <!-- Son Raporlar -->
    <div class="table-container">
        <h3 style="margin-bottom: 24px; font-size: 18px;">Son Yüklenen Raporlar</h3>
        <?php if (empty($recent_reports)): ?>
            <p style="color: var(--text-secondary); text-align: center; padding: 40px;">Henüz rapor yüklenmemiş.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Kullanıcı</th>
                        <th>Başlık</th>
                        <th>Tarih</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_reports as $report): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($report['name'] . ' ' . $report['surname']); ?></td>
                        <td><?php echo htmlspecialchars($report['title']); ?></td>
                        <td><?php echo date('d.m.Y H:i', strtotime($report['created_at'])); ?></td>
                        <td>
                            <a href="rapor-detay.php?id=<?php echo $report['id']; ?>" class="btn btn-secondary" style="padding: 8px 16px;">
                                Görüntüle
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    
    <!-- Yan Panel -->
    <div>
        <!-- Bugün Rapor Yükleyenler -->
        <div class="table-container" style="margin-bottom: 24px;">
            <h3 style="margin-bottom: 16px; font-size: 16px;">Bugün Rapor Yükleyenler</h3>
            <?php if (empty($today_uploaders)): ?>
                <p style="color: var(--text-secondary); font-size: 14px;">Henüz kimse rapor yüklemedi.</p>
            <?php else: ?>
                <?php foreach ($today_uploaders as $uploader): ?>
                <div style="padding: 12px 0; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <div style="font-weight: 600; font-size: 14px;">
                            <?php echo htmlspecialchars($uploader['name'] . ' ' . $uploader['surname']); ?>
                        </div>
                        <div style="color: var(--text-muted); font-size: 12px;">
                            <?php echo date('H:i', strtotime($uploader['created_at'])); ?>
                        </div>
                    </div>
                    <span class="badge badge-success">✓</span>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <!-- Rapor Yüklemeyenler -->
        <?php if (isAdmin() && !empty($no_report_today)): ?>
        <div class="table-container">
            <h3 style="margin-bottom: 16px; font-size: 16px;">Bugün Rapor Yüklemeyenler</h3>
            <?php foreach ($no_report_today as $user): ?>
            <div style="padding: 12px 0; border-bottom: 1px solid var(--border);">
                <div style="font-weight: 600; font-size: 14px;">
                    <?php echo htmlspecialchars($user['name'] . ' ' . $user['surname']); ?>
                </div>
                <div style="color: var(--text-muted); font-size: 12px;">
                    <?php echo htmlspecialchars($user['email']); ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
