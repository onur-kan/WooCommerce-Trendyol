<?php
/**
 * Trendyol Ürün Aktarma Sayfası - İyileştirilmiş Versiyon
 */

if (!defined('ABSPATH')) {
    exit;
}

global $trendyol_adapter;

$last_sync = get_option('wc_trendyol_last_sync', 'Henüz senkronizasyon yapılmadı');
$total_products = get_option('wc_trendyol_total_products', 0);
$synced_products = get_option('wc_trendyol_synced_products', 0);

?>
<div class="wrap">
    <h1><?php _e('Trendyol Ürün Aktarma', 'wc-trendyol'); ?></h1>

    <div class="card" style="max-width: 100%; margin-top: 20px;">
        <h2>📊 Senkronizasyon Durumu</h2>
        <table class="widefat" style="margin-top: 15px;">
            <tbody>
                <tr>
                    <td style="width: 30%;"><strong>Son Senkronizasyon:</strong></td>
                    <td id="last-sync-date"><?php echo esc_html($last_sync); ?></td>
                </tr>
                <tr>
                    <td><strong>Toplam Trendyol Ürünü:</strong></td>
                    <td id="total-products"><?php echo esc_html($total_products); ?></td>
                </tr>
                <tr>
                    <td><strong>Senkronize Edilen Ürün:</strong></td>
                    <td id="synced-products"><?php echo esc_html($synced_products); ?></td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="card" style="max-width: 100%; margin-top: 20px;">
        <h2>🚀 Ürün Aktarma</h2>
        <p style="font-size: 14px; line-height: 1.8;">
            Trendyol mağazanızdaki tüm ürünleri WooCommerce'e aktarmak için aşağıdaki butona tıklayın.
            Bu işlem ürün sayınıza göre birkaç dakika sürebilir.
        </p>

        <div style="margin: 20px 0;">
            <button type="button" id="test-connection-btn" class="button" style="margin-right: 10px;">
                🔌 Bağlantıyı Test Et
            </button>
            <button type="button" id="start-import-btn" class="button button-primary button-hero">
                ⬇️ Tüm Ürünleri Aktar
            </button>
        </div>

        <div id="connection-result" style="display: none; margin: 15px 0; padding: 15px; border-radius: 5px;"></div>

        <div id="import-progress" style="display: none; margin-top: 20px;">
            <h3>📦 Ürünler Aktarılıyor...</h3>
            <div style="background: #f0f0f1; padding: 5px; border-radius: 5px; margin: 15px 0;">
                <div id="progress-bar" style="background: linear-gradient(90deg, #f27a1a, #e74c3c); height: 30px; width: 0%; transition: width 0.3s; border-radius: 3px; color: white; text-align: center; line-height: 30px; font-weight: bold; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    0%
                </div>
            </div>
            <div id="import-status" style="font-size: 14px; color: #666;"></div>
            <div id="import-details" style="margin-top: 15px; padding: 10px; background: #f9f9f9; border-left: 4px solid #f27a1a; font-size: 13px; max-height: 200px; overflow-y: auto;"></div>
        </div>
    </div>

    <div class="card" style="max-width: 100%; margin-top: 20px; background: #f0f8ff; border-left: 4px solid #2196F3;">
        <h2>ℹ️ Önemli Bilgiler</h2>
        <ul style="line-height: 2; font-size: 14px;">
            <li><strong>Ürün Eşleştirme:</strong> Ürünler Trendyol barkodu (SKU) ile eşleştirilir.</li>
            <li><strong>Kategori Eşleştirme:</strong> Kategorileri önceden "Ürünler → Kategoriler" bölümünden eşleştirin.</li>
            <li><strong>Görseller:</strong> Ürün görselleri otomatik olarak indirilir ve medya kütüphanesine eklenir.</li>
            <li><strong>Fiyatlar:</strong> Hem liste fiyatı hem de satış fiyatı aktarılır.</li>
            <li><strong>Stok:</strong> Stok miktarları otomatik olarak senkronize edilir.</li>
            <li><strong>Güncelleme:</strong> Mevcut ürünler güncellenir, yeni ürünler oluşturulur.</li>
        </ul>
    </div>

    <div class="card" style="max-width: 100%; margin-top: 20px; background: #fff3cd; border-left: 4px solid #ffc107;">
        <h2>⚠️ Dikkat Edilmesi Gerekenler</h2>
        <ul style="line-height: 2; font-size: 14px;">
            <li>İşlem sırasında sayfayı <strong>kapatmayın</strong>.</li>
            <li>İlk aktarma işlemi ürün sayınıza göre <strong>5-30 dakika</strong> sürebilir.</li>
            <li>Kategori eşleştirmelerini önceden yapmanız önerilir.</li>
            <li>Sunucu zaman aşımı hatası alırsanız, işlemi tekrar başlatın (kaldığı yerden devam eder).</li>
        </ul>
    </div>
</div>

<style>
.card {
    background: #fff;
    border: 1px solid #ccd0d4;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    padding: 20px;
    margin-bottom: 20px;
}

.card h2 {
    margin-top: 0;
    padding-bottom: 10px;
    border-bottom: 2px solid #f27a1a;
    color: #23282d;
}

#connection-result.success {
    background: #d4edda;
    border: 1px solid #c3e6cb;
    color: #155724;
}

#connection-result.error {
    background: #f8d7da;
    border: 1px solid #f5c6cb;
    color: #721c24;
}

.button-hero {
    font-size: 16px !important;
    padding: 12px 30px !important;
    height: auto !important;
}

#import-details p {
    margin: 5px 0;
    padding: 5px 10px;
    background: white;
    border-radius: 3px;
}

#import-details p.error {
    background: #ffebee;
    color: #c62828;
}

#import-details p.success {
    background: #e8f5e9;
    color: #2e7d32;
}
</style>

<script>
jQuery(document).ready(function($) {
    
    console.log('Trendyol Import Page Loaded');
    
    // Test Connection
    $('#test-connection-btn').on('click', function(e) {
        e.preventDefault();
        
        var button = $(this);
        var originalText = button.html();
        var resultDiv = $('#connection-result');
        
        button.prop('disabled', true).html('⏳ Test ediliyor...');
        resultDiv.removeClass('success error').hide();
        
        $.ajax({
            url: trendyolAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'wc_trendyol_test_connection',
                nonce: trendyolAjax.nonce
            },
            success: function(response) {
                console.log('Test Response:', response);
                
                if (response.success) {
                    resultDiv.addClass('success').html('<strong>✓ Başarılı!</strong> ' + response.data).fadeIn();
                } else {
                    resultDiv.addClass('error').html('<strong>✗ Hata!</strong> ' + response.data).fadeIn();
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', xhr, status, error);
                resultDiv.addClass('error').html('<strong>✗ Hata!</strong> Sunucu hatası. Konsolu kontrol edin.').fadeIn();
            },
            complete: function() {
                button.prop('disabled', false).html(originalText);
            }
        });
    });
    
    // Start Import
    $('#start-import-btn').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('Trendyol\'daki tüm ürünleri WooCommerce\'e aktarmak istediğinizden emin misiniz?\n\nBu işlem uzun sürebilir ve ürün sayınıza göre 5-30 dakika alabilir.')) {
            return;
        }
        
        var button = $(this);
        var progressDiv = $('#import-progress');
        var progressBar = $('#progress-bar');
        var statusDiv = $('#import-status');
        var detailsDiv = $('#import-details');
        
        button.prop('disabled', true).html('⏳ Aktarılıyor...');
        progressDiv.fadeIn();
        progressBar.css('width', '0%').text('0%');
        statusDiv.html('Senkronizasyon başlatılıyor...');
        detailsDiv.html('');
        
        var currentPage = 0;
        var totalImported = 0;
        var totalErrors = 0;
        
        function importPage(page) {
            console.log('Importing page:', page);
            
            $.ajax({
                url: trendyolAjax.ajax_url,
                type: 'POST',
                data: {
                    action: 'wc_trendyol_sync_products',
                    nonce: trendyolAjax.nonce,
                    page: page
                },
                success: function(response) {
                    console.log('Import Response:', response);
                    
                    if (response.success) {
                        var data = response.data;
                        totalImported += data.imported;
                        
                        progressBar.css('width', data.progress + '%').text(Math.round(data.progress) + '%');
                        
                        statusDiv.html(
                            '📦 Sayfa <strong>' + (data.current_page + 1) + '</strong> / <strong>' + data.total_pages + '</strong> işleniyor...<br>' +
                            '✓ Toplam <strong>' + totalImported + '</strong> ürün başarıyla aktarıldı.<br>' +
                            '⏱️ Kalan sayfa: <strong>' + (data.total_pages - (data.current_page + 1)) + '</strong>'
                        );
                        
                        // Hataları göster
                        if (data.errors && data.errors.length > 0) {
                            data.errors.forEach(function(error) {
                                detailsDiv.prepend('<p class="error">⚠️ ' + error + '</p>');
                                totalErrors++;
                            });
                        }
                        
                        // Başarılı mesaj
                        detailsDiv.prepend('<p class="success">✓ Sayfa ' + (data.current_page + 1) + ': ' + data.imported + ' ürün aktarıldı</p>');
                        
                        // Sayfayı güncelle
                        $('#total-products').text(data.total_elements);
                        $('#synced-products').text(totalImported);
                        
                        if (data.has_more) {
                            // Sonraki sayfa
                            setTimeout(function() {
                                importPage(page + 1);
                            }, 1500);
                        } else {
                            // Tamamlandı
                            progressBar.css('width', '100%').text('100%');
                            statusDiv.html(
                                '<strong style="color: green; font-size: 16px;">🎉 Senkronizasyon tamamlandı!</strong><br>' +
                                '✓ Toplam <strong>' + totalImported + '</strong> ürün başarıyla aktarıldı.<br>' +
                                (totalErrors > 0 ? '⚠️ <strong>' + totalErrors + '</strong> hata oluştu.<br>' : '') +
                                '<em>Sayfa 3 saniye içinde yenilenecek...</em>'
                            );
                            
                            button.prop('disabled', false).html('⬇️ Tüm Ürünleri Aktar');
                            
                            setTimeout(function() {
                                location.reload();
                            }, 3000);
                        }
                    } else {
                        var errorMsg = response.data ? response.data : 'Bilinmeyen hata';
                        statusDiv.html('<strong style="color: red;">✗ Hata!</strong> ' + errorMsg);
                        detailsDiv.prepend('<p class="error">✗ ' + errorMsg + '</p>');
                        button.prop('disabled', false).html('⬇️ Tüm Ürünleri Aktar');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', xhr, status, error);
                    statusDiv.html('<strong style="color: red;">✗ Sunucu Hatası!</strong> ' + error);
                    detailsDiv.prepend('<p class="error">✗ Sunucu hatası: ' + error + '</p>');
                    button.prop('disabled', false).html('⬇️ Tüm Ürünleri Aktar');
                }
            });
        }
        
        // İlk sayfadan başla
        importPage(0);
    });
    
});
</script>