<div class="wrap">
    <div class="wc_trendyol_alert">
        BU ÖZELLİK SADECE PRO SÜRÜMÜNDE MEVCUTTUR. PRO SÜRÜMÜNÜ SATIN ALMAK İÇİN
        <a href="https://hayatikodla.net/urun/woocommerce-trendyol-entegrasyonu-pro/" target="_blank">"WOOCOMMERCE TRENDYOL PRO"</a>
        LİNKİNDEN SATIN ALABİLİRSİNİZ.
    </div>
</div>