<?php
/**
 * Trendyol Loglar Sayfası
 */

if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;
$table_name = $wpdb->prefix . 'trendyol_sync_logs';

// Log silme işlemi
if (isset($_POST['clear_logs']) && check_admin_referer('trendyol_clear_logs', 'trendyol_nonce')) {
    $wpdb->query("TRUNCATE TABLE {$table_name}");
    echo '<div class="notice notice-success"><p>' . __('Tüm loglar temizlendi.', 'wc-trendyol') . '</p></div>';
}

// Logları çek
$logs = $wpdb->get_results("SELECT * FROM {$table_name} ORDER BY created_at DESC LIMIT 500");

?>
<div class="wrap">
    <h1><?php _e('Trendyol Senkronizasyon Logları', 'wc-trendyol'); ?></h1>

    <div class="card" style="max-width: 100%; margin-top: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
            <h2 style="margin: 0;">📝 Son 500 Log Kaydı</h2>
            <form method="post" action="" style="margin: 0;">
                <?php wp_nonce_field('trendyol_clear_logs', 'trendyol_nonce'); ?>
                <button type="submit" name="clear_logs" class="button" onclick="return confirm('Tüm logları silmek istediğinizden emin misiniz?');">
                    🗑️ Logları Temizle
                </button>
            </form>
        </div>

        <table class="widefat striped">
            <thead>
                <tr>
                    <th style="width: 180px;">Tarih/Saat</th>
                    <th style="width: 100px;">Seviye</th>
                    <th>Mesaj</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                    <tr>
                        <td colspan="3" style="text-align: center; padding: 40px; color: #999;">
                            <p style="font-size: 16px;">📭 Henüz log kaydı yok.</p>
                            <p style="font-size: 14px;">Ürün aktarma işlemi yaptığınızda loglar burada görünecektir.</p>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td style="font-size: 12px;">
                                <?php 
                                $date = new DateTime($log->created_at);
                                echo $date->format('d.m.Y H:i:s'); 
                                ?>
                            </td>
                            <td>
                                <span class="log-badge log-<?php echo esc_attr($log->level); ?>">
                                    <?php 
                                    $icons = [
                                        'info' => 'ℹ️',
                                        'success' => '✓',
                                        'warning' => '⚠️',
                                        'error' => '✗'
                                    ];
                                    echo $icons[$log->level] ?? '•';
                                    ?>
                                    <?php echo esc_html(strtoupper($log->level)); ?>
                                </span>
                            </td>
                            <td style="font-size: 13px;"><?php echo esc_html($log->message); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="card" style="max-width: 100%; margin-top: 20px; background: #f0f8ff; border-left: 4px solid #2196F3;">
        <h2>ℹ️ Log Seviyeleri</h2>
        <ul style="line-height: 2; font-size: 14px;">
            <li><span class="log-badge log-info">ℹ️ INFO</span> - Genel bilgi mesajları (senkronizasyon başladı, tamamlandı vb.)</li>
            <li><span class="log-badge log-success">✓ SUCCESS</span> - Başarılı işlemler</li>
            <li><span class="log-badge log-warning">⚠️ WARNING</span> - Uyarı mesajları (önemli ama kritik olmayan)</li>
            <li><span class="log-badge log-error">✗ ERROR</span> - Hata mesajları (işlem başarısız oldu)</li>
        </ul>
    </div>
</div>

<style>
.card {
    background: #fff;
    border: 1px solid #ccd0d4;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    padding: 20px;
    margin-bottom: 20px;
}

.card h2 {
    margin-top: 0;
    padding-bottom: 10px;
    border-bottom: 2px solid #f27a1a;
    color: #23282d;
}

.widefat tbody tr:hover {
    background: #f5f5f5;
}

.log-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: bold;
    text-transform: uppercase;
}

.log-info {
    background: #d1ecf1;
    color: #0c5460;
    border: 1px solid #bee5eb;
}

.log-success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.log-warning {
    background: #fff3cd;
    color: #856404;
    border: 1px solid #ffeaa7;
}

.log-error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}
</style>