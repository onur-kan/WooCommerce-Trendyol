jQuery(function ($){

    //TRENDYOL SELECT2
    $('.trendyol_select_2').select2();
    //TRENDYOL SELECT2

    $('.trendyol_select_2_search').select2({
        minimumInputLength: 3,
        ajax              : {
            url           : ajaxurl, // AJAX URL is predefined in WordPress admin
            dataType      : 'json',
            type          : 'post',
            delay         : 250, // delay in ms while typing when to perform a AJAX search
            data          : function (params){
                return {
                    q     : params.term, // search query
                    action: 'wc_trendyol_search_brand' // AJAX action for admin-ajax.php
                };
            },
            processResults: function (data){
                var options = [];
                if (data){

                    // data is the array of arrays, and each of them contains ID and the Label of the option
                    $.each(data, function (index, text){ // do not forget that "index" is just auto incremented value
                        options.push({
                            id  : text[0],
                            text: text[1]
                        });
                    });

                }
                return {
                    results: options
                };
            },
            cache         : true
        },
    });

    //CALC TRENDYOL COMMISSION
    function calc_trendyol_cat_commission(){

        var wc_trendyol_price          = $('.wc_trendyol_product_sales_price_input').val();
        var wc_trendyol_cat_commission = $('.wc_trendyol_cat_commission_input').data('trendyol_cat_commission');

        if (wc_trendyol_cat_commission > 0){
            $('.wc_trendyol_cat_commission_input').val(((wc_trendyol_price / 100) * wc_trendyol_cat_commission).toFixed(2));
        }
    }

    $('.wc_trendyol_product_sales_price_input').on('keyup', function (){
        calc_trendyol_cat_commission();
    })

    if ($('.wc_trendyol_settings_tab').length > 0){
        calc_trendyol_cat_commission();
    }
    jQuery(function($) {
    $('#wc-trendyol-sync-product').on('click', function() {
        var $btn = $(this);
        var $status = $('#wc-trendyol-sync-status');

        $btn.prop('disabled', true);
        $status.text('Trendyol\'a gönderiliyor...');

        $.post(ajaxurl, {
            action: 'wc_trendyol_sync_single_product',
            post_id: $('#post_ID').val(),
            _wpnonce: wc_trendyol_admin.nonce // PHP tarafında localized script ile veririz
        }, function(response) {
            $btn.prop('disabled', false);

            if (response && response.success) {
                $status.text('Başarılı: ' + (response.data && response.data.message ? response.data.message : 'Ürün güncellendi.'));
            } else {
                let msg = (response && response.data && response.data.message) ? response.data.message : 'Bilinmeyen hata';
                $status.text('Hata: ' + msg);
            }
        }).fail(function() {
            $btn.prop('disabled', false);
            $status.text('AJAX hatası oluştu.');
        });
    });
});

    //CALC TRENDYOL COMMISSION

    //SEARCH BRAND

    //SEARCH BRAND

    //AJAX ADD PRODUCT

    //AJAX ADD PRODUCT
});