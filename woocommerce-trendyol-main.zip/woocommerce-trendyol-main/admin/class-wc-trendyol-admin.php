<?php

/**
 * The admin-specific functionality of the plugin - IMPROVED VERSION
 *
 * @link       https://hayatikodla.net/hasan-yuksektepe-kimdir/
 * @since      2.0.0
 *
 * @package    Wc_Trendyol
 * @subpackage Wc_Trendyol/admin
 */

class Wc_Trendyol_Admin {

    private $plugin_name;
    private $version;

    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;

        // ADD MENU
        add_action('admin_menu', [$this, 'trendyol_add_menu']);

        // ADD WOOCOMMERCE PRODUCT CATEGORY FIELDS
        add_action('product_cat_add_form_fields', [$this, 'wc_trendyol_add_wc_category_field'], 10, 2);
        add_action('product_cat_edit_form_fields', [$this, 'wc_trendyol_add_wc_category_field'], 10, 2);
        add_action("created_product_cat", [$this, "wc_trendyol_add_wc_category_field_save"]);
        add_action("edited_product_cat", [$this, "wc_trendyol_add_wc_category_field_save"]);

        // ADD WOOCOMMERCE PRODUCT CATEGORY COLUMN
        add_action('manage_edit-product_cat_columns', [$this, 'trendyol_add_wc_category_column'], 10, 2);
        add_action('manage_product_cat_custom_column', [$this, 'trendyol_add_wc_category_column_data'], 10, 3);

        // SAVE TRENDYOL PRICE
        add_action('woocommerce_process_product_meta', [$this, 'wc_trendyol_save_basic_production_price_field']);

        // ADD WC PRODUCT LIST CUSTOM COL
        add_filter('manage_edit-product_columns', [$this, 'woocommerce_trendyol_add_product_table_column'], 20);
        add_action('manage_product_posts_custom_column', [$this, 'woocommerce_trendyol_add_product_table_column_data'], 2);

        // ADD AJAX
        add_action('wp_ajax_wc_trendyol_search_brand', [$this, 'wc_trendyol_search_brand']);
        add_action('wp_ajax_wc_trendyol_test_connection', [$this, 'ajax_test_connection']);
        add_action('wp_ajax_wc_trendyol_sync_products', [$this, 'ajax_sync_products']);
        add_action('wp_ajax_wc_trendyol_import_single_product', [$this, 'ajax_import_single_product']);

        // ADD WC TAB
        add_filter('woocommerce_product_data_tabs', [$this, 'wc_trendyol_add_woocommerce_product_tab'], 10, 1);
        add_action('woocommerce_product_data_panels', [$this, 'wc_trendyol_add_woocommerce_product_tab_content']);

        // WOOCOMMERCE BACKGROUND PROCESSING
        add_action('init', function() {
            add_action('wc_trendyol_trendyol_product_exists_control', [$this, 'wc_trendyol_trendyol_product_exists_control'], 10, 3);
            if (false === as_has_scheduled_action('wc_trendyol_trendyol_product_exists_control')) {
                as_schedule_recurring_action(strtotime('midnight tonight'), (60 * 10), 'wc_trendyol_trendyol_product_exists_control');
            }
        });

        // REDIRECT WELCOME PAGE
        add_action('wc_trendyol_welcome', [$this, 'wc_trendyol_welcome_set_redirect']);
        add_action('admin_init', [$this, 'wc_trendyol_welcome_redirect']);
    }

    // REDIRECT WELCOME PAGE
    function wc_trendyol_welcome_set_redirect() {
        if (!is_network_admin()) {
            set_transient('wc_trendyol_page_welcome_redirect', 1, 30);
        }
    }

    function wc_trendyol_welcome_redirect() {
        $redirect = get_transient('wc_trendyol_page_welcome_redirect');
        delete_transient('wc_trendyol_page_welcome_redirect');
        if ($redirect) {
            wp_safe_redirect(admin_url('admin.php?page=' . rawurlencode('trendyol_settings')));
        }
    }

    // AJAX TEST CONNECTION
    public function ajax_test_connection() {
        check_ajax_referer('trendyol_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(__('Yetkiniz yok', 'wc-trendyol'));
        }

        global $trendyol_adapter;
        
        try {
            $products = $trendyol_adapter->get_my_all_products();
            
            if ((isset($products->exception) && $products->exception == 'TrendyolAuthorizationException') || 
                (isset($products->status) && $products->status == '404')) {
                wp_send_json_error(__('Bağlantı başarısız! API bilgilerinizi kontrol edin.', 'wc-trendyol'));
            } else {
                $total = $products->totalElements ?? 0;
                wp_send_json_success(sprintf(__('Bağlantı başarılı! Trendyol\'da %d ürün bulundu.', 'wc-trendyol'), $total));
            }
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    // AJAX SYNC PRODUCTS
    public function ajax_sync_products() {
        check_ajax_referer('trendyol_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(__('Yetkiniz yok', 'wc-trendyol'));
        }

        global $trendyol_adapter;
        
        $page = isset($_POST['page']) ? intval($_POST['page']) : 0;
        $size = 50;
        
        try {
            $products = $trendyol_adapter->get_my_all_products();
            
            if (!isset($products->content) || empty($products->content)) {
                wp_send_json_error(__('Ürün bulunamadı', 'wc-trendyol'));
                return;
            }
            
            $total_pages = $products->totalPages ?? 1;
            $total_elements = $products->totalElements ?? 0;
            
            // Sayfa verilerini al
            $start = $page * $size;
            $products_to_import = array_slice($products->content, $start, $size);
            
            $imported = 0;
            $errors = [];
            
            foreach ($products_to_import as $trd_product) {
                $result = $this->import_trendyol_product($trd_product);
                if ($result['success']) {
                    $imported++;
                } else {
                    $errors[] = $result['message'];
                }
            }
            
            // Log kaydet
            $this->log_sync_action('info', sprintf(
                'Sayfa %d senkronize edildi. %d/%d ürün aktarıldı.',
                $page + 1,
                $imported,
                count($products_to_import)
            ));
            
            // İlk sayfada toplam bilgisini kaydet
            if ($page == 0) {
                update_option('wc_trendyol_total_products', $total_elements);
                update_option('wc_trendyol_last_sync', current_time('mysql'));
            }
            
            // İlerlemeyi kaydet
            $current_synced = get_option('wc_trendyol_synced_products', 0);
            update_option('wc_trendyol_synced_products', $current_synced + $imported);
            
            $progress = min(100, round((($page + 1) / $total_pages) * 100, 2));
            
            wp_send_json_success([
                'imported' => $imported,
                'current_page' => $page,
                'total_pages' => $total_pages,
                'total_elements' => $total_elements,
                'has_more' => ($page + 1) < $total_pages,
                'progress' => $progress,
                'errors' => $errors
            ]);
            
        } catch (Exception $e) {
            $this->log_sync_action('error', 'Senkronizasyon hatası: ' . $e->getMessage());
            wp_send_json_error($e->getMessage());
        }
    }

    // IMPORT SINGLE TRENDYOL PRODUCT
    private function import_trendyol_product($trd_product) {
        try {
            $barcode = $trd_product->barcode ?? '';
            
            if (empty($barcode)) {
                return ['success' => false, 'message' => 'Barkod bulunamadı'];
            }
            
            // Ürün var mı kontrol et (SKU ile)
            $existing_product_id = wc_get_product_id_by_sku($barcode);
            
            if ($existing_product_id) {
                // Varolan ürünü güncelle
                $product = wc_get_product($existing_product_id);
            } else {
                // Yeni ürün oluştur
                $product = new WC_Product_Simple();
            }
            
            // Ürün bilgilerini ayarla
            $product->set_name($trd_product->title ?? 'Ürün Adı Yok');
            $product->set_description($trd_product->description ?? '');
            $product->set_sku($barcode);
            $product->set_regular_price($trd_product->listPrice ?? 0);
            $product->set_sale_price($trd_product->salePrice ?? 0);
            $product->set_stock_quantity($trd_product->quantity ?? 0);
            $product->set_manage_stock(true);
            
            if (($trd_product->quantity ?? 0) > 0) {
                $product->set_stock_status('instock');
            } else {
                $product->set_stock_status('outofstock');
            }
            
            // Meta bilgileri
            $product->update_meta_data('_trendyol_barcode', $barcode);
            $product->update_meta_data('_trendyol_product_code', $trd_product->productCode ?? '');
            $product->update_meta_data('_trendyol_last_sync', current_time('mysql'));
            $product->update_meta_data('wc_trendyol_is_trendyol_exists', 1);
            $product->update_meta_data('wc_trendyol_is_trendyol_sales_price', $trd_product->salePrice ?? 0);
            
            $product_id = $product->save();
            
            // Kategorileri ayarla
            if (isset($trd_product->pimCategoryId) && !empty($trd_product->pimCategoryId)) {
                $this->set_product_category($product_id, $trd_product->pimCategoryId);
            }
            
            // Görselleri import et
            if (isset($trd_product->images) && !empty($trd_product->images)) {
                $this->import_product_images($product_id, $trd_product->images);
            }
            
            return ['success' => true, 'product_id' => $product_id];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    // SET PRODUCT CATEGORY
    private function set_product_category($product_id, $trendyol_category_id) {
        global $wpdb;
        
        // WooCommerce kategorilerinden Trendyol ID'si eşleşeni bul
        $wc_category_id = $wpdb->get_var($wpdb->prepare(
            "SELECT term_id FROM {$wpdb->termmeta} WHERE meta_key = 'trendyol_wc_category_id' AND meta_value = %s",
            $trendyol_category_id
        ));
        
        if ($wc_category_id) {
            wp_set_object_terms($product_id, [(int)$wc_category_id], 'product_cat');
        }
    }

    // IMPORT PRODUCT IMAGES
    private function import_product_images($product_id, $images) {
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        $gallery_ids = [];
        
        foreach ($images as $index => $image) {
            $image_url = $image->url ?? '';
            
            if (empty($image_url)) {
                continue;
            }
            
            // Görsel zaten var mı kontrol et
            $existing_attachment = $this->get_attachment_by_url($image_url);
            
            if ($existing_attachment) {
                $attachment_id = $existing_attachment;
            } else {
                // Görseli indir
                $tmp = download_url($image_url);
                
                if (is_wp_error($tmp)) {
                    continue;
                }
                
                $file_array = [
                    'name' => basename($image_url),
                    'tmp_name' => $tmp
                ];
                
                $attachment_id = media_handle_sideload($file_array, $product_id);
                
                if (is_wp_error($attachment_id)) {
                    @unlink($file_array['tmp_name']);
                    continue;
                }
                
                update_post_meta($attachment_id, '_trendyol_image_url', $image_url);
            }
            
            // İlk görsel ana görsel olsun
            if ($index === 0) {
                set_post_thumbnail($product_id, $attachment_id);
            } else {
                $gallery_ids[] = $attachment_id;
            }
        }
        
        // Galeri görsellerini ayarla
        if (!empty($gallery_ids)) {
            update_post_meta($product_id, '_product_image_gallery', implode(',', $gallery_ids));
        }
    }

    // GET ATTACHMENT BY URL
    private function get_attachment_by_url($url) {
        global $wpdb;
        
        $attachment = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_trendyol_image_url' AND meta_value = %s LIMIT 1",
            $url
        ));
        
        return $attachment ? intval($attachment) : null;
    }

    // LOG SYNC ACTION
    private function log_sync_action($level, $message) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'trendyol_sync_logs';
        
        // Tablo yoksa oluştur
        $wpdb->query("CREATE TABLE IF NOT EXISTS {$table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            level varchar(20) NOT NULL,
            message text NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY level (level),
            KEY created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        
        $wpdb->insert(
            $table_name,
            [
                'level' => $level,
                'message' => $message,
                'created_at' => current_time('mysql')
            ],
            ['%s', '%s', '%s']
        );
    }

    // WOOCOMMERCE BACKGROUND PROCESSING (MEVCUT)
    public function wc_trendyol_trendyol_product_exists_control() {
        global $trendyol_adapter;

        $get_wc_products = wc_get_products([
            'limit' => -1,
            'status' => 'publish',
        ]);

        if ($get_wc_products != null) {
            foreach ($get_wc_products as $product) {
                $post_id = $product->get_id();
                $sku = $product->get_sku();
                
                if (!empty($sku)) {
                    $trd_product = $trendyol_adapter->get_my_product($sku);

                    if ($trd_product->totalElements != null) {
                        update_post_meta($post_id, 'wc_trendyol_is_trendyol_exists', 1);
                        update_post_meta($post_id, 'wc_trendyol_is_trendyol_sales_price', $trd_product->content[0]->salePrice);
                    } else {
                        update_post_meta($post_id, 'wc_trendyol_is_trendyol_exists', 0);
                        update_post_meta($post_id, 'wc_trendyol_is_trendyol_sales_price', 0);
                    }
                }
            }
        }
    }

    // ADD WC TAB
    function wc_trendyol_add_woocommerce_product_tab_content() {
        global $woocommerce, $post, $trendyol_adapter;

        $wc_product = wc_get_product($post->ID);
        $sku = $wc_product->get_sku();
        $cat = $wc_product->get_category_ids();
        $wc_trendyolduct_trendyol_barcode = get_post_meta($post->ID, 'wc_trendyolduct_trendyol_barcode', true);

        if (!empty($sku)) {
            $wc_trendyolduct = $trendyol_adapter->get_my_product($sku);
            $wc_trendyolduct = $wc_trendyolduct->content[0] ?? null;
            if ($wc_trendyolduct != null) {
                update_post_meta($post->ID, 'wc_trendyol_trendyol_product_code', $sku);
            }
        } else {
            $wc_trendyolduct = null;
        }

        if (!empty($wc_trendyolduct_trendyol_barcode) && $wc_trendyolduct == null) {
            $wc_trendyolduct = $trendyol_adapter->get_my_product($wc_trendyolduct_trendyol_barcode);
            $wc_trendyolduct = $wc_trendyolduct->content[0] ?? null;
            if ($wc_trendyolduct != null) {
                update_post_meta($post->ID, 'wc_trendyol_trendyol_product_code', $wc_trendyolduct_trendyol_barcode);
            }
        }

        $wc_trendyolduct_sale_price = $wc_trendyolduct->salePrice ?? 0;
        $wc_trendyolduct_list_price = $wc_trendyolduct->listPrice ?? 0;

        // TRENDYOL COMMISSION
        $product_cat_id = current($cat);
        $get_trendyol_wc_category_id = get_term_meta($product_cat_id, 'trendyol_wc_category_id', true);
        if (!empty($get_trendyol_wc_category_id)) {
            $get_trendyol_cat_commission = $trendyol_adapter->get_category_info($get_trendyol_wc_category_id);
        }

        // PRODUCT BRAND
        $main_brand = get_option('wc_trendyol_main_brand', null) ?? '';
        $wc_trendyolduct_brand = get_post_meta($post->ID, 'wc_trendyolduct_brand', true);
        if (!empty($wc_trendyolduct_brand)) {
            $brand_explode = explode(':', $wc_trendyolduct_brand);
        } else if (!empty($main_brand)) {
            $brand_explode = explode(':', $main_brand);
        }

        // PRODUCT SHOW CUSTOMER QUESTIONS
        $wc_trendyol_show_customer_questions = get_post_meta($post->ID, 'wc_trendyol_show_customer_questions', true);

        // PRODUCT LOCKED CONTROL
        $product_locked = $wc_trendyolduct->locked ?? null;
        $product_locked_message = $wc_trendyolduct->lockReason ?? null;

        ?>
        <div id="wc_trendyol_settings_tab" class="wc_trendyol_settings_tab panel woocommerce_options_panel">

            <?php if ($product_locked == 1): ?>
                <div class="wc_trendyol_alert">
                    <?= __('Ürününüz kilitlenmiş sebebi', 'wc-trendyol') ?>: <strong><?= $product_locked_message ?></strong>
                </div>
            <?php endif; ?>

            <h1 class="wc_trendyol_title">
                <img class="wc_trendyol_title_img" src="<?php echo plugin_dir_url(__DIR__) . '/admin/img/trendyol-logo.jpg'; ?>">
                <?php _e('Trendyol Ayarları', 'wc-trendyol'); ?>
            </h1>

            <div class="wc_trendyol_settings wc_trendyol_col_2">
                <label><?php _e('Stok Kodu', 'wc-trendyol'); ?></label>
                <input type="text" value="<?= (!empty($sku) ? $sku : 'SKU YOK') ?>" disabled>
            </div>

            <div class="wc_trendyol_settings wc_trendyol_col_2">
                <label><?php _e('Trendyol Barkodu', 'wc-trendyol'); ?></label>
                <input type="text" name="wc_trendyolduct_trendyol_barcode" class="wc_trendyolduct_trendyol_barcode" value="<?php echo(!empty($wc_trendyolduct_trendyol_barcode) ? $wc_trendyolduct_trendyol_barcode : ''); ?>">
            </div>

            <?php if ($wc_trendyolduct != null): ?>
                <div class="wc_trendyol_settings wc_trendyol_col_4">
                    <label><?php _e('Trendyol Liste Fiyatı', 'wc-trendyol'); ?> (₺)</label>
                    <input type="text" name="wc_trendyolduct_list_price_input" class="wc_trendyolduct_list_price_input" value="<?php echo $wc_trendyolduct_list_price; ?>">
                </div>
                <div class="wc_trendyol_settings wc_trendyol_col_4">
                    <label><?php _e('Trendyol Satış Fiyatı', 'wc-trendyol'); ?> (₺)</label>
                    <input type="text" name="wc_trendyolduct_sales_price_input" class="wc_trendyol_product_sales_price_input" value="<?php echo $wc_trendyolduct_sale_price; ?>">
                </div>
                <div class="wc_trendyol_settings wc_trendyol_col_4">
                    <label><?php _e('Trendyol Kategori Komisyonu', 'wc-trendyol'); ?> (₺)</label>
                    <input type="text" name="wc_trendyol_cat_commission_input" class="wc_trendyol_cat_commission_input" data-trendyol_cat_commission="<?php echo $get_trendyol_cat_commission->commission ?? 0 ?>" placeholder="<?php echo $get_trendyol_cat_commission->commission ?? __('Kategori Eşleşmemiş') ?>" disabled>
                </div>
                <div class="wc_trendyol_settings wc_trendyol_col_4">
                    <label><?php _e('Trendyol Markası', 'wc-trendyol'); ?></label>
                    <select name="wc_trendyolduct_brand" class="trendyol_select_2_search">
                        <?php if (isset($brand_explode)): ?>
                            <option value="<?= $brand_explode[0] ?>:<?= $brand_explode[1] ?>" selected><?= $brand_explode[1] ?></option>
                        <?php else: ?>
                            <option value="">Marka Ara</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="wc_trendyol_settings wc_trendyol_col_12">
                    <label><?php _e('Ürün Detayda Müşteri Sorularını Göster', 'wc-trendyol'); ?></label>
                    <input type="checkbox" name="wc_trendyol_show_customer_questions" class="wc_trendyol_show_customer_questions" <?php echo(($wc_trendyol_show_customer_questions == 1) ? 'checked' : '') ?>>
                </div>
            <?php else: ?>
                <div class="wc_trendyol_alert">
                    <?php _e('SKU veya Barkod bilgileri Trendyol ile eşleşmediği için fiyat bölümünü göremiyorsunuz. Lütfen SKU veya Barkodu Trendyoldaki ürün ile aynı olacak şekilde ayarlayınız.', 'wc-trendyol'); ?>
                </div>
            <?php endif; ?>

        </div>
        <?php
    }

    public function wc_trendyol_add_woocommerce_product_tab($default_tabs) {
        $default_tabs['wc_trendyol_settings_tab'] = [
            'label' => __('Trendyol Ayarları', 'wc-trendyol'),
            'target' => 'wc_trendyol_settings_tab',
            'priority' => 60,
            'class' => ['show_if_simple', 'show_if_variable'],
        ];

        return $default_tabs;
    }

    // ADD AJAX - BRAND SEARCH
    public function wc_trendyol_search_brand() {
        global $trendyol_adapter;
        $query = esc_attr($_POST['q']);

        $trendyol_brands = $trendyol_adapter->search_brand($query);

        foreach ($trendyol_brands as $brand) {
            $title = (mb_strlen($brand->name) > 50) ? mb_substr($brand->name, 0, 49) . '...' : $brand->name;
            $return[] = [$brand->id . ':' . $title, $title . ' (' . $brand->id . ')'];
        }

        echo json_encode($return);
        wp_die();
    }

    // ADD WC PRODUCT LIST CUSTOM COL
    public function woocommerce_trendyol_add_product_table_column($columns) {
        $offset = 5;
        $trendyol_exists = array_slice($columns, 0, $offset, true) + ['trendyol_exists' => esc_html__('Trendyolda var mı?', 'woocommerce-trendyol')] + array_slice($columns, $offset, null, true);

        $offset = 7;
        $trendyol_price = array_slice($trendyol_exists, 0, $offset, true) + ['trendyol_price' => esc_html__('Trendyol Satış Fiyatı', 'woocommerce-trendyol')] + array_slice($trendyol_exists, $offset, null, true);

        return $trendyol_price;
    }

    function woocommerce_trendyol_add_product_table_column_data($column) {
        global $post, $trendyol_adapter;

        $wc_product = wc_get_product($post->ID);
        $sku = $wc_product->get_sku();
        
        if (!empty($sku)) {
            $product_trendyol_exists = get_post_meta($post->ID, 'wc_trendyol_is_trendyol_exists', true);
            $product_trendyol_price = get_post_meta($post->ID, 'wc_trendyol_is_trendyol_sales_price', true);

            if ($column == 'trendyol_exists') {
                $plugin_dir = plugin_dir_url(__DIR__);

                if ($product_trendyol_exists != 0) {
                    echo('<img src="' . $plugin_dir . '/admin/img/yes.png">');
                } else {
                    echo('<img src="' . $plugin_dir . '/admin/img/no.png">');
                }
            } else if ($column == 'trendyol_price') {
                if ($product_trendyol_exists != 0) {
                    echo wc_price($product_trendyol_price);
                } else {
                    echo '-';
                }
            }
        } else {
            if ($column == 'trendyol_exists') {
                echo 'Ürün Eşleştirilmemiş';
            } else if ($column == 'trendyol_price') {
                echo 0;
            }
        }
    }

    // SAVE TRENDYOL PRICE
    public function wc_trendyol_save_basic_production_price_field($post_id) {
        global $trendyol_adapter;

        $wc_product = wc_get_product($post_id);
        $sku = $wc_product->get_sku();
        $wc_trendyolduct_trendyol_prodcut_code = get_post_meta($post_id, 'wc_trendyol_trendyol_product_code', true);

        // TRENDYOL BARCODE SAVE
        if (isset($_POST['wc_trendyolduct_trendyol_barcode']) && !empty($_POST['wc_trendyolduct_trendyol_barcode'])) {
            update_post_meta($post_id, 'wc_trendyolduct_trendyol_barcode', sanitize_text_field($_POST['wc_trendyolduct_trendyol_barcode']));
        }

        // TRENDYOL BRAND SAVE
        if (isset($_POST['wc_trendyolduct_brand']) && !empty($_POST['wc_trendyolduct_brand'])) {
            $wc_trendyolduct_brand = sanitize_text_field($_POST['wc_trendyolduct_brand']);
            update_post_meta($post_id, 'wc_trendyolduct_brand', $wc_trendyolduct_brand);

            $brand_explode = explode(':', $wc_trendyolduct_brand);
            $wc_trendyolduct_info = $trendyol_adapter->get_my_product($sku);
            $product_info = $wc_trendyolduct_info->content[0];

            $product_title = $product_info->title;
            $product_desc = $product_info->description;
            $product_images = $product_info->images;
            $product_stock = $wc_product->get_price();
            $product_cat_id = $product_info->pimCategoryId;

            $trendyol_adapter->update_product($sku, $product_title, $product_desc, $product_images, 18, $product_stock, $wc_trendyolduct_price, $brand_explode[0], $product_cat_id);
        }

        // TRENDYOL SALE PRICE SAVE
        $wc_trendyolduct_list_price_input = sanitize_text_field($_POST['wc_trendyolduct_list_price_input']);
        $wc_trendyolduct_sales_price_input = sanitize_text_field($_POST['wc_trendyolduct_sales_price_input']);
        if (isset($_POST['wc_trendyolduct_list_price_input'], $_POST['wc_trendyolduct_sales_price_input']) && !empty($_POST['wc_trendyolduct_sales_price_input'])) {
            $trendyol_adapter->update_product_price($wc_trendyolduct_trendyol_prodcut_code, $wc_trendyolduct_list_price_input, $wc_trendyolduct_sales_price_input);
        }

        // TRENDYOL PRODUCT DETAIL SHOW CUSTOMER QUESTION
        if (isset($_POST['wc_trendyol_show_customer_questions']) && !empty($_POST['wc_trendyol_show_customer_questions'])) {
            update_post_meta($post_id, 'wc_trendyol_show_customer_questions', 1);
        } else {
            delete_post_meta($post_id, 'wc_trendyol_show_customer_questions');
        }
    }

    // ADD WOOCOMMERCE PRODUCT CATEGORY COLUMN
    public function trendyol_add_wc_category_column($columns) {
        $columns['trendyol_category'] = __('Trendyol Kategorisi', 'wc-trendyol');
        return $columns;
    }

    public function trendyol_add_wc_category_column_data($columns, $column, $term_id) {
        global $trendyol_adapter;

        if ($column == 'trendyol_category') {
            $plugin_dir = plugin_dir_url(__DIR__);
            $get_trendyol_wc_category_id = get_term_meta($term_id, 'trendyol_wc_category_id', true);
            
            if (!empty($get_trendyol_wc_category_id)) {
                $get_category_info = $trendyol_adapter->get_category_info($get_trendyol_wc_category_id);
                return (('<img src="' . $plugin_dir . 'admin/img/yes.png">')) . ' ' . ($get_category_info->displayName ?? 'Trendyoldan alınamadı');
            } else {
                return (('<img src="' . $plugin_dir . 'admin/img/no.png">')) . ' ' . __('Trendyol ile eşitlenmemiş', 'wc-trendyol');
            }
        }

        return $columns;
    }

    // ADD WOOCOMMERCE PRODUCT CATEGORY FIELDS
    public function wc_trendyol_add_wc_category_field($term) {
        global $woocommerce, $post, $trendyol_adapter;

        wp_nonce_field('trendyol_pro_taxonomy_specific_nonce_data', 'trendyol_pro_taxonomy_specific_nonce');

        if (isset($term->term_id)) {
            $get_trendyol_wc_category_id = get_term_meta($term->term_id, 'trendyol_wc_category_id', true);
        }

        $trendyol_categories = $trendyol_adapter->get_all_categories();
        $convert_option = $this->trendyol_categories_array_to_select_option($trendyol_categories->categories, 0, ($get_trendyol_wc_category_id ?? 0));
        ?>
        <tr>
            <th><?php _e('Trendyol Kategorisine Denk Gelen Kategori', 'wc-trendyol'); ?></th>
            <td>
                <select name="trendyol_category_id" id="trendyol_category_id" class="trendyol_select_2">
                    <?php echo $convert_option; ?>
                </select>
            </td>
        </tr>
        <?php
    }

    public function wc_trendyol_add_wc_category_field_save($post_id) {
        if (!wp_verify_nonce($_POST['trendyol_pro_taxonomy_specific_nonce'], 'trendyol_pro_taxonomy_specific_nonce_data')) {
            return $post_id;
        }

        if (isset($_POST['trendyol_category_id']) && !empty($_POST['trendyol_category_id'])) {
            $trendyol_category_id = esc_attr($_POST['trendyol_category_id']);
            update_term_meta($post_id, 'trendyol_wc_category_id', $trendyol_category_id);
        } else {
            delete_term_meta($post_id, 'trendyol_wc_category_id');
        }
    }

    // ADD MENU
    public function trendyol_add_menu() {
        add_submenu_page(
            'woocommerce',
            __('Trendyol Ayarları', 'wc-trendyol'),
            __('Trendyol Ayarları', 'wc-trendyol'),
            'manage_woocommerce',
            'trendyol_settings',
            [$this, 'wc_trendyol_settings_page']
        );
        
        add_submenu_page(
            'woocommerce',
            __('Trendyol Ürün Aktarma', 'wc-trendyol'),
            __('Trendyol Ürün Aktarma', 'wc-trendyol'),
            'manage_woocommerce',
            'trendyol_product_import',
            [$this, 'wc_trendyol_product_import_page']
        );
        
        add_submenu_page(
            'woocommerce',
            __('Trendyol Loglar', 'wc-trendyol'),
            __('Trendyol Loglar', 'wc-trendyol'),
            'manage_woocommerce',
            'trendyol_logs',
            [$this, 'wc_trendyol_logs_page']
        );
    }

    public function wc_trendyol_settings_page() {
        require (__DIR__) . "/partials/wc-trendyol-admin-display.php";
    }

    public function wc_trendyol_product_import_page() {
        require (__DIR__) . "/partials/wc-trendyol-product-import-page-improved.php";
    }
    
    public function wc_trendyol_logs_page() {
        require (__DIR__) . "/partials/wc-trendyol-logs-page.php";
    }

    /**
     * Register the stylesheets for the admin area.
     */
    public function enqueue_styles() {
        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/wc-trendyol-admin.css', [], $this->version, 'all');
        wp_enqueue_style($this->plugin_name . '-select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css', [], $this->version, 'all');
    }

    /**
     * Register the JavaScript for the admin area.
     */
    public function enqueue_scripts() {
        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/wc-trendyol-admin.js', ['jquery'], $this->version, true);
        wp_enqueue_script($this->plugin_name . '-select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', ['jquery'], $this->version, true);
        
        // AJAX için localize
        wp_localize_script($this->plugin_name, 'trendyolAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('trendyol_nonce')
        ]);
    }

    public function trendyol_categories_array_to_select_option($categories = null, $depth = 0, $selected = 0) {
        $html = '';
        if ($categories != null) {
            foreach ($categories as $id => $category) {
                if (isset($category->subCategories) && $category->subCategories != null) {
                    $html .= '<option value="' . $category->id . '" ' . ($selected == $category->id ? 'selected' : '') . '>' . str_repeat('-', ($depth)) . $category->name . '</option>';
                    $html .= $this->trendyol_categories_array_to_select_option($category->subCategories, ($depth + 1), $selected);
                } else {
                    $html .= '<option value="' . $category->id . '" ' . ($selected == $category->id ? 'selected' : '') . '>' . str_repeat('-', ($depth)) . $category->name . '</option>';
                }
            }
        }

        return $html;
    }
}