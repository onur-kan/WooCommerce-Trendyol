<?php
/**
 * Trendyol API Sınıfı
 * Trendyol API ile iletişimi yönetir
 */

if (!defined('ABSPATH')) {
    exit;
}

class TWS_API {
    
    private $api_key;
    private $api_secret;
    private $supplier_id;
    private $base_url = 'https://api.trendyol.com/sapigw/suppliers/';
    
    /**
     * Constructor
     */
    public function __construct() {
        $settings = get_option('tws_settings', array());
        $this->api_key = isset($settings['api_key']) ? $settings['api_key'] : '';
        $this->api_secret = isset($settings['api_secret']) ? $settings['api_secret'] : '';
        $this->supplier_id = isset($settings['supplier_id']) ? $settings['supplier_id'] : '';
    }
    
    /**
     * API bağlantısını test et
     */
    public function test_connection() {
        if (empty($this->api_key) || empty($this->api_secret) || empty($this->supplier_id)) {
            return array(
                'success' => false,
                'message' => 'API bilgileri eksik. Lütfen ayarları kontrol edin.'
            );
        }
        
        $response = $this->request('GET', 'products', array('size' => 1));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Bağlantı hatası: ' . $response->get_error_message()
            );
        }
        
        if (isset($response['content'])) {
            return array(
                'success' => true,
                'message' => 'Bağlantı başarılı! Trendyol API\'ye erişim sağlandı.'
            );
        }
        
        return array(
            'success' => false,
            'message' => 'Beklenmeyen yanıt alındı.'
        );
    }
    
    /**
     * Trendyol ürünlerini getir
     */
    public function get_products($page = 0, $size = 50) {
        $params = array(
            'page' => $page,
            'size' => $size
        );
        
        $response = $this->request('GET', 'products', $params);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        return array(
            'success' => true,
            'data' => $response
        );
    }
    
    /**
     * Tek bir ürünü getir
     */
    public function get_product($barcode) {
        $response = $this->request('GET', 'products', array('barcode' => $barcode));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        return array(
            'success' => true,
            'data' => $response
        );
    }
    
    /**
     * Ürün stok güncelle
     */
    public function update_stock($items) {
        $response = $this->request('POST', 'products/price-and-inventory', array(
            'items' => $items
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        return array(
            'success' => true,
            'data' => $response
        );
    }
    
    /**
     * Kategorileri getir
     */
    public function get_categories() {
        $response = $this->request('GET', 'product-categories');
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        return array(
            'success' => true,
            'data' => isset($response['categories']) ? $response['categories'] : array()
        );
    }
    
    /**
     * Siparişleri getir
     */
    public function get_orders($params = array()) {
        $default_params = array(
            'page' => 0,
            'size' => 50,
            'status' => 'Created'
        );
        
        $params = wp_parse_args($params, $default_params);
        
        $response = $this->request('GET', 'orders', $params);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        return array(
            'success' => true,
            'data' => $response
        );
    }
    
    /**
     * API isteği gönder
     */
    private function request($method, $endpoint, $data = array()) {
        $url = $this->base_url . $this->supplier_id . '/' . $endpoint;
        
        // GET isteği için URL parametreleri
        if ($method === 'GET' && !empty($data)) {
            $url .= '?' . http_build_query($data);
            $data = array();
        }
        
        $args = array(
            'method' => $method,
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode($this->api_key . ':' . $this->api_secret),
                'Content-Type' => 'application/json',
                'User-Agent' => 'TrendyolWooCommerceSync/1.0'
            ),
            'timeout' => 30
        );
        
        // POST/PUT için body ekle
        if (!empty($data) && ($method === 'POST' || $method === 'PUT')) {
            $args['body'] = json_encode($data);
        }
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            $this->log_error('API Request Error', $response->get_error_message());
            return $response;
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        // Hata kontrolü
        if ($status_code < 200 || $status_code >= 300) {
            $error_message = "HTTP $status_code: $body";
            $this->log_error('API Response Error', $error_message);
            return new WP_Error('api_error', $error_message);
        }
        
        $decoded = json_decode($body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $error_message = 'JSON decode error: ' . json_last_error_msg();
            $this->log_error('JSON Error', $error_message);
            return new WP_Error('json_error', $error_message);
        }
        
        return $decoded;
    }
    
    /**
     * Hata logu
     */
    private function log_error($title, $message) {
        error_log("TWS API Error - $title: $message");
    }
    
    /**
     * Rate limiting kontrolü
     */
    private function check_rate_limit() {
        $limit_key = 'tws_api_rate_limit';
        $requests = get_transient($limit_key);
        
        if ($requests === false) {
            set_transient($limit_key, 1, 60); // 1 dakika
            return true;
        }
        
        if ($requests >= 100) { // Dakikada max 100 istek
            return false;
        }
        
        set_transient($limit_key, $requests + 1, 60);
        return true;
    }
}
