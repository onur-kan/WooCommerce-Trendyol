<?php
/**
 * Ürün Senkronizasyon Sınıfı
 */

if (!defined('ABSPATH')) {
    exit;
}

class TWS_Product_Sync {
    
    private $api;
    
    public function __construct() {
        $this->api = new TWS_API();
    }
    
    /**
     * Tüm ürünleri senkronize et
     */
    public function sync_all_products() {
        $page = 0;
        $size = 50;
        $synced = 0;
        $errors = 0;
        
        do {
            $result = $this->api->get_products($page, $size);
            
            if (!$result['success']) {
                break;
            }
            
            $products = isset($result['data']['content']) ? $result['data']['content'] : array();
            
            foreach ($products as $product) {
                if ($this->import_product($product)) {
                    $synced++;
                } else {
                    $errors++;
                }
            }
            
            $page++;
            
        } while (!empty($products));
        
        return array(
            'success' => true,
            'synced' => $synced,
            'errors' => $errors,
            'message' => sprintf('%d ürün senkronize edildi, %d hata oluştu.', $synced, $errors)
        );
    }
    
    /**
     * Tek bir ürünü içe aktar
     */
    public function import_product($trendyol_product) {
        try {
            // Ürün zaten var mı kontrol et
            $existing_product_id = $this->get_product_by_barcode($trendyol_product['barcode']);
            
            if ($existing_product_id) {
                // Mevcut ürünü güncelle
                return $this->update_existing_product($existing_product_id, $trendyol_product);
            } else {
                // Yeni ürün oluştur
                return $this->create_new_product($trendyol_product);
            }
            
        } catch (Exception $e) {
            $this->log_sync_error($trendyol_product['barcode'], $e->getMessage());
            return false;
        }
    }
    
    /**
     * Barkoda göre ürün bul
     */
    private function get_product_by_barcode($barcode) {
        global $wpdb;
        
        $product_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_sku' AND meta_value = %s",
            $barcode
        ));
        
        return $product_id ? intval($product_id) : false;
    }
    
    /**
     * Yeni ürün oluştur
     */
    private function create_new_product($trendyol_product) {
        $product = new WC_Product_Simple();
        
        // Temel bilgiler
        $product->set_name($trendyol_product['title']);
        $product->set_sku($trendyol_product['barcode']);
        $product->set_description($trendyol_product['description'] ?? '');
        $product->set_short_description($trendyol_product['description'] ?? '');
        
        // Fiyat
        if (isset($trendyol_product['salePrice'])) {
            $product->set_regular_price($trendyol_product['salePrice']);
            $product->set_price($trendyol_product['salePrice']);
        }
        
        // Stok
        if (isset($trendyol_product['quantity'])) {
            $product->set_stock_quantity($trendyol_product['quantity']);
            $product->set_manage_stock(true);
            $product->set_stock_status($trendyol_product['quantity'] > 0 ? 'instock' : 'outofstock');
        }
        
        // Görseller
        if (!empty($trendyol_product['images'])) {
            $this->set_product_images($product, $trendyol_product['images']);
        }
        
        // Kaydet
        $product_id = $product->save();
        
        // Trendyol meta bilgileri
        update_post_meta($product_id, '_trendyol_id', $trendyol_product['id']);
        update_post_meta($product_id, '_trendyol_barcode', $trendyol_product['barcode']);
        update_post_meta($product_id, '_trendyol_last_sync', current_time('mysql'));
        
        // Log
        $this->log_sync_success($product_id, $trendyol_product['barcode'], 'created');
        
        return $product_id;
    }
    
    /**
     * Mevcut ürünü güncelle
     */
    private function update_existing_product($product_id, $trendyol_product) {
        $product = wc_get_product($product_id);
        
        if (!$product) {
            return false;
        }
        
        $settings = get_option('tws_settings', array());
        
        // Fiyat güncelle
        if (!empty($settings['sync_price']) && isset($trendyol_product['salePrice'])) {
            $product->set_regular_price($trendyol_product['salePrice']);
            $product->set_price($trendyol_product['salePrice']);
        }
        
        // Stok güncelle
        if (!empty($settings['sync_stock']) && isset($trendyol_product['quantity'])) {
            $product->set_stock_quantity($trendyol_product['quantity']);
            $product->set_stock_status($trendyol_product['quantity'] > 0 ? 'instock' : 'outofstock');
        }
        
        $product->save();
        
        // Son senkronizasyon zamanı
        update_post_meta($product_id, '_trendyol_last_sync', current_time('mysql'));
        
        // Log
        $this->log_sync_success($product_id, $trendyol_product['barcode'], 'updated');
        
        return $product_id;
    }
    
    /**
     * Ürün görsellerini ayarla
     */
    private function set_product_images($product, $images) {
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        $image_ids = array();
        
        foreach ($images as $index => $image_url) {
            $image_id = $this->upload_image_from_url($image_url);
            
            if ($image_id) {
                $image_ids[] = $image_id;
                
                // İlk görsel ana görsel olsun
                if ($index === 0) {
                    $product->set_image_id($image_id);
                }
            }
        }
        
        // Galeri görselleri
        if (count($image_ids) > 1) {
            $product->set_gallery_image_ids(array_slice($image_ids, 1));
        }
    }
    
    /**
     * URL'den görsel yükle
     */
    private function upload_image_from_url($url) {
        $tmp = download_url($url);
        
        if (is_wp_error($tmp)) {
            return false;
        }
        
        $file_array = array(
            'name' => basename($url),
            'tmp_name' => $tmp
        );
        
        $id = media_handle_sideload($file_array, 0);
        
        if (is_wp_error($id)) {
            @unlink($file_array['tmp_name']);
            return false;
        }
        
        return $id;
    }
    
    /**
     * WooCommerce'den Trendyol'a stok güncelle
     */
    public function update_trendyol_stock($product_id) {
        $product = wc_get_product($product_id);
        
        if (!$product) {
            return false;
        }
        
        $barcode = $product->get_sku();
        $quantity = $product->get_stock_quantity();
        
        if (empty($barcode)) {
            return false;
        }
        
        $items = array(
            array(
                'barcode' => $barcode,
                'quantity' => $quantity ? $quantity : 0,
                'salePrice' => $product->get_price(),
                'listPrice' => $product->get_regular_price()
            )
        );
        
        $result = $this->api->update_stock($items);
        
        if ($result['success']) {
            update_post_meta($product_id, '_trendyol_last_stock_update', current_time('mysql'));
            return true;
        }
        
        return false;
    }
    
    /**
     * Başarılı senkronizasyon logu
     */
    private function log_sync_success($product_id, $barcode, $type) {
        global $wpdb;
        
        $wpdb->insert(
            $wpdb->prefix . 'tws_sync_log',
            array(
                'product_id' => $product_id,
                'trendyol_id' => $barcode,
                'sync_type' => $type,
                'status' => 'success',
                'message' => ucfirst($type) . ' successfully',
                'created_at' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s')
        );
    }
    
    /**
     * Hata logu
     */
    private function log_sync_error($barcode, $error_message) {
        global $wpdb;
        
        $wpdb->insert(
            $wpdb->prefix . 'tws_sync_log',
            array(
                'product_id' => 0,
                'trendyol_id' => $barcode,
                'sync_type' => 'sync',
                'status' => 'error',
                'message' => $error_message,
                'created_at' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s')
        );
    }
}
