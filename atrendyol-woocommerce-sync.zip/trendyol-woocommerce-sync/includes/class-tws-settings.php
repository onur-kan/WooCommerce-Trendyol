<?php
/**
 * Ayarlar Sınıfı
 */

if (!defined('ABSPATH')) {
    exit;
}

class TWS_Settings {
    
    public static function save_settings($data) {
        $settings = array(
            'api_key' => sanitize_text_field($data['api_key'] ?? ''),
            'api_secret' => sanitize_text_field($data['api_secret'] ?? ''),
            'supplier_id' => sanitize_text_field($data['supplier_id'] ?? ''),
            'auto_sync_enabled' => isset($data['auto_sync_enabled']) ? true : false,
            'sync_interval' => sanitize_text_field($data['sync_interval'] ?? 'hourly'),
            'sync_stock' => isset($data['sync_stock']) ? true : false,
            'sync_price' => isset($data['sync_price']) ? true : false,
            'sync_orders' => isset($data['sync_orders']) ? true : false,
        );
        
        update_option('tws_settings', $settings);
        
        return true;
    }
    
    public static function get_settings() {
        return get_option('tws_settings', array(
            'api_key' => '',
            'api_secret' => '',
            'supplier_id' => '',
            'auto_sync_enabled' => false,
            'sync_interval' => 'hourly',
            'sync_stock' => true,
            'sync_price' => true,
            'sync_orders' => false,
        ));
    }
}
