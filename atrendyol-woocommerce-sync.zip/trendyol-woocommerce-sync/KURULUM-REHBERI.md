# 🚀 TRENDYOL WOOCOMMERCE SYNC - KURULUM REHBERİ

## 📦 ADIM 1: WordPress'e Yükleme

### Yöntem 1: Admin Panel Üzerinden (Önerilen)
1. WordPress admin paneline giriş yapın
2. **Eklentiler → Yeni Ekle** menüsüne gidin
3. **Eklenti Yükle** butonuna tıklayın
4. `trendyol-woocommerce-sync.zip` dosyasını seçin
5. **Şimdi Yükle** butonuna tıklayın
6. Yükleme tamamlandıktan sonra **Eklentiyi Etkinleştir** butonuna tıklayın

### Yöntem 2: FTP ile Manuel Yükleme
1. ZIP dosyasını bilgisayarınızda açın
2. `trendyol-woocommerce-sync` klasörünü FTP ile `/wp-content/plugins/` klasörüne yükleyin
3. WordPress admin panelde **Eklentiler** sayfasına gidin
4. **Trendyol WooCommerce Sync** eklentisini etkinleştirin

---

## 🔑 ADIM 2: API Bilgilerini Alma

1. Tarayıcınızda [Trendyol Seller Portal](https://partner.trendyol.com/)'ı açın
2. Satıcı hesabınızla giriş yapın
3. Sol menüden **Entegrasyon** bölümüne gidin
4. **API Ayarları** veya **Entegrasyon Ayarları** seçeneğine tıklayın
5. Aşağıdaki 3 bilgiyi not alın:
   - **API Key** (Uzun bir alfanumerik kod)
   - **API Secret** (Şifre benzeri kod)
   - **Supplier ID** (Satıcı ID numaranız)

> ⚠️ **Önemli:** Bu bilgileri kimseyle paylaşmayın! API anahtarlarınız hesabınıza tam erişim sağlar.

---

## ⚙️ ADIM 3: Eklentiyi Yapılandırma

1. WordPress admin panelde **Trendyol Sync → Ayarlar** menüsüne gidin
2. API bilgilerinizi ilgili alanlara girin:
   ```
   API Key: [Trendyol'dan aldığınız API Key]
   API Secret: [Trendyol'dan aldığınız API Secret]
   Supplier ID: [Trendyol'dan aldığınız Supplier ID]
   ```
3. **Otomatik Senkronizasyon** seçeneklerini ayarlayın:
   - ✅ Otomatik senkronizasyonu aktifleştir
   - Senkronizasyon sıklığı: **Saatte bir** (Önerilen)
   - ✅ Stok senkronizasyonu
   - ✅ Fiyat senkronizasyonu
4. **Ayarları Kaydet** butonuna tıklayın

---

## 🔄 ADIM 4: İlk Senkronizasyon

1. **Trendyol Sync → Dashboard** menüsüne gidin
2. **Bağlantıyı Test Et** butonuna tıklayın
   - ✅ "Bağlantı başarılı!" mesajını görmelisiniz
   - ❌ Hata alırsanız, API bilgilerinizi kontrol edin
3. **Şimdi Senkronize Et** butonuna tıklayın
4. İşlemin tamamlanmasını bekleyin (ürün sayısına göre 1-10 dakika sürebilir)
5. İşlem tamamlandığında başarı mesajı görürsünüz

---

## ✅ ADIM 5: Kontrol ve Doğrulama

### Ürünleri Kontrol Edin
1. **Ürünler → Tüm Ürünler** menüsüne gidin
2. Trendyol'dan gelen ürünleri görmelisiniz
3. Birkaç ürünü açıp kontrol edin:
   - ✅ Ürün başlığı doğru mu?
   - ✅ Fiyat bilgisi var mı?
   - ✅ Stok miktarı doğru mu?
   - ✅ Görseller yüklendi mi?

### Logları İnceleyin
1. **Trendyol Sync → Loglar** menüsüne gidin
2. Başarılı ve başarısız işlemleri görüntüleyin
3. Hata varsa, hata mesajlarını okuyun

---

## 🎯 Kullanım Senaryoları

### Senaryo 1: Yeni Ürün Trendyol'a Eklendi
- Otomatik senkronizasyon aktifse: Belirlediğiniz süre içinde (ör. 1 saat) otomatik olarak WooCommerce'e eklenecek
- Manuel senkronizasyon: Dashboard'dan "Şimdi Senkronize Et" butonuna tıklayın

### Senaryo 2: WooCommerce'de Stok Değişti
- Eklenti otomatik olarak Trendyol'a güncelleyecek (sync_stock aktifse)
- Manuel güncelleme için ürün sayfasında "Kaydet" butonuna tıklayın

### Senaryo 3: Fiyat Değişikliği
- Fiyat değişiklikleri otomatik olarak senkronize edilir
- Hem Trendyol → WooCommerce hem de WooCommerce → Trendyol yönünde

---

## ⚠️ SORUN GİDERME

### Problem: Beyaz Ekran Hatası
**Çözüm:**
1. FTP ile `/wp-content/plugins/trendyol-woocommerce-sync/` klasörünü silin
2. Eklentiyi tekrar yükleyin
3. PHP versiyonunun 7.4 veya üzeri olduğunu kontrol edin
4. `wp-content/debug.log` dosyasına bakın

### Problem: API Bağlantı Hatası
**Çözüm:**
1. API bilgilerini tekrar kontrol edin
2. Trendyol Seller Portal'da API erişiminin aktif olduğundan emin olun
3. Hosting sağlayıcınızın cURL'e izin verdiğini kontrol edin
4. Firewall ayarlarını kontrol edin (Trendyol API'sine erişim olmalı)

### Problem: Ürünler Senkronize Olmuyor
**Çözüm:**
1. **Loglar** sayfasından hata mesajlarını inceleyin
2. Trendyol'da ürünlerin "Aktif" durumda olduğunu kontrol edin
3. WooCommerce'de stok yönetiminin aktif olduğunu kontrol edin
4. PHP memory limit'i artırın: `wp-config.php` içine ekleyin:
   ```php
   define('WP_MEMORY_LIMIT', '256M');
   ```

### Problem: Görseller Yüklenmiyor
**Çözüm:**
1. `/wp-content/uploads/` klasörünün yazılabilir olduğunu kontrol edin (chmod 755)
2. PHP `allow_url_fopen` ayarının aktif olduğunu kontrol edin
3. Sunucunuzun dış URL'lerden dosya indirmeye izin verdiğini kontrol edin

---

## 🔒 GÜVENLİK ÖNERİLERİ

1. ✅ API bilgilerinizi asla kimseyle paylaşmayın
2. ✅ WordPress ve eklentileri güncel tutun
3. ✅ Güçlü admin şifresi kullanın
4. ✅ Düzenli yedek alın
5. ✅ SSL sertifikası kullanın (HTTPS)

---

## 📊 PERFORMANS İPUÇLARI

1. **Büyük ürün katalogları için:**
   - Otomatik senkronizasyon aralığını "Günde bir kez" yapın
   - Sadece gerekli verileri senkronize edin (stok/fiyat)

2. **Hız optimizasyonu:**
   - WordPress cache eklentisi kullanın (WP Super Cache, W3 Total Cache)
   - PHP versiyonunu 8.0+ yapın
   - Database'i optimize edin

3. **Hosting önerileri:**
   - En az 2GB RAM
   - SSD disk
   - PHP 8.0+
   - cURL aktif

---

## 📞 DESTEK

Sorun yaşıyorsanız:

1. **Önce kontrol edin:**
   - Loglar sayfasını inceleyin
   - API bilgilerinin doğru olduğundan emin olun
   - WooCommerce'in aktif ve güncel olduğunu kontrol edin

2. **Hala sorun varsa:**
   - GitHub Issues: [github.com/yourusername/trendyol-woocommerce-sync](https://github.com/yourusername/trendyol-woocommerce-sync)
   - E-posta: support@yourwebsite.com

---

## ✨ İLERİ SEVİYE ÖZELLİKLER (Yakında)

- [ ] Sipariş senkronizasyonu
- [ ] Varyant desteği (Beden/Renk)
- [ ] Kategori otomatik eşleştirme
- [ ] Excel içe/dışa aktarma
- [ ] N11 ve HepsiBurada entegrasyonu
- [ ] Toplu işlemler
- [ ] E-posta bildirimleri

---

🎉 **Başarılar dileriz!** Sorularınız için her zaman buradayız.