/**
 * Trendyol WooCommerce Sync - Admin JavaScript
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        
        // AJAX helper fonksiyonu
        function twsAjaxRequest(action, data, successCallback, errorCallback) {
            data = data || {};
            data.action = action;
            data.nonce = twsAjax.nonce;
            
            $.ajax({
                url: twsAjax.ajaxurl,
                type: 'POST',
                data: data,
                success: function(response) {
                    if (response.success && successCallback) {
                        successCallback(response);
                    } else if (!response.success && errorCallback) {
                        errorCallback(response);
                    }
                },
                error: function(xhr, status, error) {
                    if (errorCallback) {
                        errorCallback({
                            success: false,
                            message: 'AJAX hatası: ' + error
                        });
                    }
                }
            });
        }
        
        // Bildirim göster
        function showNotice(message, type) {
            type = type || 'success';
            var noticeClass = 'notice notice-' + type + ' is-dismissible';
            var notice = $('<div class="' + noticeClass + '"><p>' + message + '</p></div>');
            
            $('.wrap > h1').after(notice);
            
            setTimeout(function() {
                notice.fadeOut(function() {
                    $(this).remove();
                });
            }, 5000);
        }
        
        // Loading durumunu göster/gizle
        function setButtonLoading($button, loading, originalText) {
            if (loading) {
                $button.data('original-text', $button.html());
                $button.prop('disabled', true)
                       .html('<span class="tws-loading"></span> Yükleniyor...');
            } else {
                var text = originalText || $button.data('original-text');
                $button.prop('disabled', false).html(text);
            }
        }
        
        // Console log helper
        function log(message, data) {
            if (typeof console !== 'undefined' && console.log) {
                console.log('[TWS] ' + message, data || '');
            }
        }
        
        log('Trendyol Sync Admin JS loaded');
    });
    
})(jQuery);
