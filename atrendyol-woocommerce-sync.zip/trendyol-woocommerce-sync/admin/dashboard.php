<?php
/**
 * Dashboard Sayfası
 */

if (!defined('ABSPATH')) {
    exit;
}

// İstatistikleri al
global $wpdb;

$total_synced = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}tws_sync_log WHERE status = 'success'");
$total_errors = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}tws_sync_log WHERE status = 'error'");
$last_sync = $wpdb->get_var("SELECT MAX(created_at) FROM {$wpdb->prefix}tws_sync_log");

$settings = get_option('tws_settings', array());
$is_configured = !empty($settings['api_key']) && !empty($settings['api_secret']) && !empty($settings['supplier_id']);
?>

<div class="wrap tws-dashboard">
    <h1>🔄 Trendyol WooCommerce Sync</h1>
    <p class="description">Trendyol ile WooCommerce arasında otomatik ürün senkronizasyonu</p>
    
    <?php if (!$is_configured): ?>
    <div class="notice notice-warning">
        <p><strong>⚠️ Yapılandırma Gerekli:</strong> Eklentiyi kullanabilmek için önce <a href="<?php echo admin_url('admin.php?page=trendyol-sync-settings'); ?>">Ayarlar</a> sayfasından API bilgilerinizi girmeniz gerekiyor.</p>
    </div>
    <?php endif; ?>
    
    <div class="tws-stats-grid">
        <!-- İstatistik Kartları -->
        <div class="tws-stat-card">
            <div class="tws-stat-icon">✅</div>
            <div class="tws-stat-content">
                <div class="tws-stat-value"><?php echo number_format($total_synced); ?></div>
                <div class="tws-stat-label">Başarılı Senkronizasyon</div>
            </div>
        </div>
        
        <div class="tws-stat-card error">
            <div class="tws-stat-icon">❌</div>
            <div class="tws-stat-content">
                <div class="tws-stat-value"><?php echo number_format($total_errors); ?></div>
                <div class="tws-stat-label">Hata</div>
            </div>
        </div>
        
        <div class="tws-stat-card">
            <div class="tws-stat-icon">🕐</div>
            <div class="tws-stat-content">
                <div class="tws-stat-value">
                    <?php echo $last_sync ? human_time_diff(strtotime($last_sync), current_time('timestamp')) . ' önce' : 'Henüz yok'; ?>
                </div>
                <div class="tws-stat-label">Son Senkronizasyon</div>
            </div>
        </div>
        
        <div class="tws-stat-card">
            <div class="tws-stat-icon">📦</div>
            <div class="tws-stat-content">
                <div class="tws-stat-value"><?php echo wp_count_posts('product')->publish; ?></div>
                <div class="tws-stat-label">Toplam Ürün</div>
            </div>
        </div>
    </div>
    
    <!-- Hızlı İşlemler -->
    <div class="tws-quick-actions">
        <h2>⚡ Hızlı İşlemler</h2>
        
        <div class="tws-action-buttons">
            <?php if ($is_configured): ?>
            <button type="button" class="button button-primary button-large" id="tws-test-connection">
                <span class="dashicons dashicons-yes-alt"></span> Bağlantıyı Test Et
            </button>
            
            <button type="button" class="button button-primary button-large" id="tws-sync-now">
                <span class="dashicons dashicons-update"></span> Şimdi Senkronize Et
            </button>
            
            <a href="<?php echo admin_url('admin.php?page=trendyol-sync-products'); ?>" class="button button-large">
                <span class="dashicons dashicons-products"></span> Ürünleri Yönet
            </a>
            <?php else: ?>
            <a href="<?php echo admin_url('admin.php?page=trendyol-sync-settings'); ?>" class="button button-primary button-large">
                <span class="dashicons dashicons-admin-settings"></span> Ayarları Yapılandır
            </a>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Son İşlemler -->
    <div class="tws-recent-logs">
        <h2>📋 Son İşlemler</h2>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Tarih</th>
                    <th>Ürün ID</th>
                    <th>Trendyol ID</th>
                    <th>İşlem</th>
                    <th>Durum</th>
                    <th>Mesaj</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $recent_logs = $wpdb->get_results("
                    SELECT * FROM {$wpdb->prefix}tws_sync_log 
                    ORDER BY created_at DESC 
                    LIMIT 10
                ");
                
                if ($recent_logs):
                    foreach ($recent_logs as $log):
                ?>
                <tr>
                    <td><?php echo date('d.m.Y H:i', strtotime($log->created_at)); ?></td>
                    <td>
                        <?php if ($log->product_id > 0): ?>
                        <a href="<?php echo get_edit_post_link($log->product_id); ?>">#<?php echo $log->product_id; ?></a>
                        <?php else: ?>
                        -
                        <?php endif; ?>
                    </td>
                    <td><?php echo esc_html($log->trendyol_id); ?></td>
                    <td><?php echo esc_html($log->sync_type); ?></td>
                    <td>
                        <span class="tws-status tws-status-<?php echo esc_attr($log->status); ?>">
                            <?php echo $log->status === 'success' ? '✅ Başarılı' : '❌ Hata'; ?>
                        </span>
                    </td>
                    <td><?php echo esc_html($log->message); ?></td>
                </tr>
                <?php
                    endforeach;
                else:
                ?>
                <tr>
                    <td colspan="6" style="text-align: center; padding: 30px;">
                        Henüz senkronizasyon yapılmamış.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
        
        <?php if ($recent_logs): ?>
        <p style="text-align: right; margin-top: 10px;">
            <a href="<?php echo admin_url('admin.php?page=trendyol-sync-logs'); ?>" class="button">Tüm Logları Görüntüle</a>
        </p>
        <?php endif; ?>
    </div>
    
    <!-- Yardım -->
    <div class="tws-help-box">
        <h3>📚 Yardım & Dokümantasyon</h3>
        <ul>
            <li>🔑 <strong>API Bilgileri:</strong> Trendyol Seller Portal'dan API bilgilerinizi alabilirsiniz.</li>
            <li>🔄 <strong>Otomatik Senkronizasyon:</strong> Ayarlardan otomatik senkronizasyonu aktifleştirebilirsiniz.</li>
            <li>📦 <strong>Ürün İçe Aktarma:</strong> Trendyol'daki tüm ürünleriniz WooCommerce'e otomatik aktarılır.</li>
            <li>💰 <strong>Fiyat & Stok:</strong> Fiyat ve stok değişiklikleri otomatik olarak senkronize edilir.</li>
        </ul>
    </div>
</div>

<style>
.tws-dashboard {
    max-width: 1400px;
}

.tws-stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin: 30px 0;
}

.tws-stat-card {
    background: white;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 15px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.tws-stat-card.error {
    border-left: 4px solid #dc3232;
}

.tws-stat-icon {
    font-size: 32px;
}

.tws-stat-value {
    font-size: 28px;
    font-weight: bold;
    color: #2271b1;
}

.tws-stat-label {
    color: #666;
    font-size: 13px;
}

.tws-quick-actions {
    background: white;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    margin: 20px 0;
}

.tws-action-buttons {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-top: 15px;
}

.tws-recent-logs {
    background: white;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    margin: 20px 0;
}

.tws-status {
    padding: 4px 8px;
    border-radius: 3px;
    font-size: 12px;
    font-weight: 500;
}

.tws-status-success {
    background: #d4edda;
    color: #155724;
}

.tws-status-error {
    background: #f8d7da;
    color: #721c24;
}

.tws-help-box {
    background: #f0f6fc;
    border: 1px solid #c3dafe;
    border-radius: 8px;
    padding: 20px;
    margin: 20px 0;
}

.tws-help-box ul {
    list-style: none;
    padding: 0;
}

.tws-help-box li {
    padding: 8px 0;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Bağlantı testi
    $('#tws-test-connection').on('click', function() {
        var $btn = $(this);
        $btn.prop('disabled', true).text('Test ediliyor...');
        
        $.ajax({
            url: twsAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'tws_test_connection',
                nonce: twsAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('✅ ' + response.message);
                } else {
                    alert('❌ ' + response.message);
                }
            },
            error: function() {
                alert('❌ Bir hata oluştu.');
            },
            complete: function() {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-yes-alt"></span> Bağlantıyı Test Et');
            }
        });
    });
    
    // Senkronizasyon
    $('#tws-sync-now').on('click', function() {
        if (!confirm('Tüm ürünler Trendyol\'dan çekilecek. Bu işlem zaman alabilir. Devam etmek istiyor musunuz?')) {
            return;
        }
        
        var $btn = $(this);
        $btn.prop('disabled', true).text('Senkronize ediliyor...');
        
        $.ajax({
            url: twsAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'tws_sync_products',
                nonce: twsAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('✅ ' + response.message);
                    location.reload();
                } else {
                    alert('❌ ' + (response.message || 'Bir hata oluştu.'));
                }
            },
            error: function() {
                alert('❌ Bir hata oluştu.');
            },
            complete: function() {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-update"></span> Şimdi Senkronize Et');
            }
        });
    });
});
</script>
