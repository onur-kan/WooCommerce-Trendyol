<?php
/**
 * Ayarlar Sayfası
 */

if (!defined('ABSPATH')) {
    exit;
}

// Ayarları kaydet
if (isset($_POST['tws_save_settings'])) {
    check_admin_referer('tws_settings_nonce');
    
    TWS_Settings::save_settings($_POST);
    
    echo '<div class="notice notice-success is-dismissible"><p>✅ Ayarlar kaydedildi.</p></div>';
}

$settings = TWS_Settings::get_settings();
?>

<div class="wrap">
    <h1>⚙️ Trendyol Sync Ayarları</h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('tws_settings_nonce'); ?>
        
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="api_key">API Key</label>
                    </th>
                    <td>
                        <input type="text" 
                               id="api_key" 
                               name="api_key" 
                               value="<?php echo esc_attr($settings['api_key']); ?>" 
                               class="regular-text" 
                               placeholder="Trendyol API Key">
                        <p class="description">Trendyol Seller Portal'dan alabilirsiniz.</p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="api_secret">API Secret</label>
                    </th>
                    <td>
                        <input type="password" 
                               id="api_secret" 
                               name="api_secret" 
                               value="<?php echo esc_attr($settings['api_secret']); ?>" 
                               class="regular-text" 
                               placeholder="Trendyol API Secret">
                        <p class="description">API Key ile birlikte verilir.</p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="supplier_id">Supplier ID</label>
                    </th>
                    <td>
                        <input type="text" 
                               id="supplier_id" 
                               name="supplier_id" 
                               value="<?php echo esc_attr($settings['supplier_id']); ?>" 
                               class="regular-text" 
                               placeholder="Trendyol Supplier ID">
                        <p class="description">Satıcı ID numaranız.</p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">Otomatik Senkronizasyon</th>
                    <td>
                        <label>
                            <input type="checkbox" 
                                   name="auto_sync_enabled" 
                                   value="1" 
                                   <?php checked($settings['auto_sync_enabled'], true); ?>>
                            Otomatik senkronizasyonu aktifleştir
                        </label>
                        <p class="description">Arka planda otomatik olarak ürünleri senkronize eder.</p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="sync_interval">Senkronizasyon Sıklığı</label>
                    </th>
                    <td>
                        <select name="sync_interval" id="sync_interval">
                            <option value="hourly" <?php selected($settings['sync_interval'], 'hourly'); ?>>Saatte bir</option>
                            <option value="twicedaily" <?php selected($settings['sync_interval'], 'twicedaily'); ?>>Günde iki kez</option>
                            <option value="daily" <?php selected($settings['sync_interval'], 'daily'); ?>>Günde bir kez</option>
                        </select>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">Senkronizasyon Seçenekleri</th>
                    <td>
                        <label>
                            <input type="checkbox" 
                                   name="sync_stock" 
                                   value="1" 
                                   <?php checked($settings['sync_stock'], true); ?>>
                            Stok senkronizasyonu
                        </label>
                        <br>
                        <label>
                            <input type="checkbox" 
                                   name="sync_price" 
                                   value="1" 
                                   <?php checked($settings['sync_price'], true); ?>>
                            Fiyat senkronizasyonu
                        </label>
                        <br>
                        <label>
                            <input type="checkbox" 
                                   name="sync_orders" 
                                   value="1" 
                                   <?php checked($settings['sync_orders'], true); ?>>
                            Sipariş senkronizasyonu (yakında)
                        </label>
                    </td>
                </tr>
            </tbody>
        </table>
        
        <p class="submit">
            <button type="submit" name="tws_save_settings" class="button button-primary button-large">
                💾 Ayarları Kaydet
            </button>
        </p>
    </form>
    
    <hr>
    
    <div class="tws-api-info">
        <h2>🔑 API Bilgilerini Nereden Alabilirim?</h2>
        <ol>
            <li><a href="https://partner.trendyol.com/" target="_blank">Trendyol Seller Portal</a>'a giriş yapın</li>
            <li><strong>Entegrasyon → API Ayarları</strong> menüsüne gidin</li>
            <li><strong>API Key</strong>, <strong>API Secret</strong> ve <strong>Supplier ID</strong> bilgilerinizi kopyalayın</li>
            <li>Bu bilgileri yukarıdaki forma yapıştırın</li>
        </ol>
    </div>
</div>

<style>
.tws-api-info {
    background: #f0f6fc;
    border: 1px solid #c3dafe;
    border-radius: 8px;
    padding: 20px;
    margin-top: 30px;
}

.tws-api-info ol {
    margin-left: 20px;
}

.tws-api-info li {
    margin: 10px 0;
}
</style>
