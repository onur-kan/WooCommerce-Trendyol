<?php
/**
 * Ürünler Sayfası
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1>📦 Ürün Senkronizasyonu</h1>
    <p class="description">Trendyol ürünlerinizi WooCommerce ile senkronize edin.</p>
    
    <div class="tws-products-actions" style="background: white; padding: 20px; border: 1px solid #ddd; border-radius: 8px; margin: 20px 0;">
        <h2>Senkronizasyon İşlemleri</h2>
        <p>
            <button type="button" class="button button-primary button-large" id="tws-sync-products">
                <span class="dashicons dashicons-update"></span> Tüm Ürünleri Senkronize Et
            </button>
        </p>
        <p class="description">Bu işlem, Trendyol'daki tüm ürünlerinizi WooCommerce'e aktaracaktır.</p>
    </div>
    
    <div style="background: #f0f6fc; padding: 20px; border: 1px solid #c3dafe; border-radius: 8px;">
        <h3>📋 Özellikler</h3>
        <ul>
            <li>✅ Trendyol'dan otomatik ürün içe aktarma</li>
            <li>✅ Ürün görselleri otomatik indirilir</li>
            <li>✅ Stok ve fiyat bilgileri aktarılır</li>
            <li>✅ Mevcut ürünler güncellenir</li>
        </ul>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    $('#tws-sync-products').on('click', function() {
        if (!confirm('Bu işlem uzun sürebilir. Devam etmek istiyor musunuz?')) {
            return;
        }
        
        var $btn = $(this);
        $btn.prop('disabled', true).text('Senkronize ediliyor...');
        
        $.ajax({
            url: twsAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'tws_sync_products',
                nonce: twsAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('✅ ' + response.message);
                } else {
                    alert('❌ ' + (response.message || 'Bir hata oluştu.'));
                }
            },
            complete: function() {
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-update"></span> Tüm Ürünleri Senkronize Et');
            }
        });
    });
});
</script>
