<?php
/**
 * Loglar Sayfası
 */

if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;

// Sayfalama
$per_page = 50;
$current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$offset = ($current_page - 1) * $per_page;

$total_logs = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}tws_sync_log");
$total_pages = ceil($total_logs / $per_page);

$logs = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}tws_sync_log ORDER BY created_at DESC LIMIT %d OFFSET %d",
    $per_page,
    $offset
));
?>

<div class="wrap">
    <h1>📋 Senkronizasyon Logları</h1>
    <p class="description">Tüm senkronizasyon işlemlerinin geçmişi.</p>
    
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>Tarih</th>
                <th>Ürün ID</th>
                <th>Trendyol ID</th>
                <th>İşlem Tipi</th>
                <th>Durum</th>
                <th>Mesaj</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($logs): ?>
                <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?php echo date('d.m.Y H:i:s', strtotime($log->created_at)); ?></td>
                    <td>
                        <?php if ($log->product_id > 0): ?>
                        <a href="<?php echo get_edit_post_link($log->product_id); ?>">#<?php echo $log->product_id; ?></a>
                        <?php else: ?>
                        -
                        <?php endif; ?>
                    </td>
                    <td><?php echo esc_html($log->trendyol_id); ?></td>
                    <td><?php echo esc_html($log->sync_type); ?></td>
                    <td>
                        <span style="padding: 4px 8px; border-radius: 3px; font-size: 12px; <?php echo $log->status === 'success' ? 'background: #d4edda; color: #155724;' : 'background: #f8d7da; color: #721c24;'; ?>">
                            <?php echo $log->status === 'success' ? '✅ Başarılı' : '❌ Hata'; ?>
                        </span>
                    </td>
                    <td><?php echo esc_html($log->message); ?></td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
            <tr>
                <td colspan="6" style="text-align: center; padding: 30px;">
                    Henüz log kaydı bulunmuyor.
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <?php if ($total_pages > 1): ?>
    <div class="tablenav">
        <div class="tablenav-pages">
            <?php
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => '&laquo;',
                'next_text' => '&raquo;',
                'total' => $total_pages,
                'current' => $current_page
            ));
            ?>
        </div>
    </div>
    <?php endif; ?>
</div>
