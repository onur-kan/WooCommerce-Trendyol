<?php
/**
 * Kategoriler Sayfası
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1>🏷️ Kategori Eşleştirme</h1>
    <p class="description">WooCommerce kategorilerini Trendyol kategorileri ile eşleştirin.</p>
    
    <div style="background: #fff3cd; border: 1px solid #ffc107; padding: 15px; border-radius: 8px; margin: 20px 0;">
        <p><strong>ℹ️ Bilgi:</strong> Bu özellik geliştirilme aşamasındadır.</p>
    </div>
</div>
