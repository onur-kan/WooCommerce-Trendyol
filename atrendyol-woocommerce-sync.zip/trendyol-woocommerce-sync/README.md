# Trendyol WooCommerce Sync

🔄 Trendyol ile WooCommerce arasında otomatik ürün, stok, fiyat ve sipariş senkronizasyonu.

## 📋 Özellikler

✅ **Ürün Senkronizasyonu**
- Trendyol'dan otomatik ürün içe aktarma
- Ürün görselleri otomatik indirilir
- Stok ve fiyat bilgileri aktarılır
- Mevcut ürünler güncellenir

✅ **Otomatik Senkronizasyon**
- Saatlik, günlük veya özel aralıklarla otomatik sync
- Stok değişikliklerini otomatik güncelleme
- Fiyat değişikliklerini otomatik güncelleme

✅ **Log ve Raporlama**
- Detaylı işlem logları
- Başarı ve hata takibi
- Dashboard üzerinden anlık istatistikler

## 🚀 Kurulum

1. ZIP dosyasını indirin
2. WordPress Admin Panel → Eklentiler → Yeni Ekle → Eklenti Yükle
3. ZIP dosyasını seçin ve yükleyin
4. Eklentiyi aktifleştirin
5. Trendyol Sync → Ayarlar menüsünden API bilgilerinizi girin

## 🔑 API Bilgilerini Alma

1. [Trendyol Seller Portal](https://partner.trendyol.com/)'a giriş yapın
2. **Entegrasyon → API Ayarları** menüsüne gidin
3. **API Key**, **API Secret** ve **Supplier ID** bilgilerinizi kopyalayın
4. WordPress Admin'de **Trendyol Sync → Ayarlar** sayfasına bu bilgileri girin

## 📚 Kullanım

### İlk Kurulum
1. API bilgilerinizi girin
2. "Bağlantıyı Test Et" butonuna tıklayın
3. Bağlantı başarılı olursa "Şimdi Senkronize Et" butonuna tıklayın
4. İlk senkronizasyon tamamlanana kadar bekleyin

### Otomatik Senkronizasyon
1. Ayarlar sayfasından "Otomatik Senkronizasyon" seçeneğini aktifleştirin
2. Senkronizasyon sıklığını seçin (Saatlik, Günde 2, Günlük)
3. Hangi verilerin senkronize edileceğini seçin (Stok, Fiyat)

## 📦 Sistem Gereksinimleri

- WordPress 5.8 veya üzeri
- WooCommerce 5.0 veya üzeri
- PHP 7.4 veya üzeri
- cURL aktif olmalı

## 🔧 Sorun Giderme

### Beyaz Ekran Hatası
- PHP hata loglarını kontrol edin (`wp-content/debug.log`)
- PHP memory limit'i artırın (`wp-config.php` içinde: `define('WP_MEMORY_LIMIT', '256M');`)

### API Bağlantı Hatası
- API bilgilerinizi kontrol edin
- Trendyol Seller Portal'da API erişiminin aktif olduğundan emin olun
- Sunucu firewall ayarlarını kontrol edin

### Ürünler Senkronize Olmuyor
- "Loglar" sayfasından hata mesajlarını kontrol edin
- Trendyol'da ürünlerin aktif olduğundan emin olun
- WooCommerce stok yönetiminin aktif olduğunu kontrol edin

## 📞 Destek

Sorunlarınız için:
- GitHub Issues: [github.com/yourusername/trendyol-woocommerce-sync](https://github.com/yourusername/trendyol-woocommerce-sync)
- E-posta: support@yourwebsite.com

## 📄 Lisans

GPL v2 veya üzeri

## 🎯 Gelecek Özellikler (Yakında)

- [ ] Sipariş senkronizasyonu
- [ ] Varyant desteği (Beden, Renk)
- [ ] Kategori eşleştirme
- [ ] Toplu işlemler
- [ ] Excel içe/dışa aktarma
- [ ] N11 ve HepsiBurada entegrasyonu

## 👨‍💻 Geliştirici

Developed by [Your Name](https://yourwebsite.com)

---

⭐ Beğendiyseniz yıldız vermeyi unutmayın!
