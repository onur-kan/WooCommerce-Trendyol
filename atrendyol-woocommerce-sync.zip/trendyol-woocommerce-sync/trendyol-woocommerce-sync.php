<?php
/**
 * Plugin Name: Trendyol WooCommerce Sync
 * Plugin URI: https://github.com/yourusername/trendyol-woocommerce-sync
 * Description: Trendyol ile WooCommerce arasında ürün, stok, fiyat ve sipariş senkronizasyonu sağlar
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: trendyol-woocommerce-sync
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 8.0
 */

// Doğrudan erişimi engelle
if (!defined('ABSPATH')) {
    exit;
}

// Eklenti sabitlerini tanımla
define('TWS_VERSION', '1.0.0');
define('TWS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TWS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('TWS_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Ana eklenti sınıfı
 */
class Trendyol_WooCommerce_Sync {
    
    /**
     * Singleton instance
     */
    private static $instance = null;
    
    /**
     * Singleton pattern
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // WooCommerce yüklü mü kontrol et
        add_action('plugins_loaded', array($this, 'check_dependencies'));
        
        // Eklenti aktifleştirildiğinde
        register_activation_hook(__FILE__, array($this, 'activate'));
        
        // Eklenti devre dışı bırakıldığında
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Admin sayfaları ve menüleri
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // AJAX işlemleri
        add_action('wp_ajax_tws_test_connection', array($this, 'ajax_test_connection'));
        add_action('wp_ajax_tws_sync_products', array($this, 'ajax_sync_products'));
        add_action('wp_ajax_tws_get_categories', array($this, 'ajax_get_categories'));
    }
    
    /**
     * WooCommerce bağımlılığını kontrol et
     */
    public function check_dependencies() {
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
            deactivate_plugins(plugin_basename(__FILE__));
            return;
        }
        
        // Gerekli dosyaları yükle
        $this->load_dependencies();
    }
    
    /**
     * Gerekli dosyaları yükle
     */
    private function load_dependencies() {
        require_once TWS_PLUGIN_DIR . 'includes/class-tws-api.php';
        require_once TWS_PLUGIN_DIR . 'includes/class-tws-product-sync.php';
        require_once TWS_PLUGIN_DIR . 'includes/class-tws-settings.php';
    }
    
    /**
     * WooCommerce eksik uyarısı
     */
    public function woocommerce_missing_notice() {
        ?>
        <div class="notice notice-error">
            <p><strong>Trendyol WooCommerce Sync:</strong> Bu eklenti çalışmak için WooCommerce gerektirir. Lütfen önce WooCommerce'i yükleyin ve aktifleştirin.</p>
        </div>
        <?php
    }
    
    /**
     * Eklenti aktifleştirme
     */
    public function activate() {
        // Veritabanı tablolarını oluştur
        $this->create_tables();
        
        // Varsayılan ayarları oluştur
        $default_settings = array(
            'api_key' => '',
            'api_secret' => '',
            'supplier_id' => '',
            'auto_sync_enabled' => false,
            'sync_interval' => 'hourly',
            'sync_stock' => true,
            'sync_price' => true,
            'sync_orders' => false,
        );
        
        add_option('tws_settings', $default_settings);
        
        // Zamanlanmış görevleri ayarla
        if (!wp_next_scheduled('tws_sync_cron')) {
            wp_schedule_event(time(), 'hourly', 'tws_sync_cron');
        }
    }
    
    /**
     * Eklenti devre dışı bırakma
     */
    public function deactivate() {
        // Zamanlanmış görevleri temizle
        wp_clear_scheduled_hook('tws_sync_cron');
    }
    
    /**
     * Veritabanı tablolarını oluştur
     */
    private function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        // Senkronizasyon log tablosu
        $table_name = $wpdb->prefix . 'tws_sync_log';
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            product_id bigint(20) NOT NULL,
            trendyol_id varchar(100),
            sync_type varchar(50) NOT NULL,
            status varchar(20) NOT NULL,
            message text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY product_id (product_id),
            KEY trendyol_id (trendyol_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Kategori eşleştirme tablosu
        $table_name = $wpdb->prefix . 'tws_category_mapping';
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            woo_category_id bigint(20) NOT NULL,
            trendyol_category_id bigint(20) NOT NULL,
            category_name varchar(255),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY woo_category_id (woo_category_id)
        ) $charset_collate;";
        
        dbDelta($sql);
    }
    
    /**
     * Admin menüsü ekle
     */
    public function add_admin_menu() {
        add_menu_page(
            'Trendyol Sync',
            'Trendyol Sync',
            'manage_woocommerce',
            'trendyol-sync',
            array($this, 'display_dashboard'),
            'dashicons-update',
            56
        );
        
        add_submenu_page(
            'trendyol-sync',
            'Dashboard',
            'Dashboard',
            'manage_woocommerce',
            'trendyol-sync',
            array($this, 'display_dashboard')
        );
        
        add_submenu_page(
            'trendyol-sync',
            'Ürün Senkronizasyonu',
            'Ürünler',
            'manage_woocommerce',
            'trendyol-sync-products',
            array($this, 'display_products_page')
        );
        
        add_submenu_page(
            'trendyol-sync',
            'Kategori Eşleştirme',
            'Kategoriler',
            'manage_woocommerce',
            'trendyol-sync-categories',
            array($this, 'display_categories_page')
        );
        
        add_submenu_page(
            'trendyol-sync',
            'Ayarlar',
            'Ayarlar',
            'manage_woocommerce',
            'trendyol-sync-settings',
            array($this, 'display_settings_page')
        );
        
        add_submenu_page(
            'trendyol-sync',
            'Loglar',
            'Loglar',
            'manage_woocommerce',
            'trendyol-sync-logs',
            array($this, 'display_logs_page')
        );
    }
    
    /**
     * Admin CSS ve JS dosyalarını yükle
     */
    public function enqueue_admin_assets($hook) {
        // Sadece kendi sayfalarımızda yükle
        if (strpos($hook, 'trendyol-sync') === false) {
            return;
        }
        
        wp_enqueue_style('tws-admin-css', TWS_PLUGIN_URL . 'assets/css/admin.css', array(), TWS_VERSION);
        wp_enqueue_script('tws-admin-js', TWS_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), TWS_VERSION, true);
        
        // AJAX için nonce ve URL
        wp_localize_script('tws-admin-js', 'twsAjax', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('tws_nonce')
        ));
    }
    
    /**
     * Dashboard sayfası
     */
    public function display_dashboard() {
        include TWS_PLUGIN_DIR . 'admin/dashboard.php';
    }
    
    /**
     * Ürünler sayfası
     */
    public function display_products_page() {
        include TWS_PLUGIN_DIR . 'admin/products.php';
    }
    
    /**
     * Kategoriler sayfası
     */
    public function display_categories_page() {
        include TWS_PLUGIN_DIR . 'admin/categories.php';
    }
    
    /**
     * Ayarlar sayfası
     */
    public function display_settings_page() {
        include TWS_PLUGIN_DIR . 'admin/settings.php';
    }
    
    /**
     * Loglar sayfası
     */
    public function display_logs_page() {
        include TWS_PLUGIN_DIR . 'admin/logs.php';
    }
    
    /**
     * AJAX: API bağlantısını test et
     */
    public function ajax_test_connection() {
        check_ajax_referer('tws_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Yetkiniz yok');
        }
        
        $api = new TWS_API();
        $result = $api->test_connection();
        
        wp_send_json($result);
    }
    
    /**
     * AJAX: Ürünleri senkronize et
     */
    public function ajax_sync_products() {
        check_ajax_referer('tws_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Yetkiniz yok');
        }
        
        $sync = new TWS_Product_Sync();
        $result = $sync->sync_all_products();
        
        wp_send_json($result);
    }
    
    /**
     * AJAX: Trendyol kategorilerini getir
     */
    public function ajax_get_categories() {
        check_ajax_referer('tws_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Yetkiniz yok');
        }
        
        $api = new TWS_API();
        $categories = $api->get_categories();
        
        wp_send_json_success($categories);
    }
}

// Eklentiyi başlat
function tws_init() {
    return Trendyol_WooCommerce_Sync::get_instance();
}

// WordPress yüklendikten sonra çalıştır
add_action('plugins_loaded', 'tws_init');
